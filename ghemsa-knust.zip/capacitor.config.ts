import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ghemsa.portal',
  appName: 'GHEMSA Portal',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
