import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini Client
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // REST API: Gemini study assistant & formulation router
  app.post('/api/gemini/generate', async (req: express.Request, res: express.Response): Promise<void> => {
    try {
      const { prompt, context } = req.body;
      if (!prompt) {
        res.status(400).json({ error: 'Prompt is required' });
        return;
      }

      const systemInstruction = `You are a professional, expert AI Clinical Herbalist and study mate tutor for the KNUST Department of Herbal Medicine (GHEMSA).
Your goal is to assist students with their academic learning, past questions explanations, and formulating high-quality clinical herbal recipes.
Provide clear botanical details, pharmacological actions, ratios of active molecules, preparation methodologies, scientific rationales, and critical toxicological/interaction safety warnings.
Be extremely encouraging, scholarly, precise, and highly structured (use professional Markdown headings, lists, and bold details). Connect ideas back to African/Ghanaian pharmacopeia where appropriate.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: context ? `Context analysis:\n${context}\n\nStudent prompt:\n${prompt}` : prompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const outText = response.text || "No response generated.";
      res.json({ text: outText });
    } catch (error: any) {
      console.error('Error invoking Gemini model:', error);
      res.status(500).json({ error: error.message || 'Internal AI engine error' });
    }
  });

  // Hot Module Replacement/Develop Mode Setup via Vite Middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production serving static assets
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: express.Request, res: express.Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[GHEMSA WebServer] running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
