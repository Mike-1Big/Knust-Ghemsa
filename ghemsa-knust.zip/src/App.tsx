import { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { initAuth, googleSignIn, logout } from './auth';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, LogOut, Menu, X, User as UserIcon, Brain, Sprout, 
  Library, Compass, GraduationCap, Phone, Sparkles, CheckCircle, 
  Clock, Calendar, ShieldAlert, Home, Info, Users, Beaker, 
  Newspaper, Network, Image, Bot, Mail, Shield, ChevronRight
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import LearningMaterials from './components/LearningMaterials';
import PastQuestions from './components/PastQuestions';
import HerbalReference from './components/HerbalReference';
import StudyNotes from './components/StudyNotes';
import FloraRegistry from './components/FloraRegistry';

import DepartmentHome from './components/DepartmentHome';
import AboutDepartment from './components/AboutDepartment';
import AcademicProgrammes from './components/AcademicProgrammes';
import FacultyDirectory from './components/FacultyDirectory';
import ResearchInnovation from './components/ResearchInnovation';
import StudentHubOverview from './components/StudentHubOverview';
import NewsEvents from './components/NewsEvents';
import AlumniNetwork from './components/AlumniNetwork';
import DepartmentGallery from './components/DepartmentGallery';
import ContactUs from './components/ContactUs';
import AdvisorChatbot from './components/AdvisorChatbot';

export default function App() {
  const [activeTab, setActiveTab] = useState('dept-home');
  const [currentLevel, setCurrentLevel] = useState<100 | 200 | 300 | 400>(300);
  
  // Portal role state
  const [userRole, setUserRole] = useState<'student' | 'aspiring' | null>(() => {
    return localStorage.getItem('ghemsa_portal_user_role') as 'student' | 'aspiring' | null;
  });

  // Dynamic deep-linking subtab for Academic Syllabi/Admissions
  const [programmesSubTab, setProgrammesSubTab] = useState<'overview' | 'requirements' | 'curriculum' | 'clinicals'>('overview');

  const handleSelectRole = (role: 'student' | 'aspiring') => {
    setUserRole(role);
    localStorage.setItem('ghemsa_portal_user_role', role);
    if (role === 'student') {
      handleTabNavigation('student-hub');
    } else {
      setProgrammesSubTab('requirements');
      setActiveTab('programmes');
    }
  };

  // Auth state
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Mobile menu
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // UTC clock for authentic portal feeling!
  const [currentTime, setCurrentTime] = useState('');

  // Initialize auth
  useEffect(() => {
    const unsubscribe = initAuth(
      (activeUser, token) => {
        setUser(activeUser);
        setAccessToken(token);
        setNeedsAuth(false);
      },
      () => {
        setUser(null);
        setAccessToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  // Update clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toUTCString().replace('GMT', 'UTC'));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setAccessToken(result.accessToken);
        setNeedsAuth(false);
      }
    } catch (err) {
      console.error('Google Sign-in failed:', err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setAccessToken(null);
      setNeedsAuth(true);
      setActiveTab('dashboard');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  const handleTabNavigation = (tabName: string) => {
    if (tabName === 'formulation') {
      setActiveTab('herbs');
      setTimeout(() => {
        const element = document.getElementById('ghemsa_ai_formulation_section');
        element?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else if (tabName === 'admission' || tabName === 'requirements') {
      setActiveTab('programmes');
      setProgrammesSubTab('requirements');
    } else if (tabName === 'programmes') {
      setActiveTab('programmes');
      setProgrammesSubTab('overview');
    } else {
      setActiveTab(tabName);
    }
    setMobileMenuOpen(false);
  };

  const publicMenuItems = [
    { id: 'dept-home', label: 'Department Home', icon: Home, description: 'Welcome & Achievements' },
    { id: 'about', label: 'About Us', icon: Info, description: 'History & Goals' },
    { id: 'programmes', label: 'Academic Syllabi', icon: GraduationCap, description: 'BSc Course outlines' },
    { id: 'faculty', label: 'Faculty Directory', icon: Users, description: 'Academic staff files' },
    { id: 'research', label: 'Research & Science', icon: Beaker, description: 'Lab assets & projects' },
    { id: 'news-events', label: 'News & Announcements', icon: Newspaper, description: 'Announcements bulletin' },
    { id: 'alumni', label: 'Alumni Circles', icon: Network, description: 'Mentorship & success' },
    { id: 'gallery', label: 'Campus Gallery', icon: Image, description: 'Photos of gardens & labs' },
    { id: 'chatbot', label: 'AI Chatbot & FAQs', icon: Bot, description: 'Instant answers lookup' },
    { id: 'contact', label: 'Registrar Offices', icon: Mail, description: 'Submit official inquiry' },
  ];

  const studentMenuItems = [
    { id: 'student-hub', label: 'Current Scholars Hub', icon: Compass, description: 'Central scholar tools' },
    { id: 'dashboard', label: 'Syllabus Matrix', icon: Shield, description: 'Yearly clinical course list' },
    { id: 'materials', label: 'Library Guides & Manuals', icon: BookOpen, description: 'Lab slides & material PDF' },
    { id: 'quiz', label: 'Past Questions Studio', icon: Brain, description: 'MCQ simulation testing' },
    { id: 'herbs', label: 'Active Formulation Lab', icon: Sprout, description: 'Thermodynamic cosmetic aid' },
    { id: 'notes', label: 'Google Sync Notes', icon: Library, description: 'Backup study notebooks' },
    { id: 'flora', label: 'GHEMSA Herbarium', icon: Compass, description: '3,000 Species Database' },
  ];

  const menuItems = [...publicMenuItems, ...studentMenuItems];

  return (
    <div className="min-h-screen bg-[#fbfcfa] text-slate-800 flex flex-col font-sans" id="ghemsa_portal_root">
      
      {/* GLOBAL HIGH-END DESKTOP LEFT SIDEBAR LAYOUT */}
      <aside 
        className="hidden md:flex flex-col w-72 bg-[#09150e] text-slate-205 border-r border-emerald-950/20 fixed h-full z-40"
        id="ghemsa_desktop_sidebar"
      >
        {/* Sidebar Header Brand Area */}
        <div className="p-6 border-b border-emerald-950/30 space-y-4 shrink-0">
          <div 
            onClick={() => handleTabNavigation('dashboard')} 
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="rounded-xl bg-gradient-to-tr from-emerald-500 to-emerald-750 p-2.5 text-white shadow-lg shadow-emerald-500/10">
              <Sprout className="h-5.5 w-5.5 animate-pulse" />
            </div>
            <div>
              <span className="font-black text-white text-[15px] tracking-tight block uppercase font-display">GHEMSA KNUST</span>
              <span className="text-[9px] uppercase tracking-widest font-black text-emerald-400 block mt-0.5">Academic Portal v2.0</span>
            </div>
          </div>

          {/* Custom Interactive Portal View Mode Badge */}
          <div className="rounded-xl bg-emerald-950/65 border border-emerald-800/30 px-3 py-2.5 space-y-2 text-[10px] text-emerald-300">
            <div className="flex items-center justify-between text-[8px] uppercase tracking-wider font-black text-slate-400">
              <span className="flex items-center gap-1">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400"></span>
                </span>
                Portal View Mode
              </span>
              <span className="font-mono text-emerald-500 font-extrabold">{userRole === 'student' ? 'Student' : 'Admissions'}</span>
            </div>
            
            {userRole === 'student' ? (
              <div className="space-y-1.5">
                <p className="font-extrabold text-white text-xs flex items-center gap-1">
                  🎓 Current Scholar
                </p>
                <button
                  onClick={() => handleSelectRole('aspiring')}
                  className="w-full text-center text-[8.5px] font-black uppercase text-amber-300 hover:text-amber-200 bg-amber-400/5 hover:bg-amber-400/10 border border-amber-500/20 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  Go to Admissions Mode ➔
                </button>
              </div>
            ) : userRole === 'aspiring' ? (
              <div className="space-y-1.5">
                <p className="font-extrabold text-amber-400 text-xs flex items-center gap-1">
                  🎯 Aspiring Student
                </p>
                <button
                  onClick={() => handleSelectRole('student')}
                  className="w-full text-center text-[8.5px] font-black uppercase text-emerald-400 hover:text-emerald-305 bg-emerald-400/5 hover:bg-emerald-400/10 border border-emerald-500/20 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  Go to Student Mode ➔
                </button>
              </div>
            ) : (
              <div className="space-y-1 text-center">
                <p className="font-bold text-slate-400 text-[10px]">Unconfigured Mode</p>
                <button
                  onClick={() => handleSelectRole('student')}
                  className="text-emerald-400 hover:underline cursor-pointer"
                >
                  Configure Entry Option
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Level Controls directly in Sidebar for effortless access! */}
        <div className="p-4 border-b border-emerald-950/15 bg-emerald-950/10 shrink-0 space-y-2">
          <p className="text-[9px] uppercase font-black tracking-widest text-emerald-500/80 px-2">Academic Study Year</p>
          <div className="grid grid-cols-4 gap-1 rounded-xl bg-emerald-950/60 p-0.5" id="sidebar_level_selector">
            {([100, 200, 300, 400] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setCurrentLevel(lvl)}
                className={`rounded-lg py-1.5 text-xs font-black transition-all ${
                  currentLevel === lvl
                    ? 'bg-emerald-800 text-white shadow-md shadow-emerald-900/45'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                L{lvl}
              </button>
            ))}
          </div>
        </div>

        {/* Sidebar Navigation Items */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6 animate-fade-in" id="sidebar_tabs_menu">
          
          {/* Public Portal Section */}
          <div className="space-y-1">
            <span className="text-[8.5px] uppercase font-black text-emerald-500/60 tracking-widest block px-3.5 mb-2">Public Department Portal</span>
            {publicMenuItems.map((item) => {
              const IconComponent = item.icon;
              const isSelected = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabNavigation(item.id)}
                  className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-bold tracking-tight text-left transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-900/60 to-emerald-950/20 text-white border-l-4 border-emerald-400 shadow-inner'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  id={`sidebar_tab_${item.id}`}
                >
                  <IconComponent className={`h-4 w-4 shrink-0 col-span-1 ${isSelected ? 'text-emerald-400' : 'text-slate-450'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold truncate leading-none">{item.label}</p>
                    <p className="text-[8px] font-medium text-slate-500 truncate mt-0.5 leading-none">{item.description}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Student Portal Studio Section */}
          <div className="space-y-1">
            <span className="text-[8.5px] uppercase font-black text-emerald-500/60 tracking-widest block px-3.5 mb-2">Interactive Student Studio</span>
            {studentMenuItems.map((item) => {
              const IconComponent = item.icon;
              const isSelected = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabNavigation(item.id)}
                  className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-bold tracking-tight text-left transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-900/60 to-emerald-950/20 text-white border-l-4 border-emerald-400 shadow-inner'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  id={`sidebar_tab_${item.id}`}
                >
                  <IconComponent className={`h-4 w-4 shrink-0 col-span-1 ${isSelected ? 'text-emerald-400' : 'text-slate-450'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold truncate leading-none">{item.label}</p>
                    <p className="text-[8px] font-medium text-slate-500 truncate mt-0.5 leading-none">{item.description}</p>
                  </div>
                </button>
              );
            })}
          </div>

        </nav>

        {/* Interactive authorized user widget in sidebar bottom */}
        <div className="p-4 border-t border-emerald-950/30 bg-emerald-950/20 shrink-0 space-y-3">
          {!needsAuth && user ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2.5 bg-slate-900/60 rounded-xl p-2.5 border border-white/5">
                <div className="h-8.5 w-8.5 rounded-full bg-emerald-800 border border-emerald-500/40 flex items-center justify-center text-white text-xs font-black uppercase shadow-inner">
                  {user.displayName ? user.displayName.slice(0, 2) : 'ST'}
                </div>
                <div className="flex-1 min-w-0 text-left text-[11px] font-bold">
                  <p className="text-white truncate leading-none">{user.displayName || 'GHEMSA Student'}</p>
                  <p className="text-emerald-400/80 text-[8px] truncate mt-0.5 leading-none">{user.email}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-wider text-rose-400 bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/20 py-2 rounded-xl transition-all"
              >
                <LogOut className="h-3 w-3" /> Sign Out Portal
              </button>
            </div>
          ) : (
            <button
              onClick={handleLogin}
              disabled={isLoggingIn}
              className="w-full block text-center rounded-xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black py-2.5 text-xs transition-colors shadow-lg shadow-emerald-500/5 hover:scale-[1.02] transform"
              id="sidebar_btn_auth"
            >
              Google Student Account Link
            </button>
          )}

          {/* Quick contact support hotline link */}
          <div className="text-[9px] font-mono font-bold text-center text-slate-500 space-y-1">
            <p>GHEMSA HotLine Contact:</p>
            <a 
              href="tel:0531855909" 
              className="inline-flex items-center gap-1 text-emerald-300 hover:text-emerald-250 hover:underline bg-emerald-950/50 px-2 py-1 rounded"
            >
              <Phone className="h-2.5 w-2.5" /> 0531855909
            </a>
          </div>
        </div>
      </aside>

      {/* MOBILE HEADER RESPONSIVE VIEWS */}
      <nav className="md:hidden bg-white border-b border-slate-100 sticky top-0 z-50 shadow-sm" id="ghemsa_mobile_navbar">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div 
            onClick={() => handleTabNavigation('dashboard')} 
            className="flex items-center gap-2 cursor-pointer select-none"
          >
            <div className="rounded-lg bg-emerald-850 p-2 text-white">
              <GraduationCap className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="font-extrabold text-slate-800 text-xs block tracking-tight">GHEMSA KNUST</span>
              <span className="text-[8px] uppercase tracking-wider font-extrabold text-emerald-700 block">Herbal Medicine Portal</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a 
              href="tel:0531855909" 
              className="bg-emerald-50 text-emerald-800 text-[10px] font-black uppercase px-2.5 py-1.5 rounded-full border border-emerald-100 flex items-center gap-1.5"
            >
              <Phone className="h-3 w-3 animate-bounce" /> CALL Support
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="rounded-lg p-2 text-slate-505 hover:bg-slate-150"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu expanded overlay */}
        {mobileMenuOpen && (
          <div className="border-t border-slate-100 bg-white" id="mobile_menu_expanded">
            <div className="px-3 pt-3 pb-4 space-y-1.5">
              
              {/* Studies selection year inside mobile list */}
              <div className="p-2.5 bg-slate-50 rounded-xl space-y-1">
                <span className="text-[8px] uppercase font-black text-slate-400 tracking-wider">Configure Study Year</span>
                <div className="grid grid-cols-4 gap-1 rounded bg-slate-200/60 p-0.5">
                  {([100, 200, 300, 400] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setCurrentLevel(lvl)}
                      className={`rounded py-1 text-xs font-bold transition-all ${
                        currentLevel === lvl ? 'bg-emerald-805 text-white' : 'text-slate-600'
                      }`}
                    >
                      L{lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mobile Portal View Mode custom config card */}
              <div className="p-2.5 bg-emerald-50 rounded-xl space-y-1.5 border border-emerald-100 text-left">
                <div className="flex items-center justify-between">
                  <span className="text-[8px] uppercase font-black text-emerald-850 tracking-wider">Portal View Mode</span>
                  <span className="text-[8.5px] font-black text-emerald-950 bg-white px-2 py-0.5 rounded border border-emerald-250/20 uppercase tracking-tight">
                    {userRole === 'student' ? '🎓 Registered Scholar' : '🎯 Prospective'}
                  </span>
                </div>
                <button
                  onClick={() => handleSelectRole(userRole === 'student' ? 'aspiring' : 'student')}
                  className="w-full text-center text-[9px] font-black uppercase text-white bg-emerald-850 hover:bg-emerald-900 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  Switch to {userRole === 'student' ? 'Admissions Mode' : 'Student Mode'} ➔
                </button>
              </div>

              {/* Public Portal Options */}
              <div className="space-y-1 pt-2">
                <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider block px-2 mb-1">Public Department Portal</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {publicMenuItems.map((item) => {
                    const isSelected = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleTabNavigation(item.id)}
                        className={`text-left rounded-xl px-3 py-2 text-[11px] font-bold block truncate ${
                          isSelected ? 'bg-emerald-50 text-emerald-800 font-extrabold border border-emerald-200/50' : 'text-slate-600 bg-slate-50 hover:bg-slate-100'
                        }`}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Student Portal Options */}
              <div className="space-y-1 pt-2">
                <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider block px-2 mb-1">Interactive Student Studio</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {studentMenuItems.map((item) => {
                    const isSelected = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleTabNavigation(item.id)}
                        className={`text-left rounded-xl px-3 py-2 text-[11px] font-bold block truncate ${
                          isSelected ? 'bg-emerald-50 text-emerald-800 font-extrabold border border-emerald-200/50' : 'text-slate-605 bg-slate-50 hover:bg-slate-100'
                        }`}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Mobile Account trigger */}
              <div className="border-t border-slate-100 pt-3">
                {!needsAuth && user ? (
                  <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl">
                    <div className="text-left">
                      <p className="text-xs font-bold text-slate-800">{user.displayName || 'GHEMSA Student'}</p>
                      <p className="text-[9px] text-slate-400">{user.email}</p>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="inline-flex items-center gap-1 text-[9px] uppercase tracking-wider font-extrabold text-rose-600 px-3 py-1.5 rounded-lg border border-rose-150 bg-rose-50"
                    >
                      Logout
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleLogin}
                    disabled={isLoggingIn}
                    className="w-full text-center rounded-xl bg-slate-800 py-2.5 text-xs font-bold text-white block shadow-md"
                  >
                    Sign in with Student Google Profile
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* CORE CONTENT BLOCK - FLOATING RIGHT ASPECT */}
      <div className="flex-1 md:ml-72 flex flex-col min-h-screen" id="main_cockpit_frame">
        
        {/* Top telemetry breadcrumb indicator line */}
        <header className="hidden md:flex items-center justify-between px-8 py-4.5 bg-white border-b border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-slate-400">
            <span>KNUST BSc Herbal Medicine</span>
            <span>/</span>
            <span className="text-emerald-850 font-black tracking-normal capitalize">{activeTab}</span>
            <span>/</span>
            <span className="text-slate-450 font-semibold uppercase font-mono">Level {currentLevel} Core</span>
          </div>

          {/* Clock, Sync, and indicators */}
          <div className="flex items-center gap-6 text-[11px] font-bold text-slate-500">
            <div className="flex items-center gap-1 text-slate-450">
              <Clock className="h-3.5 w-3.5" />
              <span className="font-mono font-black">{currentTime || 'GHEMSA Syncing...'}</span>
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5 text-emerald-700" />
              <span>Year {currentLevel/100} • Semesters 1 & 2 Active</span>
            </div>
          </div>
        </header>

        {/* Main Content Area with elegant AnimatePresence transition */}
        <main className="flex-1 p-4 sm:p-8 lg:p-10 max-w-6xl w-full mx-auto pb-24 md:pb-10">
          
          {/* Authorization nag box if active & on G-Drive dependent tabs */}
          {needsAuth && ['materials', 'herbs', 'notes'].includes(activeTab) && (
            <div 
              className="mb-8 rounded-3xl border border-dashed border-emerald-250 bg-emerald-50/20 p-6 flex flex-col sm:flex-row items-center justify-between gap-6 animate-fade-in"
              id="google_drive_nag"
            >
              <div className="flex items-start gap-4 text-center sm:text-left">
                <div className="h-12 w-12 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mx-auto sm:mx-0">
                  <Library className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-extrabold text-slate-800 text-sm md:text-base">Unlock Google Drive Revision Sync</h3>
                  <p className="text-xs text-slate-500 max-w-xl leading-relaxed">
                    Link your account to backup flashcards, monographs, and formulation logs. The GHEMSA student portal complies with KNUST secure GSI-material API standards.
                  </p>
                </div>
              </div>

              {/* GSI standard button */}
              <button 
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="gsi-material-button text-xs py-2 select-none"
                id="gsi_auth_btn_main"
              >
                <div className="gsi-material-button-state"></div>
                <div className="gsi-material-button-content-wrapper">
                  <div className="gsi-material-button-icon">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: "block" }}>
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                      <path fill="none" d="M0 0h48v48H0z"></path>
                    </svg>
                  </div>
                  {isLoggingIn ? (
                    <span className="gsi-material-button-contents font-bold text-xs">Authenticating...</span>
                  ) : (
                    <span className="gsi-material-button-contents font-bold text-xs">Sign in with Google</span>
                  )}
                </div>
              </button>
            </div>
          )}

          {/* Render Active View with elegant motion fade-in */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab + currentLevel}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              id="active_tab_render_area"
            >
              {activeTab === 'dept-home' && (
                <DepartmentHome onNavigate={handleTabNavigation} userRole={userRole} onSetRole={handleSelectRole} />
              )}

              {activeTab === 'about' && (
                <AboutDepartment />
              )}

              {activeTab === 'programmes' && (
                <AcademicProgrammes initialSubTab={programmesSubTab} />
              )}

              {activeTab === 'faculty' && (
                <FacultyDirectory />
              )}

              {activeTab === 'research' && (
                <ResearchInnovation />
              )}

              {activeTab === 'student-hub' && (
                <StudentHubOverview onNavigate={handleTabNavigation} />
              )}

              {activeTab === 'news-events' && (
                <NewsEvents />
              )}

              {activeTab === 'alumni' && (
                <AlumniNetwork />
              )}

              {activeTab === 'gallery' && (
                <DepartmentGallery />
              )}

              {activeTab === 'chatbot' && (
                <AdvisorChatbot />
              )}

              {activeTab === 'contact' && (
                <ContactUs />
              )}

              {activeTab === 'dashboard' && (
                <Dashboard
                  currentLevel={currentLevel}
                  setCurrentLevel={setCurrentLevel}
                  onNavigate={handleTabNavigation}
                  userName={user?.displayName || 'GHEMSA Scholar'}
                />
              )}

              {activeTab === 'materials' && (
                <LearningMaterials
                  currentLevel={currentLevel}
                  accessToken={accessToken}
                  onLoginRequest={handleLogin}
                />
              )}

              {activeTab === 'quiz' && (
                <PastQuestions
                  currentLevel={currentLevel}
                />
              )}

              {activeTab === 'herbs' && (
                <HerbalReference
                  accessToken={accessToken}
                  onLoginRequest={handleLogin}
                />
              )}

              {activeTab === 'notes' && (
                <StudyNotes
                  accessToken={accessToken}
                  onLoginRequest={handleLogin}
                  currentLevel={currentLevel}
                />
              )}

              {activeTab === 'flora' && (
                <FloraRegistry />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Global Footer in Right-pane bottom */}
        <footer className="bg-white border-t border-slate-100 py-6 pb-28 md:pb-6 text-center text-slate-450 text-xs mt-auto">
          <div className="max-w-7xl mx-auto px-4 space-y-1">
            <p className="font-extrabold text-slate-600">GHEMSA Portal • College of Health Sciences</p>
            <p className="font-semibold text-slate-400">Department of Herbal Medicine • Faculty of Pharmacy, KNUST</p>
            <p className="text-emerald-800 font-extrabold pb-0.5">Assistance Hotline: <a href="tel:0531855909" className="hover:underline font-extrabold text-emerald-900 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-100">0531855909</a></p>
            <p className="text-[10px] text-slate-400">© {new Date().getFullYear()} Kwame Nkrumah University of Science and Technology. All Rights Reserved.</p>
          </div>
        </footer>

      </div>

      {/* MOBILE BOTTOM TAB BAR FOR FLUID ACCESS ON MOBILE/ANDROID SCREENS */}
      <div 
        className="md:hidden fixed bottom-1.5 left-2 right-2 bg-[#09150e]/95 backdrop-blur-md rounded-2xl border border-emerald-800/30 text-slate-350 flex justify-around items-center py-2 px-1 z-50 shadow-2xl"
        id="mobile_bottom_navbar"
      >
        {[
          { id: 'dept-home', label: 'Home', icon: Home },
          { id: 'programmes', label: 'Degrees', icon: GraduationCap },
          { id: 'student-hub', label: 'Scholars', icon: Compass },
          { id: 'chatbot', label: 'Advisor AI', icon: Bot },
          { id: 'contact', label: 'Contact', icon: Mail },
        ].map((item) => {
          const IconComponent = item.icon;
          const isSelected = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleTabNavigation(item.id)}
              className="flex flex-col items-center justify-center gap-0.5 cursor-pointer"
              style={{ flex: 1 }}
              id={`mobile_tab_${item.id}`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${
                isSelected 
                  ? 'bg-emerald-500 text-emerald-950 font-extrabold shadow-md shadow-emerald-500/20' 
                  : 'text-slate-405 hover:text-white'
              }`}>
                <IconComponent className="h-4.5 w-4.5 shrink-0" />
              </div>
              <span className={`text-[8px] font-black uppercase tracking-widest ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Floating support bubble as fallback (Desktop Only) */}
      <div className="hidden md:block fixed bottom-4 right-4 z-40 transition-transform duration-300 hover:scale-105" id="floating_cta_hotline">
        <a
          href="tel:0531855909"
          className="flex items-center gap-2 rounded-full bg-emerald-850 hover:bg-emerald-900 border border-emerald-950 text-white font-black px-4.5 py-2.5 shadow-lg text-xs"
        >
          <span className="relative flex h-2 w-2 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-400"></span>
          </span>
          <Phone className="h-3.5 w-3.5" />
          <span>Support: 0531855909</span>
        </a>
      </div>

      {/* Welcome Path Selector Onboarding Overlay */}
      {userRole === null && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4 z-[9999] overflow-y-auto animate-fade-in" id="portal_role_onboarding">
          <div className="w-full max-w-4xl bg-[#fbfcfa] rounded-3xl border border-emerald-900/10 overflow-hidden shadow-2xl my-8">
            {/* Brand Header */}
            <div className="bg-[#09150e] text-center py-8 px-6 border-b border-emerald-950/35 relative">
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-400 via-emerald-500 to-amber-500"></div>
              <div className="inline-flex rounded-2xl bg-emerald-600/10 p-3 text-emerald-400 mb-3 border border-emerald-500/15">
                <Sprout className="h-8 w-8 animate-pulse text-emerald-400" />
              </div>
              <h2 className="text-xl sm:text-3xl font-black tracking-tight text-white font-display">
                KNUST Herbal Medicine Portal
              </h2>
              <p className="text-[10px] sm:text-xs uppercase tracking-widest font-black text-amber-400 mt-1.5">
                Kwame Nkrumah University of Science & Technology • GHEMSA
              </p>
              <p className="text-xs text-slate-400 max-w-xl mx-auto mt-2 leading-relaxed">
                Configure your portal workspace: customize lecture syllabus modules, browse pre-clinical pharmacology benchmarks, or launch live interactive simulators.
              </p>
            </div>

            {/* Choice columns */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 sm:p-8 bg-[#fbfcfa]">
              
              {/* CURRENT STUDENT CARD */}
              <div 
                onClick={() => handleSelectRole('student')}
                className="group rounded-3xl border-2 border-slate-150 bg-white hover:border-emerald-600 hover:ring-8 hover:ring-emerald-500/5 transition-all duration-300 p-6 flex flex-col justify-between cursor-pointer text-left relative overflow-hidden shadow-sm"
              >
                <div className="space-y-4">
                  <div className="relative h-44 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200">
                    <img 
                      src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=505&h=300&q=80" 
                      alt="Current Scholars Studying" 
                      className="object-cover w-full h-full group-hover:scale-104 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute top-2.5 left-2.5 bg-emerald-850 text-white font-black text-[9px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow">
                      Current Scholar
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="font-extrabold text-slate-800 text-sm md:text-base group-hover:text-emerald-850 transition-colors flex items-center gap-2">
                      I am a Registered Student <GraduationCap className="h-4.5 w-4.5 text-emerald-700" />
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Access specialized class revision aids, past MCQ exams database, cosmetic/herbal formulation labs, syllabus matrices, and sync study diaries to Google Drive.
                    </p>
                  </div>
                </div>

                <div className="border-t border-slate-105 pt-4 mt-6 flex items-center justify-between text-xs text-emerald-850 font-extrabold">
                  <span>Help Me with Academia ➔</span>
                  <ChevronRight className="h-4 w-4 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>

              {/* PROSPECTIVE STUDENT CARD */}
              <div 
                onClick={() => handleSelectRole('aspiring')}
                className="group rounded-3xl border-2 border-slate-150 bg-white hover:border-amber-500 hover:ring-8 hover:ring-amber-500/5 transition-all duration-300 p-6 flex flex-col justify-between cursor-pointer text-left relative overflow-hidden shadow-sm"
              >
                <div className="space-y-4">
                  <div className="relative h-44 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200">
                    <img 
                      src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=505&h=300&q=80" 
                      alt="Hopeful Prospective Scholar" 
                      className="object-cover w-full h-full group-hover:scale-104 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute top-2.5 left-2.5 bg-amber-500 text-slate-950 font-black text-[9px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow">
                      Prospective Scholar
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="font-extrabold text-slate-800 text-sm md:text-base group-hover:text-amber-700 transition-colors flex items-center gap-2">
                      I am an Aspiring Student <Compass className="h-4.5 w-4.5 text-amber-500" />
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Review accredited admission targets, tuition budgets, degree guidelines, history records, and interact with our Virtual AI Student Advisor.
                    </p>
                  </div>
                </div>

                <div className="border-t border-slate-105 pt-4 mt-6 flex items-center justify-between text-xs text-amber-700 font-extrabold">
                  <span>Check Admissions & Requirements ➔</span>
                  <ChevronRight className="h-4 w-4 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>

            </div>

            {/* Certifications and footnotes */}
            <div className="bg-slate-50 py-4.5 px-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] font-bold text-slate-550">
              <span>National Health Sector Integrated Curriculum</span>
              <span className="hidden sm:inline text-slate-400">•</span>
              <span>Fully Accredited by Traditional Medicine Practice Council (TMPC) Ghana</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
