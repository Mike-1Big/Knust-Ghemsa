import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);


const provider = new GoogleAuthProvider();
// Required Scopes for study material syncing
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.addScope('https://www.googleapis.com/auth/drive.readonly');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

// Auth state listener setup
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // Clear tokens and notify failure to login again if not active
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Google Auth');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

// ==========================================
// GOOGLE DRIVE STUDY REPOSITORY WORKFLOWS
// ==========================================

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  createdTime?: string;
}

/**
 * Searches and lists Markdown files in GHEMSA Study Notebook folder
 */
export async function listDriveStudyNotes(accessToken: string, folderId: string): Promise<DriveFileItem[]> {
  try {
    const q = `_trash=false and '${folderId}' in parents and mimeType='text/markdown'`;
    const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name,mimeType,webViewLink,createdTime)&orderBy=name`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) {
      throw new Error('Failed to list files in Google Drive');
    }
    const data = await res.json();
    return data.files || [];
  } catch (err) {
    console.error('Error listing Drive study notes:', err);
    return [];
  }
}

/**
 * Finds or creates the dedicated "GHEMSA KNUST Study Notebook" folder
 */
export async function findOrCreateAppFolder(accessToken: string): Promise<string> {
  try {
    // 1. Search for existing folder with matches name
    const q = "mimeType = 'application/vnd.google-apps.folder' and name = 'GHEMSA KNUST Study Notebook' and trashed = false";
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)`;
    const res = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) {
      throw new Error('Failed to query Google Drive folders');
    }
    const data = await res.json();
    if (data.files && data.files.length > 0) {
      return data.files[0].id;
    }

    // 2. Not found, let's create a new one!
    const createUrl = 'https://www.googleapis.com/drive/v3/files';
    const folderMetadata = {
      name: 'GHEMSA KNUST Study Notebook',
      mimeType: 'application/vnd.google-apps.folder',
    };
    const createRes = await fetch(createUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(folderMetadata),
    });
    if (!createRes.ok) {
      throw new Error('Failed to create GHEMSA folder on Google Drive');
    }
    const folder = await createRes.json();
    return folder.id;
  } catch (err) {
    console.error('Error handling GHEMSA folder:', err);
    throw err;
  }
}

/**
 * Uploads a note to GHEMSA folder (supports Create and update)
 */
export async function uploadNoteToDrive(
  accessToken: string,
  folderId: string,
  title: string,
  content: string,
  existingFileId?: string
): Promise<string> {
  try {
    const filename = title.endsWith('.md') ? title : `${title}.md`;

    if (existingFileId) {
      // 1. Update existing file content (Media upload PATCH)
      const updateUrl = `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=media`;
      const updateRes = await fetch(updateUrl, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'text/markdown',
        },
        body: content,
      });

      if (updateRes.ok) {
        return existingFileId;
      }
      console.warn('Stale file ID found, writing fresh file fallback...');
    }

    // 2. Perform multipart upload to create a new file
    const metadata = {
      name: filename,
      mimeType: 'text/markdown',
      parents: [folderId],
    };

    const boundary = 'ghemsa_knust_boundary';
    const delimiter = `\r\n--${boundary}\r\n`;
    const close_delim = `\r\n--${boundary}--`;

    const body =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: text/markdown; charset=UTF-8\r\n\r\n' +
      content +
      close_delim;

    const createUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    const createRes = await fetch(createUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: body,
    });

    if (!createRes.ok) {
      const errText = await createRes.text();
      throw new Error(`Drive Create File failed: ${errText}`);
    }

    const fileData = await createRes.json();
    return fileData.id;
  } catch (err) {
    console.error('Error uploading note:', err);
    throw err;
  }
}

/**
 * Deletes a file from Google Drive (includes prompt protection)
 */
export async function deleteNoteFromDrive(accessToken: string, fileId: string): Promise<boolean> {
  try {
    const url = `https://www.googleapis.com/drive/v3/files/${fileId}`;
    const res = await fetch(url, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    return res.ok;
  } catch (err) {
    console.error('Error deleting file:', err);
    return false;
  }
}
