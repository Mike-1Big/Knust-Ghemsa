import React from 'react';
import { History, ShieldCheck, Handshake, Sprout, Footprints, GraduationCap, Users } from 'lucide-react';

export default function AboutDepartment() {
  React.useEffect(() => {
    document.title = "About Us | Department of Herbal Medicine | KNUST Ghana";
  }, []);

  const milestones = [
    {
      year: '2001',
      title: 'Department Founded',
      desc: 'Established as the first academic department in West Africa to offer a fully standardized degree in Herbal Medicine under the Faculty of Pharmacy, KNUST.'
    },
    {
      year: '2005',
      title: 'First Cohort Graduates',
      desc: 'The pioneer batch of medical herbalists entered the field, subsequently registered by the Traditional Medicine Practice Council (TMPC).'
    },
    {
      year: '2010',
      title: 'MoH Clinical Integration',
      desc: 'The Ghana Ministry of Health approved and established official clinical Herbal Units in selected regional and district state hospitals.'
    },
    {
      year: '2018',
      title: 'WHO Focal Coordination',
      desc: 'Collaborated on standardizing traditional medical practices across the West African Health Organisation (WAHO) territory.'
    },
    {
      year: '2024',
      title: 'National Registry Milestone',
      desc: 'Over 300+ medical herbalists actively deployed under Ghana Health Service (GHS) payroll, establishing reliable, community-first botanical options.'
    }
  ];

  return (
    <div className="space-y-12 animate-fade-in" id="about_department_root">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (About View)</span>
        <strong className="text-slate-700">Title:</strong> History & Objectives | Dept of Herbal Medicine | KNUST Ghana<br />
        <strong className="text-slate-700">Description:</strong> Learn about our rich historical journey since 2001, our core clinical training mandates, and our extensive community outreach in Ghana.
      </div>

      {/* Header section */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block">History & Strategic Intent</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Pioneering Clinical Phytotherapy in Africa
        </h1>
        <p className="text-xs sm:text-base text-slate-500 max-w-3xl leading-relaxed">
          The Kwame Nkrumah University of Science and Technology (KNUST) has been at the forefront of science education since its inception. Decades of rich, indigenous herbal research culminated in the professional establishment of our department in 2001.
        </p>
      </div>

      {/* Narrative grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        
        {/* Left pane: History and Origin text */}
        <div className="bg-white border border-slate-150 rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-850">
              <History className="h-5 w-5" />
            </div>
            <h3 className="font-extrabold text-slate-800 text-base">Historical Context</h3>
          </div>

          <div className="text-xs sm:text-sm text-slate-600 space-y-4 leading-relaxed">
            <p>
              Traditional medicine represents the primary line of healthcare for over 70% of the Ghanaian population. Although therapeutic outcomes were well documented, practitioners were historically untrained in surgical safety, modern clinical diagnostics, pharmacology, or professional ethical standards.
            </p>
            <p>
              In response, the <strong>Government of Ghana</strong>, through the Ministry of Health, collaborated with KNUST in 2001 to introduce the pioneered <strong>Bachelor of Herbal Medicine (BSc)</strong> programme. This initiative aimed to bridge the therapeutic efficacy of ethnic remedies with modern scientific safety validation models.
            </p>
            <p className="border-l-4 border-amber-400 bg-amber-500/5 p-3 rounded-r-xl font-medium text-slate-700">
              Graduates of the department, known professionally as <strong>Medical Herbalists</strong>, complete a rigorous academic course load, clinical medicine rotations in partner state hospitals, and national service to receive standard government licensing.
            </p>
            <p>
              Today, the department stands as an international model for the professionalization of indigenous medical science across low-to-medium income nations globally.
            </p>
          </div>
        </div>

        {/* Right pane: Objectives, Role in healthcare */}
        <div className="space-y-6">
          <div className="bg-emerald-950 text-emerald-100 rounded-3xl p-6 md:p-8 space-y-6 border border-emerald-905">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-900 border border-emerald-800 text-emerald-300">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-white text-base">Key Strategic Goals</h3>
            </div>

            <ul className="space-y-4 text-xs">
              <li className="flex gap-3">
                <span className="p-1.5 h-6 w-6 rounded-full bg-emerald-900 text-emerald-400 font-bold flex items-center justify-center shrink-0">1</span>
                <div>
                  <strong className="text-white block font-black">Standardize Herbal Preparations</strong>
                  Validate local safety margins, define correct therapeutic dosing levels, and formulate active bio-stabilized syrups/creams.
                </div>
              </li>
              <li className="flex gap-3">
                <span className="p-1.5 h-6 w-6 rounded-full bg-emerald-900 text-emerald-400 font-bold flex items-center justify-center shrink-0">2</span>
                <div>
                  <strong className="text-white block font-black">Integrative Hospital Practicing</strong>
                  Empower students to confidently practice in primary and tertiary clinics alongside medical officers, sharing analytical diagnostic findings.
                </div>
              </li>
              <li className="flex gap-3">
                <span className="p-1.5 h-6 w-6 rounded-full bg-emerald-900 text-emerald-400 font-bold flex items-center justify-center shrink-0">3</span>
                <div>
                  <strong className="text-white block font-black">Environmental & Forest Conservation</strong>
                  Collaborate with state forestries to prevent the extinction of rare medicinal shrubs, promoting eco-friendly farm propagation.
                </div>
              </li>
            </ul>
          </div>

          <div className="bg-white border border-slate-150 rounded-3xl p-6 flex flex-col justify-between gap-4">
            <div className="flex items-center gap-2 text-slate-800">
              <Handshake className="h-5 w-5 text-emerald-800" />
              <h4 className="font-bold text-sm">Community Engagement & Outreach</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              We frequently run outreach seminars inside rural Ghanaian marketplaces (such as Kumasi Central Market) and community health posts. Our students educate local herbal dealers on sanitary preservation, dangerous pesticide residuals, and identifying hepatotoxic toxicities.
            </p>
          </div>
        </div>

      </div>

      {/* MILESTONES TIMELINE CHART */}
      <div className="space-y-8 pt-4">
        <div className="text-center">
          <span className="text-[10px] text-emerald-800 uppercase font-black tracking-widest block">Two Decades of Progress</span>
          <h3 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight">Timeline of Herbal Professionalisation</h3>
        </div>

        <div className="relative border-l border-slate-200 ml-4 sm:ml-8 md:ml-12 space-y-8">
          {milestones.map((ms) => (
            <div key={ms.year} className="relative pl-6 sm:pl-8 group">
              {/* Dot marker */}
              <span className="absolute -left-2.5 top-1.5 h-5 w-5 rounded-full border-4 border-slate-100 bg-emerald-800 text-white shadow group-hover:scale-110 transition-transform flex items-center justify-center"></span>
              
              <div className="bg-white rounded-2xl border border-slate-150 p-5 shadow-sm space-y-2 max-w-3xl">
                <span className="font-mono font-black text-emerald-850 text-sm bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded">
                  {ms.year}
                </span>
                <h4 className="font-extrabold text-slate-800 text-sm">{ms.title}</h4>
                <p className="text-xs text-slate-500 leading-relaxed">{ms.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
