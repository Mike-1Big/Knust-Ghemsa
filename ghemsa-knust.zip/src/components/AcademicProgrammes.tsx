import React, { useState } from 'react';
import { BookOpen, GraduationCap, Compass, Briefcase, Award, ShieldAlert, CheckCircle2, History, ChevronRight, School, Users, Network, Calendar } from 'lucide-react';
import { COURSES_BY_LEVEL } from '../data/courses';

interface AcademicProgrammesProps {
  initialSubTab?: 'overview' | 'requirements' | 'curriculum' | 'clinicals';
}

export default function AcademicProgrammes({ initialSubTab }: AcademicProgrammesProps) {
  const [subTab, setSubTab] = useState<'overview' | 'requirements' | 'curriculum' | 'clinicals'>(initialSubTab || 'overview');

  React.useEffect(() => {
    if (initialSubTab) {
      setSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  React.useEffect(() => {
    document.title = "BSc Herbal Medicine Programme | KNUST College of Health Sciences";
  }, []);

  return (
    <div className="space-y-12 animate-fade-in" id="academic_programmes_root">
      
      {/* SEO metadata preview block */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Academic View)</span>
        <strong className="text-slate-700">Title:</strong> BSc Herbal Medicine | Admission & Careers | KNUST Ghana<br />
        <strong className="text-slate-700">Description:</strong> Apply for the fully accredited 4-year Bachelor of Herbal Medicine at KNUST. Guided by world-class standards in phytomedicine, pharmacognosy, and clinical biochemistry.
      </div>

      {/* Hero Intro */}
      <div className="space-y-4">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block">Undergraduate Syllabi Directory</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Bachelor of Herbal Medicine (BSc.)
        </h1>
        <p className="text-xs sm:text-base text-slate-600 max-w-3xl leading-relaxed">
          The Department of Herbal Medicine offers a highly standardized, fully integrated 4-year professional medical degree program. Our scholars develop diagnostic competencies parallel to conventional physicians, with deep focus on botanical therapeutics.
        </p>

        {/* Academic program sub tabs */}
        <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2.5 pt-4">
          {[
            { id: 'overview', label: 'Degree Overview', icon: GraduationCap },
            { id: 'requirements', label: 'Admissions Requirements', icon: School },
            { id: 'curriculum', label: 'Syllabus & Level Structure', icon: BookOpen },
            { id: 'clinicals', label: 'Clinicals, Internships & Careers', icon: Briefcase }
          ].map((tab) => {
            const TabIcon = tab.icon;
            const isActive = subTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSubTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer border ${
                  isActive 
                    ? 'bg-emerald-950 border-emerald-950 text-white shadow-sm'
                    : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <TabIcon className="h-4 w-4" />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Dynamic render of Sub-Tabs */}
      {subTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in" id="prog_overview">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-slate-150 space-y-4 shadow-sm">
              <h3 className="font-extrabold text-slate-800 text-base">Key Program Details</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                The Bachelor of Herbal Medicine course is structured to deliver dual expertise: traditional ethnobotanical methodologies and rigorous peer-reviewed clinical diagnosis. Student clinicians are taught to respect local cultural frameworks, while demanding quantitative molecular evidence.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Duration</span>
                  <span className="text-xs font-extrabold text-slate-700 block">4 Academic Years (Full Time)</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Total Credits</span>
                  <span className="text-xs font-extrabold text-[#11311b] block">Minimum 125 Credit Hours</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Accreditation</span>
                  <span className="text-xs font-extrabold text-emerald-800 block">TMPC & Ghana GTEC Certified</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Graduation Title</span>
                  <span className="text-xs font-extrabold text-slate-700 block">Medical Herbalist (MH)</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 border border-slate-150 space-y-4 shadow-sm">
              <h3 className="font-extrabold text-slate-800 text-base">Graduation Threshold Requirements</h3>
              <ul className="space-y-3.5 text-xs text-slate-600">
                <li className="flex gap-2 items-start">
                  <CheckCircle2 className="h-4.5 w-4.5 text-emerald-700 shrink-0 mt-0.5" />
                  <span>Completion of all primary lectures and laboratory practical hours with a minimal Cumulative Weighted Average (CWA) of 50.0% or above.</span>
                </li>
                <li className="flex gap-2 items-start">
                  <CheckCircle2 className="h-4.5 w-4.5 text-emerald-700 shrink-0 mt-0.5" />
                  <span>Successful completion of a consecutive 12-week supervised block industry clinical rotation split between authorized medical wards and forestry farms.</span>
                </li>
                <li className="flex gap-2 items-start">
                  <CheckCircle2 className="h-4.5 w-4.5 text-emerald-700 shrink-0 mt-0.5" />
                  <span>Production, defense, and submission of an original fourth-year experimental or clinical observational research dissertation.</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-5 bg-gradient-to-br from-emerald-950 to-[#0c1a11] text-emerald-100 rounded-3xl p-6 md:p-8 space-y-6">
            <h3 className="text-white font-black text-lg">Ghana Pharmacy Council Integration</h3>
            <p className="text-xs text-emerald-250/80 leading-relaxed">
              Upon successful completion of the coursework, medical herbalists undergo a compulsory <strong>One-Year Rotating Internship Agency</strong>. This internship covers:
            </p>
            <div className="space-y-4 font-normal text-xs pt-2 text-[#bfe0cc]">
              <div className="p-3 bg-emerald-900/60 rounded-xl border border-emerald-800/40">
                <h4 className="font-extrabold text-white">1. Clinical Ward Diagnostics (6 Months)</h4>
                <p className="text-[11px] text-emerald-300 mt-0.5">Rotations inside standard regional clinics under medical supervision.</p>
              </div>
              <div className="p-3 bg-emerald-900/60 rounded-xl border border-emerald-800/40">
                <h4 className="font-extrabold text-white">2. Botanical Standardization (6 Months)</h4>
                <p className="text-[11px] text-emerald-300 mt-0.5">Laboratory rotations at the Center for Scientific Research into Plant Medicine (CSRPM) in Mampong-Akwapim.</p>
              </div>
            </div>
            <p className="text-[11px] text-amber-300 font-bold bg-[#fad432]/10 p-3 rounded-lg border border-[#fad432]/20">
              ✔ Following internship, candidates sit for the professional qualifying licensure exam conducted by the Traditional Medicine Practice Council (TMPC).
            </p>
          </div>

        </div>
      )}

      {subTab === 'requirements' && (
        <div className="bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-8 animate-fade-in" id="prog_requirements">
          <div className="space-y-2 border-b border-slate-100 pb-4">
            <h3 className="font-extrabold text-slate-850 text-base md:text-lg flex items-center gap-2">
              <span className="p-1 px-1.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase">Admission Benchmarks</span>
              Entrance Requirements for BSc. Herbal Medicine
            </h3>
            <p className="text-xs text-slate-500">Requirements apply to core Ghanaian secondary cohorts, certificate/mature applicants, and international students.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h4 className="font-extrabold text-slate-700 text-sm">A. WASSCE / SSSCE Senior High Applicants</h4>
              <p className="text-xs text-slate-550 leading-relaxed">
                Applicants must obtain passes (A1-C6 / A-D) in three (3) core subjects: Core Mathematics, English Language, and Integrated Science, plus credits in three (3) elective science blocks:
              </p>
              <ul className="space-y-2 text-xs text-slate-650 font-semibold pl-4 list-disc">
                <li>Chemistry (Essential)</li>
                <li>Biology (Essential)</li>
                <li>Physics or Elective Mathematics</li>
              </ul>
              <em className="text-[11px] text-amber-800 block">Note: An overall aggregate score of 24 (SSSCE) or 36 (WASSCE) or better is required.</em>
            </div>

            <div className="space-y-4 border-t md:border-t-0 md:border-l border-slate-150 pt-4 md:pt-0 md:pl-8">
              <h4 className="font-extrabold text-slate-700 text-sm">B. Diploma & Secondary Practitioner Applicants</h4>
              <p className="text-xs text-slate-550 leading-relaxed">
                Holders of accredited Dispensing Technology Diplomas, Medical Laboratory Diplomas, or approved Advanced Certificates in Herbal Technology from recognized institutes are eligible for direct admission.
              </p>
              <ul className="space-y-2 text-xs text-slate-650 font-semibold pl-4 list-disc">
                <li>Must have completed a minimum of two (2) years post-diploma work.</li>
                <li>Must pass a departmental placement selection interview.</li>
                <li>Admission may be credited straight into Second Year (Level 200).</li>
              </ul>
            </div>

            <div className="space-y-4 border-t border-slate-150 pt-6">
              <h4 className="font-extrabold text-slate-700 text-sm">C. Mature Students Route</h4>
              <p className="text-xs text-slate-550 leading-relaxed">
                Aged 25 years or above at the period of submitting applications. Must show a relevant working medical background or active lineage traditional practice portfolio.
              </p>
              <ul className="space-y-2 text-xs text-slate-650 font-semibold pl-4 list-disc">
                <li>Must compile and present evidence of practical phytotherapy work.</li>
                <li>Must sit for and pass the KNUST Mature Entrance Examinations in General Science and English.</li>
              </ul>
            </div>

            <div className="space-y-4 border-t border-slate-150 pt-6 md:pl-8">
              <h4 className="font-extrabold text-slate-700 text-sm">D. GCE Advanced Level & International Certificates</h4>
              <p className="text-xs text-slate-550 leading-relaxed">
                Standard UK Advanced Level, International Baccalaureate (IB), or equivalent Francophone BAC certifications.
              </p>
              <ul className="space-y-2 text-xs text-slate-650 font-semibold pl-4 list-disc">
                <li>Requires 3 credits in GCE Advanced level Chemistry, Biology, and Physics.</li>
                <li>English translation equivalent certifications must be verified by the Ghana Tertiary Education Commission (GTEC).</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {subTab === 'curriculum' && (
        <div className="space-y-6 animate-fade-in" id="prog_curriculum">
          <div className="text-center space-y-1">
            <span className="text-[10px] text-emerald-800 uppercase font-black tracking-widest block">Yearly Syllabus Mapping</span>
            <h3 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight">Structured Layout (Level 100 to 400)</h3>
            <p className="text-xs text-slate-500 max-w-lg mx-auto">Explore the detailed lists of modules covering foundational medical sciences, botanical chemistry, advanced toxicology, and direct clinical practice.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {([100, 200, 300, 400] as const).map((level) => (
              <div key={level} className="bg-white rounded-3xl border border-slate-150 p-6 space-y-4 shadow-sm hover:border-emerald-300 transition-all">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="p-1 px-2 rounded bg-emerald-800 text-white font-mono font-black text-xs">L {level}</span>
                    <h4 className="font-extrabold text-slate-800 text-sm hover:text-emerald-850">Year {level/100} Syllabus</h4>
                  </div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">{COURSES_BY_LEVEL[level]?.length || 0} Core Courses</span>
                </div>

                <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto pr-1 space-y-2.5">
                  {(COURSES_BY_LEVEL[level] || []).map((course, idx) => (
                    <div key={course.code} className="pt-2.5 first:pt-0 space-y-1">
                      <div className="flex items-start justify-between gap-2.5">
                        <span className="font-mono text-[10px] font-black text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded shrink-0">{course.code}</span>
                        <h5 className="font-bold text-slate-800 text-xs text-left flex-1 leading-tight">{course.name}</h5>
                        <span className="text-[10px] font-mono text-slate-400 shrink-0 font-bold">{course.credits} Cr</span>
                      </div>
                      <p className="text-[10.5px] text-slate-500 leading-normal pl-0.5">{course.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {subTab === 'clinicals' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in" id="prog_clinicals">
          
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-5">
              <h3 className="font-extrabold text-slate-850 text-base flex items-center gap-2">
                <span className="p-1 px-1.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase">Practical Exposure</span>
                Clinical Training & Rotations
              </h3>
              <p className="text-xs text-slate-650 leading-relaxed">
                Theoretical knowledge of botany is rendered useless without practical healing applications. Our curriculum mandates highly regulated clinical postings across selected partner institutions:
              </p>

              <div className="space-y-4 pt-2">
                <div className="flex gap-3">
                  <div className="p-2 bg-emerald-50 text-emerald-800 rounded-xl shrink-0 h-9 w-9 flex items-center justify-center">
                    <Calendar className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-xs leading-none">Level 200/300 Hospital Postings</h4>
                    <p className="text-xs text-slate-450 mt-1">Supervised training at the <strong>KNUST University Hospital</strong> and municipal clinical centers.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="p-2 bg-emerald-50 text-emerald-800 rounded-xl shrink-0 h-9 w-9 flex items-center justify-center">
                    <Users className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-xs leading-none">Level 400 Ward Rotations</h4>
                    <p className="text-xs text-slate-450 mt-1">Intensive pathology and patient therapeutics rotations inside standard surgical, medical, and pediatric wards under medical officers.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="p-2 bg-emerald-50 text-emerald-800 rounded-xl shrink-0 h-9 w-9 flex items-center justify-center">
                    <Network className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-xs leading-none">CSRPM Mampong Research Attachment</h4>
                    <p className="text-xs text-slate-450 mt-1">Direct attachment to the Center for Scientific Research into Plant Medicine to observe laboratory toxicity protocols.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-amber-400/5 border border-amber-300 rounded-2xl p-4 flex gap-3">
              <span className="text-2xl">💡</span>
              <p className="text-xs text-amber-955 leading-relaxed font-semibold">
                Students are actively graded on patient case-clerking, diagnostic analytical reports, and botanical formulation stability journals compiled during clinical periods.
              </p>
            </div>
          </div>

          <div className="lg:col-span-6 bg-slate-900 text-slate-100 rounded-3xl p-6 md:p-8 space-y-6">
            <h3 className="text-white font-extrabold text-base leading-tight">Career Opportunities after Graduation</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Upon receiving standard registration from the Traditional Medicine Practice Council (TMPC), our graduates enter a rich and expanding job market across multiple professional sectors:
            </p>

            <div className="space-y-4.5 pt-2">
              <div className="border-l-2 border-emerald-500 pl-3 space-y-1">
                <h4 className="text-white font-extrabold text-xs uppercase tracking-wide">1. National Health Centers (GHS)</h4>
                <p className="text-xs text-slate-400">Practicing as fully salaried <strong>Medical Herbalists</strong> inside designated Herbal Units of Government regional/district hospitals.</p>
              </div>

              <div className="border-l-2 border-emerald-500 pl-3 space-y-1">
                <h4 className="text-white font-extrabold text-xs uppercase tracking-wide">2. Regulatory & Quality Control (FDA/GSA)</h4>
                <p className="text-xs text-slate-400">Working as expert evaluators in the <strong>Ghana Food and Drugs Authority (FDA)</strong> or Ghana Standards Authority (GSA) to audit phytoremedy registration applications.</p>
              </div>

              <div className="border-l-2 border-emerald-500 pl-3 space-y-1">
                <h4 className="text-white font-extrabold text-xs uppercase tracking-wide">3. Pharmaceutical Manufacturing R&D</h4>
                <p className="text-xs text-slate-400">Formulating active botanicals, stabilizing decoctions, and managing natural cosmetics/supplement research lines.</p>
              </div>

              <div className="border-l-2 border-emerald-500 pl-3 space-y-1">
                <h4 className="text-white font-extrabold text-xs uppercase tracking-wide">4. Academic & Research Consults</h4>
                <p className="text-xs text-slate-400">Purdue postgraduate courses in phytochemistry, pharmacology, or clinical toxicologies, lecturing in state and private medical colleges.</p>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
