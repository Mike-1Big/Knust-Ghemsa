import React, { useState, useRef, useEffect } from 'react';
import { Bot, User, Send, HelpCircle, FileText, ChevronRight, Sparkles, RefreshCw, Cpu } from 'lucide-react';

interface ChatMessage {
  sender: 'ai' | 'user';
  text: string;
  source?: string;
}

export default function AdvisorChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: "Hello! I am the KNUST Department of Herbal Medicine Virtual Assistant. How may I assist you today? Feel free to select any of the common topics below or type your questions about admissions, courses, clinical training, fees, and career prospects.",
      source: 'Direct Department Handbook v2.0'
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    document.title = "FAQ & AI Chatbot | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const knowledgeBase: Record<string, { answer: string; source: string }> = {
    admissions: {
      answer: "For WASSCE/SSSCE applicants, you need passes in English, Core Maths, and Integrated Science, plus Chemistry, Biology, and Physics electives, with an aggregate score under 36 (WASSCE). Dipoma/Mature applicants may also apply and attend a placement selection interview.",
      source: 'BSc Admissions Catalog Section 2.1'
    },
    courses: {
      answer: "The program spans 4 levels (100 to 400). You begin with core sciences and plant sciences in Level 100/200, advance to Phytochemistry and clinical pharmacology in Level 300, and complete your thesis alongside active clinical therapeutics in Level 400.",
      source: 'Syllabus and Credit Curriculum Matrix 2026'
    },
    fees: {
      answer: "Ghanaian undergraduate fees range between GHS 3,500 and GHS 5,200 per academic year. International student fees are approximately USD 2,800 annually. Scholarship assistance through GETFund and Mastercard is available for qualified applicants.",
      source: 'KNUST Academic Registrar Bulletin 2025'
    },
    accommodation: {
      answer: "On-campus undergraduate residential options include Independence Hall, Republic Hall, and Queen Elizabeth II Hall. Private student hostels with standard facilities are located next to our botanical gardens inside Kotei and Ayeduase.",
      source: 'Office of the Dean of Students Accommodation Board'
    },
    research: {
      answer: "Undergraduates can collaborate on ongoing research projects led by senior faculty members inside our Phytochemistry Discovery Lab. Top Level 400 researchers frequently receive sponsored assistant roles funded by the WHO taskforce.",
      source: 'Office of Scientific and Industrial Research Hub'
    },
    clinical: {
      answer: 'Our professional clinical rotations are hosted in coordination with the Komfo Anokye Teaching Hospital (KATH), KNUST University Hospital, municipal health units, and the Center for Scientific Research into Plant Medicine (CSRPM) in Mampong.',
      source: 'Clinical Supervision and Postings Bylaws'
    },
    careers: {
      answer: "Graduates register as licensed Medical Herbalists (MH) under the Traditional Medicine Council (TMPC). Key career placement sectors include Ghana Health Service (GHS) Hospital units, Food and Drugs Authority (FDA) evaluation desks, R&D labs, and private consultancies.",
      source: 'GHS Allied Professions Policy Manual page 12'
    },
    graduation: {
      answer: "To graduate, scholars must acquire a minimum of 125 credit hours over 4 academic years, attain a static CWA above 50.0%, submit a clinical rotational journal, and successfully defend a primary experimental dissertation thesis.",
      source: 'Section C - Academic Standards Bylaws, KNUST'
    },
    contacts: {
      answer: "You can reach our general secretariat directly at +233 (0) 32 206 0294, email herbal.pharm@knust.edu.gh, or call our student support hotline at +233 (0) 53 185 5909. Our offices are situated on the 1st Floor of the Faculty of Pharmacy building.",
      source: 'Departmental Communication Directory'
    }
  };

  const presetChips = [
    { label: '📦 Admission Criteria?', key: 'admissions' },
    { label: '📚 Course Outlines?', key: 'courses' },
    { label: '💰 Tuition & Fees?', key: 'fees' },
    { label: '🏥 Clinical Placements?', key: 'clinical' },
    { label: '🎓 Career Prospects?', key: 'careers' },
    { label: '🏆 Graduation Thresholds?', key: 'graduation' },
  ];

  // Auto scroll down chats
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const triggerResponse = (key: string) => {
    const records = knowledgeBase[key];
    if (records) {
      setMessages((prev) => [...prev, { sender: 'ai', text: records.answer, source: records.source }]);
    } else {
      setMessages((prev) => [...prev, { 
        sender: 'ai', 
        text: "I want to be sure I give you precise registrar details. I understand questions regarding 'admissions', 'courses', 'fees', 'accommodation', 'research', 'clinical training', 'graduation', 'career prospects', and 'contacts'. Could you select one of those core fields?", 
        source: 'AI Auxiliary Assistant' 
      }]);
    }
    setIsTyping(false);
  };

  const handleSend = (userText: string) => {
    if (!userText.trim()) return;

    setMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setInputVal('');
    setIsTyping(true);

    const checkedVal = userText.toLowerCase().trim();

    setTimeout(() => {
      // Basic keyword parsing
      let matchedKey = '';
      if (checkedVal.includes('admiss') || checkedVal.includes('apply') || checkedVal.includes('require')) matchedKey = 'admissions';
      else if (checkedVal.includes('course') || checkedVal.includes('subject') || checkedVal.includes('syllabus') || checkedVal.includes('level')) matchedKey = 'courses';
      else if (checkedVal.includes('fee') || checkedVal.includes('cost') || checkedVal.includes('price') || checkedVal.includes('scholarship')) matchedKey = 'fees';
      else if (checkedVal.includes('room') || checkedVal.includes('hostel') || checkedVal.includes('accommod') || checkedVal.includes('hall')) matchedKey = 'accommodation';
      else if (checkedVal.includes('research') || checkedVal.includes('grant') || checkedVal.includes('project')) matchedKey = 'research';
      else if (checkedVal.includes('clinic') || checkedVal.includes('hospital') || checkedVal.includes('rotat') || checkedVal.includes('ward')) matchedKey = 'clinical';
      else if (checkedVal.includes('career') || checkedVal.includes('job') || checkedVal.includes('practice') || checkedVal.includes('employ')) matchedKey = 'careers';
      else if (checkedVal.includes('gradu') || checkedVal.includes('cwa') || checkedVal.includes('thesis') || checkedVal.includes('credit')) matchedKey = 'graduation';
      else if (checkedVal.includes('contact') || checkedVal.includes('phone') || checkedVal.includes('email') || checkedVal.includes('call')) matchedKey = 'contacts';

      triggerResponse(matchedKey);
    }, 750);
  };

  const triggerPreset = (key: string, label: string) => {
    setMessages((prev) => [...prev, { sender: 'user', text: label }]);
    setIsTyping(true);

    setTimeout(() => {
      triggerResponse(key);
    }, 600);
  };

  return (
    <div className="space-y-8 animate-fade-in" id="chatbot_root_screen">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium font-sans">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Chatbot View)</span>
        <strong className="text-slate-700">Title:</strong> FAQs & Interactive Virtual Assistant | KNUST Herbal Medicine<br />
        <strong className="text-slate-700">Description:</strong> Consult our virtual advisor on admissions criteria, student accommodations, program tuition costs, and postgraduate hospital career routes in Ghana.
      </div>

      {/* Header section */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block font-mono">Interactive Support Assistant</span>
        <h1 className="text-xl sm:text-3xl font-extrabold text-slate-800 tracking-tight leading-none">
          Live AI Advisor & Knowledge Base
        </h1>
        <p className="text-xs text-slate-500 max-w-2xl leading-normal">
          Query our compiled Knowledge Base instantly. Our Virtual Assistant uses validated guidelines to answer common student inquiries.
        </p>
      </div>

      {/* CHATBOT SCREEN FRAME */}
      <div className="bg-white rounded-3xl border border-slate-150 overflow-hidden flex flex-col h-[520px] shadow-sm max-w-4xl mx-auto" id="terminal_chatbot">
        
        {/* Chatbot top header line */}
        <div className="bg-[#09150e] p-4 text-white flex items-center justify-between border-b border-emerald-950 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-emerald-500 text-emerald-950 shadow-md">
              <Bot className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="text-xs font-black block tracking-wide">KNUST Virtual Department Advisor</span>
              <span className="text-[8px] uppercase tracking-widest text-emerald-400 block font-black leading-none">Knowledge Base v2.0 Active</span>
            </div>
          </div>
          
          <button 
            onClick={() => setMessages([{ sender: 'ai', text: "Hello! I am the KNUST Department of Herbal Medicine Virtual Assistant. How may I assist you today? Feel free to select any of the common topics below or type your questions about admissions, courses, clinical training, fees, and career prospects.", source: 'Direct Department Handbook v2.0' }])}
            className="text-[10px] border border-emerald-800 font-extrabold text-emerald-400 hover:text-white hover:bg-emerald-900/40 px-2 py-1 rounded transition-all flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="h-3 w-3" /> Clear Sessions
          </button>
        </div>

        {/* CHAT MESSAGES STREAM */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4.5 bg-slate-50/40">
          {messages.map((msg, index) => {
            const isUser = msg.sender === 'user';
            return (
              <div 
                key={index} 
                className={`flex gap-3 max-w-[85%] ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
              >
                {/* Visual Avatar */}
                <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 border ${
                  isUser 
                    ? 'bg-amber-400 text-slate-900 border-amber-500 shadow-sm' 
                    : 'bg-[#09150e] text-emerald-300 border-emerald-950'
                }`}>
                  {isUser ? <User className="h-4.5 w-4.5 stroke-2" /> : <Bot className="h-4.5 w-4.5" />}
                </div>

                {/* Message Body Bubble */}
                <div className="space-y-1.5 text-left">
                  <div className={`rounded-2xl p-4.5 text-xs font-semibold leading-relaxed shadow-sm ${
                    isUser 
                      ? 'bg-amber-400 text-slate-900 rounded-tr-none' 
                      : 'bg-white text-slate-750 border border-slate-150 rounded-tl-none'
                  }`}>
                    {msg.text}
                  </div>
                  
                  {/* Sources Verification Tag */}
                  {!isUser && msg.source && (
                    <span className="text-[10px] text-slate-450 font-mono font-black italic block pl-1">
                      📚 Source Ref: {msg.source}
                    </span>
                  )}
                </div>
              </div>
            );
          })}

          {/* SIMULATED TYPING INDICATOR */}
          {isTyping && (
            <div className="flex gap-3 mr-auto items-center animate-pulse">
              <div className="h-8 w-8 rounded-full bg-[#09150e] text-emerald-300 border border-emerald-950 flex items-center justify-center shrink-0">
                <Bot className="h-4.5 w-4.5" />
              </div>
              <div className="bg-white rounded-2xl px-4 py-2.5 text-slate-400 text-[11px] font-bold border border-slate-150 rounded-tl-none flex items-center gap-1">
                <span>Advisor thinking</span>
                <span className="animate-bounce">.</span>
                <span className="animate-bounce delay-100">.</span>
                <span className="animate-bounce delay-200">.</span>
              </div>
            </div>
          )}
          
          <div ref={scrollRef}></div>
        </div>

        {/* QUICK SUGGESTION CHIPS SCROLL ROW */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-150 flex gap-2 overflow-x-auto select-none shrink-0" id="quick_chatbot_presets">
          {presetChips.map((chip) => (
            <button
              key={chip.key}
              onClick={() => triggerPreset(chip.key, chip.label)}
              className="bg-white hover:bg-emerald-50 text-slate-655 hover:text-emerald-950 border border-slate-200 hover:border-emerald-300 font-extrabold text-[10px] tracking-tight px-3 py-1.5 rounded-full shrink-0 transition-all cursor-pointer shadow-sm"
            >
              {chip.label}
            </button>
          ))}
        </div>

        {/* MANUAL INPUT BAR */}
        <div className="p-3 bg-white border-t border-slate-150 flex gap-3 items-center shrink-0">
          <input 
            type="text"
            placeholder="Query about admissions, fees, courses, clinicals, accommodation, careers..."
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend(inputVal)}
            className="flex-1 bg-slate-50 border border-slate-205 rounded-xl px-4 py-3 text-xs outline-none focus:border-emerald-750 transition-all font-semibold"
          />
          <button 
            onClick={() => handleSend(inputVal)}
            className="p-3 bg-emerald-850 hover:bg-emerald-900 border border-emerald-950 rounded-xl text-white transition-all cursor-pointer"
          >
            <Send className="h-4.5 w-4.5" />
          </button>
        </div>

      </div>

    </div>
  );
}
