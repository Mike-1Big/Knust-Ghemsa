import React, { useState } from 'react';
import { Users, GraduationCap, Briefcase, Award, CheckCircle, ArrowRight, Sparkles, Building2, UserCheck, Heart } from 'lucide-react';

interface AlumniProfile {
  name: string;
  year: string;
  role: string;
  sector: string;
  story: string;
  accomplishment: string;
}

export default function AlumniNetwork() {
  const [registered, setRegistered] = useState(false);
  const [formData, setFormData] = useState({
    fullname: '',
    email: '',
    phone: '',
    gradYear: '2020',
    employment: '',
    verified: false,
  });

  React.useEffect(() => {
    document.title = "Alumni Network | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const sectors = [
    { name: 'Ghana Health Service (GHS) Wards', percentage: '45%' },
    { name: 'Regulatory Affairs (FDA / Standards Authority)', percentage: '20%' },
    { name: 'Private Phytomedicine Clinics & Consultation', percentage: '18%' },
    { name: 'Research Centers & Postgraduate Studies', percentage: '12%' },
    { name: 'Natural Cosmetics & Supplement Manufacturing', percentage: '5%' }
  ];

  const alumniProfiles: AlumniProfile[] = [
    {
      name: 'Dr. Emmanuel Kusi, MH',
      year: 'Class of 2008',
      role: 'Senior Medical Herbalist & Lead Clinician',
      sector: 'Ghana Health Service - Koforidua Regional Hospital',
      story: 'Emmanuel was one of our pioneer graduates. Starting as an assistant intern, he oversaw the official integration of the local Herbal Unit within the Koforidua Regional Hospital. He manages patient clerking, botanical prescription dispensing, and clinical pharmacology consultations.',
      accomplishment: 'Successfully registered and treated over 15,000 chronic hepatitis and hypertension patients utilizing standardized protocols.'
    },
    {
      name: 'Dr. Theresa Mensah, MH',
      year: 'Class of 2014',
      role: 'Director of Botanical Quality Control',
      sector: 'Phytodyne Pharmaceuticals & Natural Cosmetics Ltd',
      story: 'Theresa pursued her master’s in Phytopharmaceutics immediately after graduation. She holds standard patents for stabilizing Lippia multiflora tea against rapid biological mold decay.',
      accomplishment: 'Authored three standard industry SOPs regulating raw raw material sanitization guidelines used by cosmetic companies in West Africa.'
    },
    {
      name: 'Dr. George Appiah-Kubi, MH',
      year: 'Class of 2018',
      role: 'Regulatory Evaluation Lead (Herbal Medicine Unit)',
      sector: 'Ghana Food and Drugs Authority (FDA)',
      story: 'George evaluates therapeutic safety applications. His work ensures that only certified botanical formulations containing verified toxicity reports make it to retail market shelves.',
      accomplishment: 'Drafted the 2023 National Regulatory Guidelines on Microbial Tolerance in commercial food and plant supplements.'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.fullname && formData.email) {
      setRegistered(true);
    }
  };

  return (
    <div className="space-y-12 animate-fade-in" id="alumni_network_root">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Alumni View)</span>
        <strong className="text-slate-700">Title:</strong> Alumni Careers & success Stories | KNUST Herbal Medicine<br />
        <strong className="text-slate-700">Description:</strong> Browse outstanding placements of our licensed medical herbalists across GHS hospital units and the Ghana FDA. Join our official graduate registry portal.
      </div>

      {/* Header section */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block font-mono">Licensed Medical Herbalists Network</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Our Global Alumni Circle
        </h1>
        <p className="text-xs sm:text-base text-slate-505 max-w-3xl leading-relaxed">
          Over 350+ medical herbalists trained in our department are actively deployed across state medical units, regulatory committees, academic faculties, and leading pharmaceutical companies.
        </p>
      </div>

      {/* SECTORS STATISTIC OVERVIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Industry percentages */}
        <div className="lg:col-span-5 bg-gradient-to-br from-[#0c1c12] to-[#040a06] text-white rounded-3xl p-6 border border-emerald-950 space-y-5">
          <div>
            <span className="text-[10px] uppercase font-black text-emerald-450 tracking-wider">Employment Channels</span>
            <h3 className="text-white font-extrabold text-base md:text-lg">Where Our Alumni Practice</h3>
          </div>

          <div className="space-y-4 pt-2">
            {sectors.map((sector) => (
              <div key={sector.name} className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold text-emerald-100">
                  <span className="truncate max-w-[200px]">{sector.name}</span>
                  <span className="text-emerald-400 font-mono font-black">{sector.percentage}</span>
                </div>
                <div className="h-2 bg-emerald-950 rounded-full overflow-hidden border border-emerald-900">
                  <div className="h-full bg-emerald-400 rounded-full" style={{ width: sector.percentage }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mentorship panel */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-800 rounded-xl">
              <Users className="h-5 w-5" />
            </div>
            <h3 className="font-extrabold text-slate-800 text-sm md:text-base">Alumni Peer Mentorship Initiative</h3>
          </div>
          <p className="text-xs text-slate-550 leading-relaxed font-semibold">
            The department runs a structured <strong>Mentorship Scheme</strong> matching Level 400 clinical students with seasoned medical herbalists. During the final year rotation, scholars shadowing alumni learn standard ward round decorum, client case clerking, and regulatory registration parameters.
          </p>
          <div className="bg-[#fad432]/5 border border-[#fad432]/30 rounded-2xl p-4 flex gap-3 text-xs font-semibold text-[#5c4a16]">
            <span>⭐</span>
            <p className="leading-normal">
              Are you a senior practitioner interested in guiding current students? Register using our portal below and indicate your hospital location to be paired with local clinical interns.
            </p>
          </div>
        </div>

      </div>

      {/* SAMPLE SUCCESS STORIES COHORTS */}
      <div className="space-y-6 pt-4">
        <div>
          <span className="text-[10px] uppercase font-black text-amber-700 tracking-wider">Spotlights on Practice</span>
          <h3 className="font-extrabold text-slate-850 text-base md:text-lg">Alumni Career Showcases & Accomplishments</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {alumniProfiles.map((person) => (
            <div key={person.name} className="bg-white rounded-3xl border border-slate-150 p-6 flex flex-col justify-between space-y-4 shadow-sm hover:border-emerald-300 transition-all">
              <div className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-mono font-black text-emerald-855 bg-emerald-50 px-2 py-0.5 rounded">
                    {person.year}
                  </span>
                  <Award className="h-4.5 w-4.5 text-amber-500" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-extrabold text-slate-850 text-sm leading-tight">{person.name}</h4>
                  <p className="text-[10.5px] font-bold text-emerald-805 uppercase tracking-wide leading-none">{person.role}</p>
                </div>
                <p className="text-xs text-slate-505 leading-relaxed italic border-l-2 border-slate-150 pl-3">
                  "{person.story}"
                </p>
              </div>

              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 text-[11px] leading-relaxed">
                <strong className="text-slate-700 block font-bold uppercase text-[9px] tracking-wide mb-0.5">Core Career Achievement:</strong>
                <span className="text-slate-500 font-medium font-serif">{person.accomplishment}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* GRADUATE PORTAL REGISTRATION FORM */}
      <div className="bg-white rounded-3xl border border-slate-150 p-6 md:p-8 max-w-2xl mx-auto space-y-6">
        <div className="text-center space-y-1">
          <span className="p-1 px-2 rounded bg-emerald-50 text-emerald-800 text-[9px] font-black uppercase">Postgraduate Register</span>
          <h3 className="font-extrabold text-slate-850 text-base md:text-lg">Register in the Official KNUST Alumni Portal</h3>
          <p className="text-xs text-slate-450">Join our verified roster. Ensure prospective students and state agencies can lookup accredited practitioners.</p>
        </div>

        {registered ? (
          <div className="bg-emerald-50/50 border border-emerald-200 rounded-3xl p-6 text-center space-y-3 animate-fade-in">
            <div className="h-12 w-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto text-xl font-bold">✔</div>
            <h4 className="font-extrabold text-slate-800 text-sm">Application Received Successfully!</h4>
            <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
              Thank you, <strong>{formData.fullname}</strong>. Our departmental administration secretary will audit your registration metrics with the TMPC registration list and verify your profile.
            </p>
            <button 
              onClick={() => { setRegistered(false); setFormData({fullname:'', email:'', phone:'', gradYear:'2020', employment:'', verified:false}); }}
              className="text-xs font-black text-emerald-800 hover:underline"
            >
              Submit another registration
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Full Name (Inc MH designation)</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Dr. Frank Amoah, MH"
                  value={formData.fullname}
                  onChange={(e) => setFormData({...formData, fullname: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Professional Email Address</label>
                <input 
                  type="email" 
                  required
                  placeholder="e.g. frank.amoah@ghs.gov.gh"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Phone / WhatsApp Registration</label>
                <input 
                  type="text" 
                  placeholder="e.g. +233 (0) 24 123 4567"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Year of Graduation</label>
                <select 
                  value={formData.gradYear}
                  onChange={(e) => setFormData({...formData, gradYear: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-850"
                >
                  {['2025','2024','2023','2022','2021','2020','2018','2015','2010','2005'].map((yr) => (
                    <option key={yr} value={yr}>Class of {yr}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Current Employer & Ward/Room Placement</label>
              <input 
                type="text" 
                placeholder="e.g. Traditional Medicine Unit, Cape Coast Teaching Hospital"
                value={formData.employment}
                onChange={(e) => setFormData({...formData, employment: e.target.value})}
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
              />
            </div>

            <label className="flex items-start gap-2 pt-2 cursor-pointer select-none">
              <input 
                type="checkbox" 
                required
                checked={formData.verified}
                onChange={(e) => setFormData({...formData, verified: e.target.checked})}
                className="mt-0.5" 
              />
              <span className="text-[11px] text-slate-500 leading-normal">I confirm that I am a registered practicing Medical Herbalist under the Traditional Medicine Practice Council (TMPC) of Ghana, and authorize GHEMSA / KNUST to catalog my contacts.</span>
            </label>

            <button 
              type="submit"
              className="w-full py-3 bg-emerald-850 hover:bg-emerald-900 border border-emerald-950 text-white font-extrabold rounded-xl transition-all cursor-pointer text-xs"
            >
              Verify & Register Profile
            </button>
          </form>
        )}
      </div>

    </div>
  );
}
