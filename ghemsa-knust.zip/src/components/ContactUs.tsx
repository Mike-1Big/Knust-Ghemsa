import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageSquare, Clock, Globe, HelpCircle, CheckCircle, Smartphone } from 'lucide-react';

export default function ContactUs() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'Prospective Student',
    subject: '',
    message: '',
  });

  React.useEffect(() => {
    document.title = "Contact Us | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setSubmitted(true);
    }
  };

  return (
    <div className="space-y-12 animate-fade-in" id="contact_us_root">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-205 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Contact View)</span>
        <strong className="text-slate-700">Title:</strong> Contact Department of Herbal Medicine | KNUST Ghana Office<br />
        <strong className="text-slate-700">Description:</strong> Consult our registrar secretaries regarding admissions, tours of modern phytochem labs, or general herbal safety inquiries in Kumasi.
      </div>

      {/* Header section */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block font-mono">Office of Departmental Relations</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-none">
          Contact Our Admin Office
        </h1>
        <p className="text-xs sm:text-base text-slate-500 max-w-3xl leading-relaxed">
          Questions about admissions, clinical projects, or botanical reference parameters? Reach out directly via our physical desk, specialized email channels, or submit the contact form below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Direct Contacts & Addresses */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-gradient-to-br from-[#0c1c12] to-[#040a06] text-white rounded-3xl p-6 md:p-8 space-y-6 border border-emerald-950">
            <h3 className="font-extrabold text-white text-base">Physical HQ Location & Addresses</h3>
            
            <div className="space-y-4.5 text-xs text-emerald-100 font-semibold">
              <div className="flex gap-3">
                <MapPin className="h-5.5 w-5.5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-black mb-1">Office Address:</strong>
                  Department of Herbal Medicine,<br />
                  First Floor, Faculty of Pharmacy Building,<br />
                  Kwame Nkrumah University of Science & Technology,<br />
                  Kumasi, Ashanti Region, Ghana.
                </div>
              </div>

              <div className="border-t border-emerald-900/60 pt-4 flex gap-3">
                <Mail className="h-5.5 w-5.5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-black mb-1">Email Channels:</strong>
                  General Office: <a href="mailto:herbal.pharm@knust.edu.gh" className="text-amber-300 hover:underline">herbal.pharm@knust.edu.gh</a><br />
                  Admissions Direct: <a href="mailto:admissions.herbal@knust.edu.gh" className="text-amber-300 hover:underline">admissions.herbal@knust.edu.gh</a><br />
                  Research & Grants: <a href="mailto:research.herbal@knust.edu.gh" className="text-amber-300 hover:underline">research.herbal@knust.edu.gh</a>
                </div>
              </div>

              <div className="border-t border-emerald-900/60 pt-4 flex gap-3">
                <Phone className="h-5.5 w-5.5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-black mb-1">Telephones:</strong>
                  Front Reception: +233 (0) 32 206 0294<br />
                  Assistance Hotline: <a href="tel:0531855909" className="text-amber-300 hover:underline font-extrabold">+233 (0) 53 185 5909</a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-150 p-6 space-y-4 shadow-sm">
            <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 uppercase tracking-wide">
              <Clock className="h-4.5 w-4.5 text-emerald-800" /> Administrative Operating Hours
            </h4>
            <div className="divide-y divide-slate-100 text-xs text-slate-500 font-semibold space-y-2">
              <div className="pt-2 first:pt-0 flex justify-between">
                <span>Monday - Friday</span>
                <span className="font-mono text-slate-700">08:00 AM - 04:30 PM (GMT)</span>
              </div>
              <div className="pt-2 flex justify-between">
                <span>Saturday - Sunday</span>
                <span className="text-amber-800 font-bold bg-amber-50 px-2 py-0.5 rounded">Offices Closed</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Interactive Contact Form & Simulated Map */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-6">
          <div className="space-y-1">
            <h3 className="font-extrabold text-slate-850 text-sm md:text-base">Submit an Official Inquiry</h3>
            <p className="text-xs text-slate-450">Complete the form below to register a general, research, or admission support inquiry.</p>
          </div>

          {submitted ? (
            <div className="bg-emerald-50/50 border border-emerald-250 rounded-3xl p-6 text-center space-y-4 animate-fade-in">
              <div className="h-12 w-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto text-xl font-bold">✔</div>
              <div>
                <h4 className="font-extrabold text-slate-800 text-sm">Inquiry Transmitted Successfully!</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed max-w-md mx-auto">
                  Thank you, <strong>{formData.name}</strong>. Your correspondence has been ticketed and routed with the <strong>{formData.role}</strong> registry. An administrative coordinator will follow up at <strong>{formData.email}</strong> within 48 business hours.
                </p>
              </div>
              <button 
                onClick={() => { setSubmitted(false); setFormData({name:'', email:'', role:'Prospective Student', subject:'', message:''}); }}
                className="text-xs font-black text-emerald-800 hover:underline"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Your Full Name</label>
                  <input 
                    type="text" 
                    required
                    placeholder="e.g. Samuel Adjei"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Your Email Address</label>
                  <input 
                    type="email" 
                    required
                    placeholder="e.g. sam.adjei@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full bg-white border border-slate-205 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Which best describes you?</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({...formData, role: e.target.value})}
                    className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                  >
                    <option>Prospective Student</option>
                    <option>Current Scholar</option>
                    <option>Licensed Practitioner / Alumnus</option>
                    <option>Researcher / Collaborative Agent</option>
                    <option>General Public / Patient Enquiry</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Subject of Inquiry</label>
                  <input 
                    type="text" 
                    required
                    placeholder="e.g. BSc Admissions requirements"
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                    className="w-full bg-white border border-slate-205 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-bold block uppercase tracking-wide text-[9px]">Your Detailed message</label>
                <textarea 
                  required
                  rows={4}
                  placeholder="Describe your inquiry in detail..."
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-800 resize-none font-sans"
                />
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-emerald-850 hover:bg-emerald-990 border border-emerald-950 text-white font-extrabold rounded-xl transition-all cursor-pointer text-xs flex items-center justify-center gap-2"
              >
                <Send className="h-3.5 w-3.5" /> Transmit Inquiries to Registrar
              </button>
            </form>
          )}

          {/* SIMULATED ACCESSIBLE INTERACTIVE MAP */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden text-center space-y-1.5" id="simulated_map_frame">
            <div className="aspect-video bg-emerald-50 relative flex flex-col items-center justify-center p-6 border-b border-slate-100">
              <span className="text-3xl">📍</span>
              <h4 className="font-extrabold text-slate-805 text-xs">Simulated KNUST Central Map Coordinates</h4>
              <p className="text-[10.5px] text-slate-400 leading-normal max-w-sm mt-0.5">Faculty of Pharmacy Building, opposite College of Science Library, KNUST Campus, Kumasi.</p>
              
              <div className="absolute bottom-3 left-3 bg-white border border-slate-200 rounded-xl px-3 py-1 font-mono text-[9px] font-bold text-slate-400 shadow-sm">
                Lat: 6.6745° N, Lon: -1.5716° W
              </div>
            </div>
            <p className="text-[10px] text-slate-400 font-bold">🗺 Open in Google Maps navigation is supported when live on-device.</p>
          </div>

        </div>

      </div>

    </div>
  );
}
