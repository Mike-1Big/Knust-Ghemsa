import React, { useState, useEffect } from 'react';
import { Sparkles, Award, ArrowLeft, RefreshCw, CheckCircle, XCircle, ChevronRight, HelpCircle, BookOpen, Layers, Check, AlertCircle, Loader2, BrainCircuit } from 'lucide-react';
import { getApiUrl } from '../utils/api';

interface RevisionMaterial {
  id: string;
  title: string;
  type: string;
  description: string;
  level: number;
  courseCode: string;
  courseName: string;
}

interface CurriculumRevisionProps {
  material: RevisionMaterial;
  onClose: () => void;
}

interface MCQQuestion {
  question: string;
  options: string[];
  correct: string;
  explanation: string;
}

interface Flashcard {
  front: string;
  back: string;
  details?: string;
}

// Pre-seeded curriculum-mapped fallbacks in case network is down or API limits are hit, ensuring a bulletproof experience!
const OFFLINE_CURRICULUM_DB: Record<string, { mcq: MCQQuestion[]; flashcards: Flashcard[] }> = {
  'HRM 151': {
    mcq: [
      {
        question: "Which botanical classification system is primarily used at KNUST and emphasizes phylogenetic relationships based on genetic evidence?",
        options: ["Linnaean Artificial System", "Bentham and Hooker System", "Angiosperm Phylogeny Group (APG) System", "Engler and Prantl System"],
        correct: "Angiosperm Phylogeny Group (APG) System",
        explanation: "The APG system is a modern, molecular-based classification system for flowering plants that represents the gold standard in contemporary academic ethnobotany."
      },
      {
        question: "Under the ICN nomenclatural hierarchy, which suffix is mandatory for a plant Order taxonomic rank?",
        options: ["-iales", "-ales", "-aceae", "-ideae"],
        correct: "-ales",
        explanation: "The suffix -ales denotes an Order rank (e.g., Gentianales), whereas -aceae is for Families and -ideae is for Subfamilies."
      },
      {
        question: "When applying a diagnostic leaf key, which term defines a margin containing sharp teeth pointing straight outward at a right angle?",
        options: ["Serrate margin", "Dentate margin", "Crenate margin", "Entire margin"],
        correct: "Dentate margin",
        explanation: "Dentate leaves have teeth that point directly outward. Serrate leaves have teeth pointing forward like a saw, and crenate leaves have rounded teeth."
      }
    ],
    flashcards: [
      {
        front: "What is binomial nomenclature?",
        back: "A two-part naming convention for species established by Carl Linnaeus, composed of the Genus name (capitalized) and the specific epithet (lowercase), both italicized.",
        details: "Example: Cryptolepis sanguinolenta. This format prevents taxonomic confusion across regional dialects."
      },
      {
        front: "Define the difference between 'Holotype' and 'Isotype'.",
        back: "A Holotype is the single physical specimen designated by the original author as the nomenclatural type of a species. An Isotype is any duplicate specimen of the holotype collected at the same time.",
        details: "Stored in academic Herbaria (like the KNUST Department of Herbal Medicine Herbarium) for standard clinical reference."
      }
    ]
  },
  'HRM 251': {
    mcq: [
      {
        question: "In microscopic pharmacognosy, which diagnostic crystal type is formed by calcium oxalate in the leaf tissues of West African Senna (Senna alata)?",
        options: ["Acicular needles", "Prismatic single crystals", "Micro-sphenoidal sand", "Rosette aggregates"],
        correct: "Prismatic single crystals",
        explanation: "Senna species prominently exhibit distinct solitary prismatic crystals of calcium oxalate bordering the vascular bundles, serving as an adulteration detector."
      },
      {
        question: "Symmetric, ranunculaceous (anomocytic) stomata are characterized by which spatial cell relationship?",
        options: [
          "Surrounded by a limited number of cells indistinguishable from other epidermal cells",
          "Flanked on each side by two subsidiary cells with parallel axes",
          "Surrounded by a ring of repeating radiating cells",
          "Guarded by subsidiary cells oriented at perpendicular right angles"
        ],
        correct: "Surrounded by a limited number of cells indistinguishable from other epidermal cells",
        explanation: "Anomocytic (ranunculaceous) stomata possess guard cells enclosed by epidermal cells that cannot be differentiated from surrounding cell structures."
      }
    ],
    flashcards: [
      {
        front: "What is the specific reagent used to identify lignified cells?",
        back: "Phloroglucinol + Concentrated Hydrochloric Acid (HCl). Highly selective.",
        details: "Lignified structures like sclerenchyma or stone cells turn intense cherry-red, indicating the presence of woody supportive elements."
      },
      {
        front: "What parameter does the 'Stomatal Index' represent?",
        back: "The percentage which the number of stomata forms relative to the total number of epidermal cells plus stomata on a specified unit leaf surface area.",
        details: "Formula: SI = (S * 100) / (E + S). It remains highly constant for a given species and is used for drug evaluation."
      }
    ]
  },
  'HRM 353': {
    mcq: [
      {
        question: "What is the clinical rationale for administering Cryptolepis sanguinolenta (Nibima) for uncomplicated malaria over classic Artemisinin combination options in rural Ghana?",
        options: [
          "Complete lack of any clinical side-effects",
          "Cryptolepine intercalates DNA and breaks systemic fevers without inducing immediate plasmodial resistance",
          "It acts as a nutritional blood builder raising iron count",
          "It is completely water-soluble and does not require brewing"
        ],
        correct: "Cryptolepine intercalates DNA and breaks systemic fevers without inducing immediate plasmodial resistance",
        explanation: "Cryptolepine has multiple synergistic actions: it intercalates DNA, inhibits beta-hematin crystallization, and acts as an anti-inflammatory, slowing resistance evolution."
      }
    ],
    flashcards: [
      {
        front: "What is the primary therapeutic marker of Cryptolepis sanguinolenta?",
        back: "Cryptolepine, an indoloquinoline alkaloid stored in the yellow roots.",
        details: "Standardized for anti-plasmodial, anti-inflammatory, and antimicrobial therapies in West Africa."
      },
      {
        front: "Why is Symphytum officinale contraindicated in clinical phytotherapy?",
        back: "Due to the presence of hepatotoxic Pyrrolizidine Alkaloids (PAs) which cause Hepatic Veno-Occlusive Disease (HVOD).",
        details: "Causes progressive liver cirrhosis and DNA damage over prolonged dosage levels."
      }
    ]
  },
  'default': {
    mcq: [
      {
        question: "In clinical herbal medicine, which parameter is primary in verifying the quality of a crude drug consignment?",
        options: ["The retail price and packaging label", "Organoleptic, microscopic, and chemical chromatographic assays", "The geographic location of the forest collection", "The total shelf age of the dried roots"],
        correct: "Organoleptic, microscopic, and chemical chromatographic assays",
        explanation: "These tripartite standard tests verify authenticity, exclude adulteration, and confirm the active metabolite density."
      },
      {
        question: "An aglycone moiety of a plant secondary biomarker represents which biochemical segment?",
        options: ["The non-sugar therapeutic carrier skeleton", "The active sugar ring segment", "A starch-binding amino chain", "The water-soluble side radical"],
        correct: "The non-sugar therapeutic carrier skeleton",
        explanation: "In glycosides, the aglycone (or genin) is the non-sugar portion, representing the core bioactivity mechanism."
      }
    ],
    flashcards: [
      {
        front: "What is active-recall study in herbal pharmacognosy?",
        back: "Testing yourself on botanical parameters, diagnostic chemical stains, and safe clinical guidelines, rather than passively highlighting text.",
        details: "Proven to boost exam retention rates by up to 150% in clinical science curricula."
      }
    ]
  }
};

export default function CurriculumRevision({ material, onClose }: CurriculumRevisionProps) {
  const [revisionMode, setRevisionMode] = useState<'select' | 'mcq' | 'flashcards'>('select');
  const [loading, setLoading] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);
  
  // Interactive States
  const [questions, setQuestions] = useState<MCQQuestion[]>([]);
  const [flashcardDeck, setFlashcardDeck] = useState<Flashcard[]>([]);
  
  // MCQ state
  const [currentMCOIndex, setCurrentMCQIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [scoreCount, setScoreCount] = useState(0);
  const [answeredMap, setAnsweredMap] = useState<Record<number, { chosen: string; isCorrect: boolean }>>({});

  // Flashcards state
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [masteredCards, setMasteredCards] = useState<Record<number, 'mastered' | 'practice'>>({});

  // Helpful status loading message rotator
  const [loadingTicker, setLoadingTicker] = useState('Parsing botanical terminology...');

  useEffect(() => {
    if (loading) {
      const messages = [
        'Parsing botanical nomenclature...',
        'Cross-referencing KNUST syllabus standards...',
        'Extracting phytochemical pathways...',
        'Structuring molecular active-recall triggers...',
        'Drafting pharmacognosy-aligned diagnostic parameters...'
      ];
      let idx = 0;
      const interval = setInterval(() => {
        idx = (idx + 1) % messages.length;
        setLoadingTicker(messages[idx]);
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [loading]);

  const handleStartRevision = async (mode: 'mcq' | 'flashcards') => {
    setLoading(true);
    setErrorStatus(null);
    setRevisionMode(mode);

    // Prompt formulating structured, high-quality revision variables
    const prompt = `Formulate clinical study revision tools for my university herbal medicine curriculum.
Subject details:
Course: ${material.courseCode} - ${material.courseName}
Level: KNUST Level ${material.level} Essential Core
Topic: ${material.title}
Resource Summary: ${material.description}

Requested Mode: ${mode.toUpperCase()}

If Mode is MCQ:
Directly output a raw JSON array of exactly 5 multiple choice questions. Do not write markdown wrappers like \`\`\`json. Output ONLY the raw JSON format so it can be parsed by JSON.parse().
Each question object MUST follow this TypeScript structure exactly:
{
  "question": "Clear clinical or botanical question text",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "correct": "Exact correct option text matches one of the options",
  "explanation": "Scientific explanation linking botanical features, molecular markers, or therapeutics"
}

If Mode is FLASHCARDS:
Directly output a raw JSON array of exactly 5 revision active-recall card decks. Do not write markdown. Output ONLY raw JSON.
Each object structure MUST follow this:
{
  "front": "Diagnostic chemical test or botanical question",
  "back": "Exact therapeutic botanical family, procedure or pharmacological rule",
  "details": "Clinical dosage warnings or related KNUST curriculum rules"
}`;

    try {
      const res = await fetch(getApiUrl('/api/gemini/generate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          context: `You are generating structured revision data for Level ${material.level} student. The course code is ${material.courseCode}.`
        })
      });

      if (!res.ok) {
        throw new Error('API server reported error. Utilizing offline pre-seeded system instead.');
      }

      const data = await res.json();
      const rawText = data.text;

      // Clean markdown block wrappers if model outputted them
      let cleaned = rawText.trim();
      if (cleaned.startsWith('```json')) {
        cleaned = cleaned.slice(7);
      } else if (cleaned.startsWith('```')) {
        cleaned = cleaned.slice(3);
      }
      if (cleaned.endsWith('```')) {
        cleaned = cleaned.slice(0, -3);
      }
      cleaned = cleaned.trim();

      const parsed = JSON.parse(cleaned);

      if (mode === 'mcq') {
        if (!Array.isArray(parsed) || parsed.length === 0 || !parsed[0].question) {
          throw new Error("Invalid structure returned");
        }
        setQuestions(parsed);
        setCurrentMCQIndex(0);
        setSelectedAnswer(null);
        setShowExplanation(false);
        setScoreCount(0);
        setAnsweredMap({});
      } else {
        if (!Array.isArray(parsed) || parsed.length === 0 || !parsed[0].front) {
          throw new Error("Invalid structure returned");
        }
        setFlashcardDeck(parsed);
        setCurrentCardIndex(0);
        setIsFlipped(false);
        setMasteredCards({});
      }
    } catch (err) {
      console.warn('AI Revision generator offline or timed out, loading offline custom curriculum bank:', err);
      // Fallback
      const courseCode = material.courseCode;
      const fallbackData = OFFLINE_CURRICULUM_DB[courseCode] || OFFLINE_CURRICULUM_DB['default'];
      
      if (mode === 'mcq') {
        setQuestions(fallbackData.mcq);
        setCurrentMCQIndex(0);
        setSelectedAnswer(null);
        setShowExplanation(false);
        setScoreCount(0);
        setAnsweredMap({});
      } else {
        setFlashcardDeck(fallbackData.flashcards);
        setCurrentCardIndex(0);
        setIsFlipped(false);
        setMasteredCards({});
      }
      setErrorStatus("Connected to Offline curriculum bank. (Local Mode Active)");
    } finally {
      setLoading(false);
    }
  };

  // MCQ Handlers
  const handleAnswerSelect = (option: string) => {
    if (answeredMap[currentMCOIndex]) return; // Stop re-answers
    setSelectedAnswer(option);
    const correctAns = questions[currentMCOIndex].correct;
    const isCorrect = option.trim().toLowerCase() === correctAns.trim().toLowerCase();

    if (isCorrect) {
      setScoreCount((prev) => prev + 1);
    }

    setAnsweredMap((prev) => ({
      ...prev,
      [currentMCOIndex]: { chosen: option, isCorrect }
    }));
    setShowExplanation(true);
  };

  const handleNextMCQ = () => {
    if (currentMCOIndex < questions.length - 1) {
      setCurrentMCQIndex((prev) => prev + 1);
      const nextAns = answeredMap[currentMCOIndex + 1];
      setSelectedAnswer(nextAns ? nextAns.chosen : null);
      setShowExplanation(!!nextAns);
    }
  };

  const handlePrevMCQ = () => {
    if (currentMCOIndex > 0) {
      setCurrentMCQIndex((prev) => prev - 1);
      const prevAns = answeredMap[currentMCOIndex - 1];
      setSelectedAnswer(prevAns ? prevAns.chosen : null);
      setShowExplanation(true);
    }
  };

  // Flashcards Handlers
  const handleMarkMastered = (status: 'mastered' | 'practice') => {
    setMasteredCards((prev) => ({ ...prev, [currentCardIndex]: status }));
    // Automatically advance with a short flip animation timeout
    setTimeout(() => {
      if (currentCardIndex < flashcardDeck.length - 1) {
        setIsFlipped(false);
        setCurrentCardIndex((prev) => prev + 1);
      }
    }, 450);
  };

  // Calculate mastery values
  const totalMastered = Object.values(masteredCards).filter((s) => s === 'mastered').length;
  const masteryPercentage = flashcardDeck.length > 0 
    ? Math.round((totalMastered / flashcardDeck.length) * 100) 
    : 0;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4" id="curriculum_revision_assistant">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header Branding */}
        <div className="bg-emerald-850 px-6 py-4 text-white flex items-center justify-between border-b border-emerald-900/40 shrink-0">
          <div className="flex items-center gap-2.5">
            <BrainCircuit className="h-6 w-6 text-teal-300 animate-pulse" />
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-teal-300">Curriculum Active Recall Lab</p>
              <h3 className="font-extrabold text-sm sm:text-base leading-tight truncate max-w-md">
                {material.courseCode}: {material.title}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full hover:bg-white/10 p-2 text-white/80 hover:text-white transition-colors cursor-pointer"
            title="Exit revision session"
          >
            ✕
          </button>
        </div>

        {/* Level Status & Offline notice bar */}
        <div className="bg-slate-50 px-6 py-2.5 border-b border-slate-100 flex flex-wrap items-center justify-between text-xs font-black text-slate-500 shrink-0 gap-2">
          <span className="bg-emerald-50 text-emerald-800 text-[10px] uppercase font-black tracking-wider px-2 py-0.5 rounded">
            KNUST Syllabus Level {material.level} Core
          </span>
          {errorStatus ? (
            <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded font-bold border border-amber-100 flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> {errorStatus}
            </span>
          ) : (
            <span className="text-emerald-700 font-extrabold flex items-center gap-1 text-[10px]">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span> Live AI Revision Synced
            </span>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {loading ? (
            /* Loading State */
            <div className="py-16 text-center space-y-4">
              <div className="relative w-16 h-16 mx-auto">
                <Loader2 className="w-16 h-16 animate-spin text-emerald-800" />
                <BrainCircuit className="w-6 h-6 text-teal-600 absolute inset-0 m-auto animate-pulse" />
              </div>
              <p className="text-sm font-extrabold text-slate-700">{loadingTicker}</p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Gemini is translating your study slide parameters into interactive, high-retention active recall prompts. Please hold on.
              </p>
            </div>
          ) : revisionMode === 'select' ? (
            /* Mode Selection Panel */
            <div className="space-y-6">
              <div className="text-center space-y-1">
                <h4 className="text-lg font-extrabold text-slate-800">Select Active Revision Strategy</h4>
                <p className="text-xs text-slate-500">Pick the cognitive learning technique mapped to this scientific paper.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* MCQ Mock Exam */}
                <button
                  onClick={() => handleStartRevision('mcq')}
                  className="border-2 border-slate-100 hover:border-emerald-700 hover:bg-emerald-50/10 p-6 rounded-2xl text-left bg-white transition-all space-y-3 cursor-pointer group"
                >
                  <div className="rounded-xl bg-violet-100 text-violet-800 p-3 w-fit group-hover:scale-110 transition-transform">
                    <HelpCircle className="h-6 w-6" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-slate-800 text-sm sm:text-base">Syllabus MCQ mock quiz</h5>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Generates 5 clinical questions aligned with your KNUST herbal curriculum to check your retention of botanical names, plant families, and diagnostic markers.
                    </p>
                  </div>
                </button>

                {/* Active Recall Flashcards */}
                <button
                  onClick={() => handleStartRevision('flashcards')}
                  className="border-2 border-slate-100 hover:border-emerald-700 hover:bg-emerald-50/10 p-6 rounded-2xl text-left bg-white transition-all space-y-3 cursor-pointer group"
                >
                  <div className="rounded-xl bg-teal-100 text-teal-800 p-3 w-fit group-hover:scale-110 transition-transform">
                    <Layers className="h-6 w-6" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-slate-800 text-sm sm:text-base">Active recall flashcards</h5>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      Generates dynamic digital revision cards. Flip to reveal scientific formulas, pharmacognostic parameters, clinical dosage rules, and contraindications.
                    </p>
                  </div>
                </button>
              </div>

              {/* Study Slide Overview */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                  <BookOpen className="h-4 w-4 text-emerald-800" />
                  <span>Interactive Slide Source Context</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed italic bg-white p-3 rounded-lg border border-slate-100">
                  "{material.description}"
                </p>
              </div>
            </div>
          ) : revisionMode === 'mcq' ? (
            /* MCQ Game Screen */
            <div className="space-y-6">
              {/* Score and Progress */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                  Question {currentMCOIndex + 1} of {questions.length}
                </span>
                <span className="text-xs font-black text-emerald-850 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                  Score: {scoreCount} / {Object.keys(answeredMap).length}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-800 transition-all duration-300"
                  style={{ width: `${((currentMCOIndex + 1) / questions.length) * 100}%` }}
                ></div>
              </div>

              {/* Question card */}
              <div className="space-y-4">
                <h4 className="text-sm sm:text-base font-extrabold text-slate-800 leading-snug">
                  {questions[currentMCOIndex]?.question}
                </h4>

                {/* Option buttons */}
                <div className="space-y-2.5">
                  {questions[currentMCOIndex]?.options.map((option, idx) => {
                    const optionLetters = ['A', 'B', 'C', 'D'];
                    const isSelected = selectedAnswer === option;
                    const isCorrectAnswer = option.trim().toLocaleLowerCase() === questions[currentMCOIndex].correct.trim().toLowerCase();
                    const hasBeenAnswered = answeredMap[currentMCOIndex] !== undefined;
                    const chosenByStudent = answeredMap[currentMCOIndex]?.chosen === option;

                    let buttonClass = "border border-slate-200 hover:bg-slate-50 bg-white hover:border-slate-300";
                    let iconNode = <span className="h-5 w-5 rounded-full border border-slate-300 flex items-center justify-center text-[10px] font-bold text-slate-400 group-hover:border-slate-400 shrink-0">{optionLetters[idx]}</span>;

                    if (hasBeenAnswered) {
                      if (isCorrectAnswer) {
                        buttonClass = "border-emerald-600 bg-emerald-50 border-2 font-bold text-emerald-900";
                        iconNode = <Check className="h-5 w-5 bg-emerald-700 text-white rounded-full p-0.5 shrink-0" />;
                      } else if (chosenByStudent) {
                        buttonClass = "border-rose-400 bg-rose-50 border-2 font-semibold text-rose-900";
                        iconNode = <XCircle className="h-5 w-5 text-rose-700 shrink-0" />;
                      } else {
                        buttonClass = "border-slate-100 bg-white opacity-45 cursor-not-allowed";
                        iconNode = <span className="h-5 w-5 rounded-full border border-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-300 shrink-0">{optionLetters[idx]}</span>;
                      }
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => handleAnswerSelect(option)}
                        disabled={hasBeenAnswered}
                        className={`w-full text-left p-3.5 rounded-xl text-xs sm:text-sm flex items-start gap-3 transition-all cursor-pointer group ${buttonClass}`}
                      >
                        {iconNode}
                        <span className="flex-1 leading-normal pt-0.5">{option}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Explanation section */}
              {showExplanation && (
                <div className="bg-emerald-50/45 border border-emerald-100 rounded-xl p-4 space-y-2 animate-fade-in">
                  <p className="text-[10px] font-black uppercase tracking-wider text-emerald-850 flex items-center gap-1">
                    <Award className="h-3.5 w-3.5" /> Scientific explanation
                  </p>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {questions[currentMCOIndex]?.explanation}
                  </p>
                </div>
              )}

              {/* Navigation buttons */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={handlePrevMCQ}
                  disabled={currentMCOIndex === 0}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 rounded-xl text-xs font-black text-slate-600 transition-all cursor-pointer"
                >
                  Previous
                </button>

                {currentMCOIndex === questions.length - 1 && answeredMap[currentMCOIndex] ? (
                  <button
                    onClick={() => {
                      setRevisionMode('select');
                      setQuestions([]);
                    }}
                    className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-black shadow-sm transition-all cursor-pointer"
                  >
                    Finish Revision Session
                  </button>
                ) : (
                  <button
                    onClick={handleNextMCQ}
                    disabled={!answeredMap[currentMCOIndex]}
                    className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white disabled:opacity-40 rounded-xl text-xs font-black shadow-sm transition-all flex items-center gap-1 cursor-pointer"
                  >
                    Next Question <ChevronRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Active Recall Flashcard Screen */
            <div className="space-y-6">
              {/* Tracker status */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 text-xs font-bold text-slate-500">
                <span>Card {currentCardIndex + 1} of {flashcardDeck.length}</span>
                <span className="bg-teal-50 text-teal-800 px-3 py-1 rounded-full font-black">
                  Mastered: {masteryPercentage}% ({totalMastered}/{flashcardDeck.length})
                </span>
              </div>

              {/* Card stage Flip area */}
              <div className="perspective-1000 w-full py-2">
                <div
                  onClick={() => setIsFlipped((prev) => !prev)}
                  className={`w-full min-h-[220px] rounded-3xl border-2 cursor-pointer shadow-sm relative transition-all duration-500 transform-style-3d ${
                    isFlipped
                      ? 'bg-teal-50/25 border-teal-300 rotate-y-180 shadow-md'
                      : 'bg-white hover:bg-slate-50 border-slate-100 hover:border-slate-200'
                  }`}
                  id="active_revision_flashcard_flipper"
                >
                  {!isFlipped ? (
                    /* Front side */
                    <div className="absolute inset-0 p-6 flex flex-col justify-between items-center text-center backface-hidden">
                      <span className="text-[9px] uppercase font-black tracking-widest text-slate-400">Question Side</span>
                      <p className="text-sm sm:text-base font-black text-slate-800 px-4 leading-relaxed my-auto">
                        {flashcardDeck[currentCardIndex]?.front}
                      </p>
                      <span className="text-[10px] font-extrabold text-teal-800 underline">Click Card to Flip</span>
                    </div>
                  ) : (
                    /* Back side */
                    <div className="absolute inset-0 p-6 flex flex-col justify-between items-center text-center rotate-y-180 backface-hidden">
                      <span className="text-[9px] uppercase font-black tracking-widest text-teal-700">Therapeutic Answer</span>
                      <div className="my-auto space-y-3 px-2">
                        <p className="text-sm sm:text-base font-extrabold text-teal-900 leading-relaxed">
                          {flashcardDeck[currentCardIndex]?.back}
                        </p>
                        {flashcardDeck[currentCardIndex]?.details && (
                          <p className="text-xs text-slate-500 bg-white/70 py-2 px-3 border border-slate-100 rounded-lg max-w-md mx-auto italic leading-normal">
                            {flashcardDeck[currentCardIndex]?.details}
                          </p>
                        )}
                      </div>
                      <span className="text-[10px] font-extrabold text-slate-400">Click to flip back</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Master / Review buttons when card has been flipped */}
              {isFlipped && (
                <div className="grid grid-cols-2 gap-3 animate-slide-in">
                  <button
                    onClick={() => handleMarkMastered('practice')}
                    className="rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-800 font-extrabold py-3 text-xs tracking-wide transition-colors cursor-pointer"
                  >
                    Need More Practice
                  </button>
                  <button
                    onClick={() => handleMarkMastered('mastered')}
                    className="rounded-xl bg-teal-800 hover:bg-teal-900 text-white font-extrabold py-3 text-xs tracking-wide shadow-sm transition-colors cursor-pointer"
                  >
                    Mastered / Know It!
                  </button>
                </div>
              )}

              {/* Navigation and completion controls */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => {
                    if (currentCardIndex > 0) {
                      setIsFlipped(false);
                      setCurrentCardIndex((prev) => prev - 1);
                    }
                  }}
                  disabled={currentCardIndex === 0}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 rounded-xl text-xs font-black text-slate-600 cursor-pointer"
                >
                  Previous Card
                </button>

                {currentCardIndex === flashcardDeck.length - 1 ? (
                  <button
                    onClick={() => {
                      setRevisionMode('select');
                      setFlashcardDeck([]);
                    }}
                    className="px-5 py-2 bg-emerald-800 hover:bg-emerald-950 text-white rounded-xl text-xs font-black shadow-sm cursor-pointer"
                  >
                    Complete Practice Session
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setIsFlipped(false);
                      setCurrentCardIndex((prev) => prev + 1);
                    }}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-black text-slate-600 flex items-center gap-1 cursor-pointer"
                  >
                    Skip Card <ChevronRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Support indicator */}
        <div className="bg-slate-50 p-4 border-t border-slate-100 flex items-center justify-between shrink-0 text-[10px] text-slate-400 font-bold uppercase">
          <span>GHEMSA Revision Engine v2.0</span>
          <span>KNUST College of Health Sciences</span>
        </div>
      </div>
    </div>
  );
}
