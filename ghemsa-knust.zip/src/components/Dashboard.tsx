import { useState, useEffect } from 'react';
import { BookOpen, Award, Sparkles, Sprout, ArrowRight, Library, GraduationCap, Calendar, Brain, Phone, Compass, CheckCircle2, User, HelpCircle, RefreshCw } from 'lucide-react';
import { COURSES_BY_LEVEL, HERBAL_RESOURCES, Course } from '../data/courses';
import { HerbalResource } from '../types';

interface DashboardProps {
  currentLevel: 100 | 200 | 300 | 400;
  setCurrentLevel: (level: 100 | 200 | 300 | 400) => void;
  onNavigate: (tab: string) => void;
  userName: string;
}

export default function Dashboard({ currentLevel, setCurrentLevel, onNavigate, userName }: DashboardProps) {
  const [plantOfTheDay, setPlantOfTheDay] = useState<HerbalResource | null>(null);
  const [selectedSemester, setSelectedSemester] = useState<1 | 2>(1);
  
  // Interactive mock student details
  const [studentId, setStudentId] = useState(() => {
    return localStorage.getItem('ghemsa_student_id') || '';
  });
  const [indexNumber, setIndexNumber] = useState(() => {
    return localStorage.getItem('ghemsa_index_number') || '';
  });
  const [registrationCompleted, setRegistrationCompleted] = useState<boolean>(() => {
    return localStorage.getItem('ghemsa_registration_completed') === 'true';
  });

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [tempStudentId, setTempStudentId] = useState(studentId);
  const [tempIndexNumber, setTempIndexNumber] = useState(indexNumber);
  const [tempRegistrationCompleted, setTempRegistrationCompleted] = useState(registrationCompleted);

  // Sync temp state if they change externally (like when saving)
  useEffect(() => {
    setTempStudentId(studentId);
    setTempIndexNumber(indexNumber);
    setTempRegistrationCompleted(registrationCompleted);
  }, [studentId, indexNumber, registrationCompleted]);

  // Track completed courses
  const [completedCourses, setCompletedCourses] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('ghemsa_completed_courses');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    // Select plant of the day based on today's date
    const day = new Date().getDate();
    const index = day % HERBAL_RESOURCES.length;
    setPlantOfTheDay(HERBAL_RESOURCES[index]);
  }, []);

  const handleToggleCourse = (code: string) => {
    const updated = { ...completedCourses, [code]: !completedCourses[code] };
    setCompletedCourses(updated);
    localStorage.setItem('ghemsa_completed_courses', JSON.stringify(updated));
  };

  const handleSaveProfile = () => {
    setStudentId(tempStudentId);
    setIndexNumber(tempIndexNumber);
    setRegistrationCompleted(tempRegistrationCompleted);
    localStorage.setItem('ghemsa_student_id', tempStudentId);
    localStorage.setItem('ghemsa_index_number', tempIndexNumber);
    localStorage.setItem('ghemsa_registration_completed', String(tempRegistrationCompleted));
    setIsEditingProfile(false);
  };

  // Filter courses by selected level and semester
  const activeLevelCourses = COURSES_BY_LEVEL[currentLevel] || [];
  const filteredCourses = activeLevelCourses.filter(c => c.semester === selectedSemester);
  
  // Dynamic metrics
  const totalCredits = filteredCourses.reduce((sum, c) => sum + c.credits, 0);
  const completedCount = filteredCourses.filter(c => completedCourses[c.code]).length;
  const completedCredits = filteredCourses.filter(c => completedCourses[c.code]).reduce((sum, c) => sum + c.credits, 0);

  const totalCourseCountAcrossAll = COURSES_BY_LEVEL[100].length + COURSES_BY_LEVEL[200].length + COURSES_BY_LEVEL[300].length + COURSES_BY_LEVEL[400].length;

  // Format academic year
  const getAcademicYear = (level: number) => {
    if (level === 100) return '2023/2024';
    if (level === 200) return '2024/2025';
    if (level === 300) return '2025/2026';
    return '2026/2027';
  };

  return (
    <div className="space-y-8 animate-fade-in" id="ghemsa_dashboard_root">
      {/* Welcome & Focus Banner */}
      <div 
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950 to-emerald-900 p-8 text-white shadow-xl border border-emerald-800/20"
        id="dashboard_welcome"
      >
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none md:block hidden">
          <GraduationCap className="h-48 w-48 text-emerald-300" />
        </div>
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3.5 py-1 text-[10px] font-black uppercase tracking-wider text-emerald-300 border border-emerald-500/20">
            <Sparkles className="h-3 w-3 animate-pulse text-emerald-400" /> GHEMSA Portal • KNUST
          </div>
          <h1 className="text-2xl sm:text-3.5xl font-extrabold tracking-tight font-display text-white">
            Department of Herbal Medicine Curriculum
          </h1>
          <p className="text-emerald-100/80 leading-relaxed text-xs sm:text-sm">
            Official curriculum matrix, interactive registration checker, study guides, and MCQ simulators for BSc Herbal Medicine students. Select your year of study, semester, and track register status below.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('quiz')}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-4.5 py-2.5 text-xs font-black text-emerald-950 hover:bg-emerald-300 transition-all duration-200 shadow-md shadow-emerald-950/20"
              id="dash_btn_quiz"
            >
              <Brain className="h-4 w-4" /> Start MCQ Practice
            </button>
            <button
              onClick={() => onNavigate('herbs')}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-900/40 border border-emerald-700/50 hover:bg-emerald-900/60 px-4.5 py-2.5 text-xs font-black text-emerald-100 transition-all duration-200"
              id="dash_btn_lab"
            >
              Launch Compounding Lab <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Department Enrollment & Registration Gateway */}
      <div 
        className="rounded-3xl border-2 border-emerald-100 bg-white p-6 shadow-sm space-y-6 @container" 
        id="departmental_enrollment_gate"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <h3 className="font-extrabold text-slate-800 text-sm md:text-base flex items-center gap-2">
              <span className="p-1 px-2 rounded-lg bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">KNUST GHEMSA</span>
              Department Student Verification & Status Gate
            </h3>
            <p className="text-xs text-slate-500">
              Input your active student details to configure enrollment records and toggle your current semester registration status.
            </p>
          </div>
          <div className="shrink-0 flex items-center gap-3">
            {studentId && indexNumber && registrationCompleted ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-850 border border-emerald-200">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Record Complete
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-black text-amber-800 border border-amber-200 animate-pulse">
                <span className="h-2 w-2 rounded-full bg-amber-500"></span>
                Update Required
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Student ID input */}
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block">KNUST Student ID</label>
            <input 
              type="text" 
              placeholder="Enter Student ID (e.g. 2011234)" 
              value={tempStudentId}
              onChange={(e) => setTempStudentId(e.target.value.replace(/\D/g, ''))}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-xs font-bold font-mono tracking-wide transition-all outline-none"
            />
          </div>

          {/* Index Number input */}
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider block">KNUST Index Number</label>
            <input 
              type="text" 
              placeholder="Enter Index Number (e.g. 7098451)" 
              value={tempIndexNumber}
              onChange={(e) => setTempIndexNumber(e.target.value.replace(/\D/g, ''))}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-xs font-bold font-mono tracking-wide transition-all outline-none"
            />
          </div>

          {/* Registration completion toggle */}
          <div className="space-y-2 flex flex-col justify-between">
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider block mb-1">KNUST Course Registration Status</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setTempRegistrationCompleted(true)}
                className={`flex-1 rounded-xl py-2.5 text-xs font-black transition-all border ${
                  tempRegistrationCompleted 
                    ? 'bg-emerald-800 text-white border-emerald-950 shadow-sm' 
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Yes, Completed
              </button>
              <button
                type="button"
                onClick={() => setTempRegistrationCompleted(false)}
                className={`flex-1 rounded-xl py-2.5 text-xs font-black transition-all border ${
                  !tempRegistrationCompleted 
                    ? 'bg-rose-900 text-white border-rose-950 shadow-sm' 
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                No, Pending
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
          <div className="flex items-center gap-2">
            {registrationCompleted ? (
              <p className="text-[11px] text-emerald-800 font-bold bg-emerald-50 px-2 py-1 rounded border border-emerald-200/50 flex items-center gap-1">
                ✔ Active Registration Completed and Registered in Departments system.
              </p>
            ) : (
              <p className="text-[11px] text-rose-800 font-bold bg-rose-50 px-2 py-1 rounded border border-rose-200/50 flex items-center gap-1">
                ⚠ Course registration currently marked as pending/incomplete.
              </p>
            )}
          </div>
          <button
            onClick={handleSaveProfile}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-900 hover:bg-emerald-950 text-white font-black px-6 py-3 text-xs transition-all cursor-pointer shadow-md shadow-emerald-950/10 hover:scale-[1.01]"
          >
            Save & Update Records
          </button>
        </div>
      </div>

      {/* Stats Panel */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3" id="stats_panel_grid">
        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">KNUST Curricula Track</span>
            <div className="rounded-xl bg-teal-50 p-2 text-teal-600">
              <BookOpen className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-800">{totalCourseCountAcrossAll}</span>
            <span className="text-xs text-slate-500">Core classes (L100 - L400)</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Active Botanical Monographs</span>
            <div className="rounded-xl bg-emerald-50 p-2 text-emerald-600">
              <Sprout className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-800">{HERBAL_RESOURCES.length}</span>
            <span className="text-xs text-slate-500">Standardized reference kits</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Completed Credit-hours</span>
            <div className="rounded-xl bg-teal-50 p-2 text-indigo-600">
              <Library className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-800">
              {Object.values(completedCourses).filter(Boolean).length > 0 ? `${completedCredits} hrs` : 'Interactive'}
            </span>
            <span className="text-xs text-slate-500">Check off finished courses</span>
          </div>
        </div>
      </div>

      {/* Academic Feature Desks Shortcuts */}
      <div className="space-y-4" id="academic_feature_desks">
        <div>
          <h2 className="text-base font-black text-slate-800 tracking-tight flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-emerald-800" /> GHEMSA Core Academic Desks
          </h2>
          <p className="text-xs text-slate-500">Quick gateway shortcuts to active learning resources and boards simulators.</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <div 
            onClick={() => onNavigate('materials')}
            className="group rounded-2xl border border-slate-100 bg-white p-4 hover:shadow-lg hover:border-emerald-200 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="rounded-xl bg-teal-50 p-2 text-teal-700 w-9 h-9 flex items-center justify-center group-hover:scale-110 transition-transform">
                <BookOpen className="h-4 w-4" />
              </div>
              <h3 className="font-extrabold text-xs text-slate-800 leading-snug group-hover:text-emerald-850 transition-colors">Study Guides</h3>
              <p className="text-[10px] text-slate-500 leading-normal">Browse slides, lab papers, and monographs.</p>
            </div>
            <div className="mt-3 text-[9px] font-black uppercase text-emerald-700 tracking-wider flex items-center gap-1">
              Open Guides <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          <div 
            onClick={() => onNavigate('quiz')}
            className="group rounded-2xl border border-slate-100 bg-white p-4 hover:shadow-lg hover:border-emerald-200 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="rounded-xl bg-purple-50 p-2 text-purple-700 w-9 h-9 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Brain className="h-4 w-4" />
              </div>
              <h3 className="font-extrabold text-xs text-slate-800 leading-snug group-hover:text-emerald-850 transition-colors">Past Questions</h3>
              <p className="text-[10px] text-slate-500 leading-normal">Test diagnostics, MCQs, and revisions.</p>
            </div>
            <div className="mt-3 text-[9px] font-black uppercase text-purple-750 tracking-wider flex items-center gap-1">
              Start Practice <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          <div 
            onClick={() => onNavigate('herbs')}
            className="group rounded-2xl border border-slate-100 bg-white p-4 hover:shadow-lg hover:border-emerald-200 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="rounded-xl bg-emerald-50 p-2 text-emerald-700 w-9 h-9 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Sprout className="h-4 w-4" />
              </div>
              <h3 className="font-extrabold text-xs text-slate-800 leading-snug group-hover:text-emerald-850 transition-colors">Formulation Lab</h3>
              <p className="text-[10px] text-slate-500 leading-normal">Draft, review, and formulate active compounds.</p>
            </div>
            <div className="mt-3 text-[9px] font-black uppercase text-emerald-750 tracking-wider flex items-center gap-1">
              Launch Lab <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          <div 
            onClick={() => onNavigate('notes')}
            className="group rounded-2xl border border-slate-100 bg-white p-4 hover:shadow-lg hover:border-emerald-200 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="rounded-xl bg-indigo-50 p-2 text-indigo-700 w-9 h-9 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Library className="h-4 w-4" />
              </div>
              <h3 className="font-extrabold text-xs text-slate-800 leading-snug group-hover:text-emerald-850 transition-colors">Study Notebook</h3>
              <p className="text-[10px] text-slate-500 leading-normal">Sync summaries directly to Google Drive.</p>
            </div>
            <div className="mt-3 text-[9px] font-black uppercase text-indigo-750 tracking-wider flex items-center gap-1">
              Open Notebook <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          <div 
            onClick={() => onNavigate('flora')}
            className="group rounded-2xl border border-emerald-100 bg-white p-4 hover:shadow-lg hover:border-emerald-300 transition-all cursor-pointer flex flex-col justify-between col-span-2 lg:col-span-1"
          >
            <div className="space-y-2">
              <div className="rounded-xl bg-amber-50 p-2 text-amber-700 w-9 h-9 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Compass className="h-4 w-4 text-amber-750 animate-spin duration-3000" />
              </div>
              <h3 className="font-extrabold text-xs text-slate-800 leading-snug group-hover:text-emerald-850 transition-colors">Flora Registry</h3>
              <p className="text-[10px] text-slate-500 leading-normal">Certified plants of the Ghana Pharmacopoeia.</p>
            </div>
            <div className="mt-3 text-[9px] font-black uppercase text-amber-750 tracking-wider flex items-center gap-1">
              Launch Registry <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>

      {/* Primary Section Layout */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3" id="main_content_layouts">
        
        {/* Core Syllabus Block styled exactly like the official paper registration screenshots! */}
        <div className="lg:col-span-2 space-y-6" id="dashboard_curriculum_section">
          
          {/* Header Controls for Selection */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
            <div className="space-y-1">
              <h3 className="font-black text-slate-800 text-sm tracking-wide uppercase">KNUST Registration Configurator</h3>
              <p className="text-[11px] text-slate-500">Configure your academic Level of study and semester parameters below.</p>
            </div>
            
            <div className="flex flex-wrap items-center gap-3">
              {/* Year/Level toggle */}
              <div className="inline-flex rounded-xl bg-slate-150 p-1" id="academic_year_level_toggles">
                {([100, 200, 300, 400] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setCurrentLevel(lvl)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-black transition-all ${
                      currentLevel === lvl
                        ? 'bg-white text-emerald-800 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    L{lvl}
                  </button>
                ))}
              </div>

              {/* Semester toggle */}
              <div className="inline-flex rounded-xl bg-slate-150 p-1" id="semester_toggles">
                {([1, 2] as const).map((sem) => (
                  <button
                    key={sem}
                    onClick={() => setSelectedSemester(sem)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-black transition-all ${
                      selectedSemester === sem
                        ? 'bg-emerald-800 text-white shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Sem {sem}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Official Replica paper sheet registration portal card */}
          <div className="relative border border-slate-200 bg-white shadow-lg rounded-2xl overflow-hidden" id="official_knust_replica_form">
            {/* Top decorative receipt pattern barlines */}
            <div className="h-1.5 w-full bg-gradient-to-r from-emerald-800 via-teal-700 to-amber-650"></div>
            
            <div className="p-6 md:p-8 space-y-6">
              
              {/* KNUST official looking header */}
              <div className="text-center space-y-1 border-b border-slate-150 pb-4">
                <p className="font-extrabold text-[12px] sm:text-sm text-slate-800 tracking-wider uppercase font-serif">
                  Kwame Nkrumah University of Science and Technology, Kumasi
                </p>
                <p className="text-[10px] font-bold text-slate-600 tracking-widest uppercase">
                  College of Health Sciences • Faculty of Pharmacy
                </p>
                <p className="font-black text-xs text-emerald-800 tracking-wider uppercase bg-emerald-50 inline-block px-3 py-0.5 rounded-full mt-1">
                  BSc. Herbal Medicine
                </p>
                <h4 className="font-black text-[13px] sm:text-sm text-slate-850 mt-3 tracking-tight font-mono">
                  {getAcademicYear(currentLevel)} {selectedSemester === 1 ? 'FIRST' : 'SECOND'} SEMESTER REGISTRATION
                </h4>
              </div>

              {/* Replica Metadata Field grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 bg-slate-50/50 rounded-xl p-4 border border-slate-100 text-xs text-slate-700 font-medium">
                <div className="space-y-1.5">
                  <p className="flex justify-between md:block"><span className="text-slate-400 font-bold uppercase text-[9px] tracking-wide inline-block w-24">Name:</span> <span className="font-bold text-slate-800">{(userName || 'GHEMSA Scholar').toUpperCase()}</span></p>
                  
                  <p className="flex justify-between md:block">
                    <span className="text-slate-400 font-bold uppercase text-[9px] tracking-wide inline-block w-24">Student ID:</span> 
                    {isEditingProfile ? (
                      <input 
                        type="text" 
                        value={tempStudentId} 
                        onChange={(e) => setTempStudentId(e.target.value)}
                        className="bg-white border border-slate-200 rounded px-1.5 py-0.5 max-w-[120px] text-xs font-bold font-mono focus:outline-emerald-800"
                      />
                    ) : (
                      <span className="font-bold text-slate-800 font-mono">{studentId}</span>
                    )}
                  </p>

                  <p className="flex justify-between md:block">
                    <span className="text-slate-400 font-bold uppercase text-[9px] tracking-wide inline-block w-24">Index No:</span> 
                    {isEditingProfile ? (
                      <input 
                        type="text" 
                        value={tempIndexNumber} 
                        onChange={(e) => setTempIndexNumber(e.target.value)}
                        className="bg-white border border-slate-200 rounded px-1.5 py-0.5 max-w-[120px] text-xs font-bold font-mono focus:outline-emerald-800"
                      />
                    ) : (
                      <span className="font-bold text-slate-800 font-mono">{indexNumber}</span>
                    )}
                  </p>
                </div>

                <div className="space-y-1.5 border-t border-dashed border-slate-150 pt-2 md:border-t-0 md:pt-0">
                  <p className="flex justify-between md:block"><span className="text-slate-400 font-bold uppercase text-[9px] tracking-wide inline-block w-24">Programme:</span> <span className="font-bold text-slate-800">BSC. HERBAL MEDICINE</span></p>
                  <p className="flex justify-between md:block"><span className="text-slate-400 font-bold uppercase text-[9px] tracking-wide inline-block w-24">Academic Year:</span> <span className="font-bold text-slate-800 font-mono">Year {currentLevel/100}</span></p>
                  <p className="flex justify-between md:block">
                    <span className="text-slate-400 font-bold uppercase text-[9px] tracking-wide inline-block w-24">Reg Status:</span> 
                    {isEditingProfile ? (
                      <select 
                        value={tempRegistrationCompleted ? 'true' : 'false'}
                        onChange={(e) => setTempRegistrationCompleted(e.target.value === 'true')}
                        className="bg-white border border-slate-200 rounded px-1 px-1.5 py-0.5 text-xs font-bold focus:outline-emerald-800"
                      >
                        <option value="true font-bold text-emerald-800">COMPLETED</option>
                        <option value="false font-bold text-rose-800">PENDING</option>
                      </select>
                    ) : (
                      <span className={`font-black text-[10px] px-2 py-0.5 rounded-full ${registrationCompleted ? 'text-emerald-850 bg-emerald-50 border border-emerald-200/55' : 'text-rose-750 bg-rose-50 border border-rose-200/55'}`}>
                        {registrationCompleted ? 'COMPLETED' : 'PENDING'}
                      </span>
                    )}
                  </p>
                </div>

                {/* Profile Editor Trigger */}
                <div className="md:col-span-2 border-t border-slate-150 pt-2.5 flex justify-end gap-1.5">
                  {isEditingProfile ? (
                    <>
                      <button 
                        onClick={() => setIsEditingProfile(false)}
                        className="text-[10px] text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded font-bold transition-all"
                      >
                        Cancel
                      </button>
                      <button 
                        onClick={handleSaveProfile}
                        className="text-[10px] text-white bg-emerald-800 hover:bg-emerald-950 px-2.5 py-1 rounded font-bold transition-all"
                      >
                        Save Details
                      </button>
                    </>
                  ) : (
                    <button 
                      onClick={() => setIsEditingProfile(true)}
                      className="text-[10px] text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded font-black transition-all"
                    >
                      Configure Academic credentials
                    </button>
                  )}
                </div>
              </div>

              {/* Verified Badge stamp look of the registration slip */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-150 pb-2">
                <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider font-mono">Academic Course Matrix Registry</p>
                <div className="inline-flex items-center gap-1.5 rounded bg-rose-50 border border-rose-200 px-3 py-1 font-mono text-[9px] font-black text-rose-600 animate-pulse">
                  <span>● ONLINE BIOMETRIC VERIFICATION SECURED</span>
                </div>
              </div>

              {/* Exact Course Code registration Table replica */}
              <div className="overflow-x-auto" id="registration_replica_table">
                <table className="w-full text-left border-collapse min-w-[500px]">
                  <thead>
                    <tr className="border-b-2 border-slate-200 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                      <th className="py-2.5 w-24">Course Code</th>
                      <th className="py-2.5">Course Title</th>
                      <th className="py-2.5 w-20 text-center">Semester</th>
                      <th className="py-2.5 w-16 text-center">Credits</th>
                      <th className="py-2.5 w-24 text-right">Progress</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredCourses.length > 0 ? (
                      filteredCourses.map((course) => {
                        const isFinished = completedCourses[course.code];
                        return (
                          <tr 
                            key={course.code} 
                            className={`group hover:bg-emerald-50/20 transition-colors ${
                              isFinished ? 'bg-slate-55/35 text-slate-400' : 'text-slate-800'
                            }`}
                          >
                            <td className="py-3 font-extrabold font-mono text-emerald-800 tracking-wide">
                              {course.code}
                            </td>
                            <td className="py-3">
                              <div className="font-extrabold tracking-tight group-hover:text-emerald-900 transition-colors">{course.name}</div>
                              <p className="text-[10px] text-slate-400 mt-0.5 pr-2 leading-relaxed font-medium block">
                                {course.description}
                              </p>
                            </td>
                            <td className="py-3 text-center text-[10px] font-bold text-slate-400 font-mono">
                              Sem {course.semester}
                            </td>
                            <td className="py-3 text-center font-bold font-mono text-slate-800">
                              {course.credits}
                            </td>
                            <td className="py-3 text-right">
                              <button
                                onClick={() => handleToggleCourse(course.code)}
                                className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all border shrink-0 cursor-pointer ${
                                  isFinished
                                    ? 'bg-emerald-800 border-emerald-900 text-white shadow-sm'
                                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:text-slate-800'
                                }`}
                              >
                                {isFinished ? (
                                  <>
                                    <CheckCircle2 className="h-3 w-3" /> Passed
                                  </>
                                ) : (
                                  <>Complete</>
                                )}
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-400">
                          Syllabus parameters under compilation. Enjoy Levels 100 to 400 active modules.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Signature dotted cut off stamp as shown in screenshots */}
              <div className="border-t border-dashed border-slate-200 pt-6 space-y-6">
                
                {/* Dynamically formulated calculations matching receipt screenshots summary parameters */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-extrabold text-slate-700 bg-slate-50 p-4 rounded-xl border border-dashed border-slate-205">
                  <div>
                    <span className="text-slate-400 font-medium block text-[9px] uppercase tracking-wider">Number of subjects</span>
                    <p className="text-slate-800 font-black font-mono text-lg mt-0.5">{filteredCourses.length}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium block text-[9px] uppercase tracking-wider">Credits registered</span>
                    <p className="text-emerald-850 font-black font-mono text-lg mt-0.5">{totalCredits}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium block text-[9px] uppercase tracking-wider">Subjects Completed</span>
                    <p className="text-indigo-850 font-black font-mono text-lg mt-0.5">{completedCount} of {filteredCourses.length}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium block text-[9px] uppercase tracking-wider">Undefered Credits</span>
                    <p className="text-amber-850 font-black font-mono text-lg mt-0.5">{completedCredits} hrs</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-between gap-6 text-[10px] text-slate-400 font-bold uppercase font-mono">
                  <div className="text-center sm:text-left space-y-2 w-full sm:w-auto">
                    <p className="border-b border-dotted border-slate-300 pb-1.5 max-w-[200px] mx-auto sm:mx-0"></p>
                    <p>Student's Signature</p>
                  </div>
                  <div className="text-center sm:text-right space-y-2 w-full sm:w-auto">
                    <p className="border-b border-dotted border-slate-300 pb-1.5 max-w-[220px] mx-auto sm:mx-0 sm:ml-auto"></p>
                    <p>Academic Supervisor / Registration Officer</p>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Quick study metrics motivator widget */}
          {completedCount > 0 && (
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/20 p-5 flex items-center justify-between gap-6 animate-fade-in">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-emerald-150/50 flex items-center justify-center text-emerald-800 shrink-0">
                  <Award className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs font-black text-slate-800">Sabbatical Semester Progress</p>
                  <p className="text-[10px] text-slate-500">You have checked off {completedCount} courses completed ({Math.round((completedCount/filteredCourses.length)*100)}% absolute completion) for L{currentLevel} Sem {selectedSemester}.</p>
                </div>
              </div>
              <button 
                onClick={() => setCompletedCourses({})}
                className="text-[9px] font-black uppercase text-rose-600 bg-rose-50 border border-rose-100 px-3 py-1.5 rounded-lg shrink-0 transition-colors"
              >
                Reset Track
              </button>
            </div>
          )}

          {/* Contact helpdesk and support */}
          <div className="rounded-2xl border border-dashed border-slate-100 bg-white p-6 flex flex-col md:flex-row items-center gap-6" id="dashboard_helpdesk_callout">
            <div className="rounded-full bg-teal-50 p-4 text-teal-800 shrink-0">
              <Phone className="h-8 w-8 text-emerald-800" />
            </div>
            <div className="space-y-2 text-center md:text-left flex-1">
              <h3 className="font-extrabold text-slate-800 text-sm md:text-base">GHEMSA KNUST Academic SupportDesk</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Stuck with course registrations, study guidelines access, exam syllabus synchronizations, or past questions? Speak directly to our support assistant:
              </p>
              <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-3">
                <a
                  href="tel:0531855909"
                  className="inline-flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-extrabold px-4 py-2.5 text-[11px] shadow-sm transition-colors cursor-pointer"
                >
                  <Phone className="h-3 w-3" /> Dial Office: 0531855909
                </a>
                <span className="text-[9px] uppercase tracking-wider font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1.5 rounded border border-emerald-100/30">
                  Direct Student HotLine
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar panels */}
        <div className="space-y-6" id="dashboard_sidebar_widgets">
          {plantOfTheDay && (
            <div 
              className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm space-y-4 relative overflow-hidden"
              id="plant_of_the_day_card"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-teal-50 rounded-full blur-xl opacity-60 -mr-4 -mt-4"></div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 inline-flex items-center gap-1.5">
                  <Sprout className="h-3.5 w-3.5" /> Plant of the Day
                </span>
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-black text-slate-800 leading-tight">
                  {plantOfTheDay.name}
                </h3>
                <p className="text-xs italic font-semibold text-slate-500">
                  {plantOfTheDay.botanicalName}
                </p>
                <p className="text-[10px] text-slate-400 font-bold leading-normal">
                  {plantOfTheDay.family} family • Local: <span className="text-slate-650">{plantOfTheDay.localName}</span>
                </p>
              </div>

              <div className="border-t border-slate-100 pt-3 space-y-2 text-xs">
                <div>
                  <span className="font-bold text-slate-700 block mb-0.5">Primary Actives:</span>
                  <div className="flex flex-wrap gap-1">
                    {plantOfTheDay.activeConstituents.slice(0, 2).map((ac) => (
                      <span key={ac} className="rounded bg-slate-100 px-1.5 py-0.5 text-slate-600 font-mono text-[10px]">
                        {ac}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="font-bold text-slate-700 block mb-0.5">Therapeutic Action:</span>
                  <p className="text-slate-500 line-clamp-2 text-[11px] leading-relaxed">{plantOfTheDay.therapeuticUses[0]}</p>
                </div>
              </div>

              <button
                onClick={() => onNavigate('herbs')}
                className="w-full text-center rounded-xl border border-slate-200 hover:border-emerald-300 py-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-slate-50/50 hover:bg-emerald-50/25 transition-all text-[11px]"
              >
                Inspect Full Monograph
              </button>
            </div>
          )}

          {/* Academic Calendar Widget */}
          <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm space-y-4">
            <h3 className="font-black text-slate-850 text-xs tracking-wider uppercase flex items-center gap-2">
              <Calendar className="h-4.5 w-4.5 text-emerald-600" /> Key Dates (KNUST)
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-start gap-3 border-l-2 border-emerald-500 pl-3 py-0.5">
                <div className="space-y-0.5">
                  <p className="text-xs font-bold text-slate-800">GHEMSA Mid-Semesters</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wide">July 8 - July 12, 2026</p>
                </div>
              </div>
              <div className="flex items-start gap-3 border-l-2 border-teal-500 pl-3 py-0.5">
                <div className="space-y-0.5">
                  <p className="text-xs font-bold text-slate-800">Clinical Herbarium Field Trip</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wide">July 22, 2026 (At Aburi Gardens)</p>
                </div>
              </div>
              <div className="flex items-start gap-3 border-l-2 border-slate-300 pl-3 py-0.5">
                <div className="space-y-0.5">
                  <p className="text-xs font-bold text-slate-800">Final Dissertation Defense</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wide">August 17, 2026</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
