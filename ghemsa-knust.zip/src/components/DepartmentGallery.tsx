import React, { useState } from 'react';
import { Camera, Layers, Sprout, Heart, Users, ExternalLink, Sparkles } from 'lucide-react';

interface GalleryItem {
  id: string;
  category: 'Labs' | 'Gardens' | 'Clinicals' | 'Outreaches';
  title: string;
  description: string;
  url: string;
}

export default function DepartmentGallery() {
  const [filter, setFilter] = useState<'All' | 'Labs' | 'Gardens' | 'Clinicals' | 'Outreaches'>('All');

  React.useEffect(() => {
    document.title = "Department Gallery | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const galleryItems: GalleryItem[] = [
    {
      id: 'gal_01',
      category: 'Labs',
      title: 'HPLC Active Ingredient Screening',
      description: 'Undergraduate scholars calibrating mobile solvents to run fingerprint markers on raw plant specimens.',
      url: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_02',
      category: 'Labs',
      title: 'Phytochemistry Extraction Setup',
      description: 'Using professional vacuum rotary evaporators to separate crude ethanolic plant extracts under stabilized temperature guides.',
      url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_03',
      category: 'Gardens',
      title: 'KNUST Botanical Garden Conservatories',
      description: 'Our primary research living classroom containing over 1,200 cataloged indigenous medicinal plant species.',
      url: 'https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_04',
      category: 'Gardens',
      title: 'Greenhouse Sprout Domestication',
      description: 'Evaluating optimal climate preservation and humidity tolerances for endangered anti-malarial saplings.',
      url: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_05',
      category: 'Clinicals',
      title: 'Clinical Ward Diagnostics Rotation',
      description: 'Student medical herbalists observing ward diagnostic charts and assessing renal metrics under consulting medical officers.',
      url: 'https://images.unsplash.com/photo-1584515906207-fd4044a5e1c2?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_06',
      category: 'Clinicals',
      title: 'Traditional Therapeutic Apothecary',
      description: 'A licensed pharmacist evaluating standard botanical liquids, syrups, and capsule stability under hospital conditions.',
      url: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_07',
      category: 'Outreaches',
      title: 'GHEMSA Rural Marketplace Sanitary Health Check',
      description: 'Students educating market herb sellers inside Kumasi on preserving raw bark powders from hazardous aflatoxin mold growth.',
      url: 'https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'gal_08',
      category: 'Outreaches',
      title: 'Ethnobotanical Consultation Sessions',
      description: 'A licensed graduate practicing diagnostic patient clerking and prescribing standardized formulas in rural communities.',
      url: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=600&q=80'
    }
  ];

  const filteredItems = filter === 'All' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === filter);

  return (
    <div className="space-y-12 animate-fade-in" id="department_gallery_root">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Gallery View)</span>
        <strong className="text-slate-705">Title:</strong> Department Photo Gallery | KNUST Herbal Medicine<br />
        <strong className="text-slate-705">Description:</strong> Explore high-definition visuals of the KNUST phytomedicines analytics laboratories, live conservation botanical gardens, and student medical postings.
      </div>

      {/* Header section with filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block font-mono">Visual Campuses & Assets</span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight leading-none">
            Our Department in Pictures
          </h1>
          <p className="text-xs text-slate-500">Take a virtual walk inside our research complexes, nurseries, and student postings.</p>
        </div>

        {/* Filter Selection Grid */}
        <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1 rounded-xl shrink-0">
          {(['All', 'Labs', 'Gardens', 'Clinicals', 'Outreaches'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider cursor-pointer transition-all ${
                filter === cat
                  ? 'bg-emerald-850 text-white shadow-sm font-extrabold'
                  : 'text-slate-550 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* GALLERY GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="gallery_items_grid">
        {filteredItems.map((item) => (
          <div 
             key={item.id} 
             className="bg-white rounded-3xl border border-slate-150 overflow-hidden shadow-sm hover:shadow-xl hover:border-emerald-500/25 transition-all flex flex-col group cursor-zoom-in"
          >
            {/* Image Box */}
            <div className="relative aspect-video sm:aspect-square overflow-hidden bg-slate-100">
              <img 
                src={item.url} 
                alt={item.title} 
                className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-2 right-2 bg-[#09150e]/80 text-emerald-400 border border-emerald-800/10 backdrop-blur-md text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full">
                {item.category}
              </span>
            </div>

            {/* Explanatory text under each media block */}
            <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
              <div className="space-y-1 text-left">
                <h4 className="font-extrabold text-slate-800 text-xs md:text-sm leading-tight group-hover:text-emerald-850 transition-colors">
                  {item.title}
                </h4>
                <p className="text-[11px] text-slate-450 leading-normal font-semibold font-sans">
                  {item.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
