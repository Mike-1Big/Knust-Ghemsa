import React from 'react';
import { Sprout, Award, BookOpen, Quote, Shield, GraduationCap, ChevronRight, School, Users, Activity, Sparkles, Building2, Compass } from 'lucide-react';

interface DepartmentHomeProps {
  onNavigate: (tab: string) => void;
  userRole: 'student' | 'aspiring' | null;
  onSetRole: (role: 'student' | 'aspiring') => void;
}

export default function DepartmentHome({ onNavigate, userRole, onSetRole }: DepartmentHomeProps) {
  // SEO description meta simulated inside component
  React.useEffect(() => {
    document.title = "Department of Herbal Medicine | KNUST Ghana - Premier Botanical Medicine Education";
  }, []);

  const stats = [
    { value: '1st', label: 'BSc Herbal Medicine Programme in West Africa', icon: School },
    { value: '3,000+', label: 'GHEMSA Herbarium Species Database', icon: Sprout },
    { value: '350+', label: 'Alumni Practicing in Public & Private Clinics', icon: Users },
    { value: '25+', label: 'Active Clinical Hospital & Ministry Affiliations', icon: Activity },
  ];

  const highlights = [
    {
      title: 'World Health Organization Support',
      desc: 'Recognized as a focal center for the training of herbal research specialists and traditional practitioners in Sub-Saharan Africa.',
      icon: Shield,
      image: 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=400&q=80' // Clinic/health researcher context
    },
    {
      title: 'Collaborative Phytochemistry Labs',
      desc: 'Utilizing state-of-the-art HPLC and GC-MS equipment for active product validation in partnership with Pharmacy and Biochemistry.',
      icon: Award,
      image: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=400&q=80' // True laboratory glass chemistry research
    },
    {
      title: 'KNUST Botanical Garden Access',
      desc: 'Exclusive research and validation access to over 50 acres of living rare botanical specimens and conserved economic plants in Kumasi.',
      icon: BookOpen,
      image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=400&q=80' // Greenhouse garden context
    },
  ];

  return (
    <div className="space-y-12 animate-fade-in" id="dept_home_root">
      
      {/* Search Engine Optimization Metadata Box - Premium Academic Info architecture */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4.5 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Structured Data View)</span>
        <strong className="text-slate-700">Title:</strong> Department of Herbal Medicine | Kwame Nkrumah University of Science and Technology, KNUST Ghana<br />
        <strong className="text-slate-700">Description:</strong> Explore the premier academic center for botanical research and modern phytomedicine therapy in West Africa. Learn more about admission requirements, clinical training, and our GHEMSA Herbarium directory.
      </div>

      {/* GRAND HERO BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#091d12] via-[#05110a] to-[#122e1e] p-8 md:p-12 text-white border border-emerald-800/20 shadow-2xl">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none hidden lg:block">
          <Building2 className="h-96 w-96 text-emerald-300" />
        </div>

        <div className="max-w-3xl space-y-6 relative z-10">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-amber-400/10 px-4 py-1 text-[10px] font-black uppercase tracking-widest text-amber-300 border border-amber-300/20">
            <Sparkles className="h-3 w-3 text-amber-400 animate-pulse" /> College of Health Sciences • KNUST
          </div>
          
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight font-display leading-[1.1] text-white">
            Pioneering Science in <span className="text-amber-400 bg-amber-400/5 px-2 rounded-lg border border-amber-400/10">Traditional Phytomedicine</span>
          </h1>

          <p className="text-emerald-100/80 leading-relaxed text-xs sm:text-base max-w-2xl font-medium">
            Welcome to the Kwame Nkrumah University of Science and Technology (KNUST) Department of Herbal Medicine. Established to validate, standardize, and integrate Ghana's rich botanical heritage into mainstream clinical healthcare.
          </p>

          <div className="pt-4 flex flex-wrap gap-3.5">
            <button
               onClick={() => onNavigate('admission')}
               className="inline-flex items-center gap-2 rounded-xl bg-amber-400 text-slate-950 hover:bg-amber-300 px-6 py-3 text-xs font-black transition-all duration-200 shadow-lg shadow-amber-400/20 cursor-pointer hover:scale-[1.01]"
            >
              Apply for BSc Admission <ChevronRight className="h-4 w-4" />
            </button>
            <button
               onClick={() => onNavigate('chatbot')}
               className="inline-flex items-center gap-2 rounded-xl bg-emerald-900/50 border border-emerald-700/40 hover:bg-emerald-900/70 px-5 py-3 text-xs font-extrabold text-emerald-100 transition-all duration-200 cursor-pointer"
            >
              Ask Live AI Advisor
            </button>
          </div>
        </div>
      </div>

      {/* ADAPTIVE GUIDE BANNER FOR ACCORDANCE WITH USER ROLE */}
      {userRole && (
        <div className={`rounded-3xl p-6 border flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm animate-fade-in ${
          userRole === 'student' 
            ? 'bg-emerald-50/40 border-emerald-200/60 text-slate-800'
            : 'bg-amber-50/40 border-amber-205/60 text-slate-800'
        }`} id="role_adaptive_guidance_banner">
          <div className="flex items-start gap-4 text-left">
            <div className={`p-3 rounded-2xl shrink-0 ${
              userRole === 'student' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
            }`}>
              {userRole === 'student' ? <GraduationCap className="h-6 w-6" /> : <Compass className="h-6 w-6" />}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className={`text-[9px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded ${
                  userRole === 'student' ? 'bg-emerald-800 text-white' : 'bg-amber-500 text-slate-950'
                }`}>
                  {userRole === 'student' ? 'Current Student Mode' : 'Prospective Student Mode'}
                </span>
                <span className="text-slate-400 font-mono text-[10px]">Active Guidance Console</span>
              </div>
              <h3 className="font-extrabold text-[#11311b] text-sm md:text-base leading-tight">
                {userRole === 'student' 
                  ? 'Helping Student Academic Progress' 
                  : 'Enrollment & Admission Checklist'}
              </h3>
              <p className="text-xs text-slate-500 max-w-xl leading-relaxed font-semibold">
                {userRole === 'student' 
                  ? 'Instantly launch academic matrix, MCQ simulators, slide learning manuals, and backup your personal notes to Google Drive cloud workspace.'
                  : 'Explore official accredited entry criteria, check program outlines, learn WHO advisory historical context, or start in-depth inquiries.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5 shrink-0 justify-end w-full md:w-auto">
            {userRole === 'student' ? (
              <>
                <button
                  onClick={() => onNavigate('student-hub')}
                  className="rounded-xl bg-emerald-850 hover:bg-emerald-900 text-white font-extrabold px-4 py-2.5 text-xs transition-colors cursor-pointer"
                >
                  Central Scholars Hub ➔
                </button>
                <button
                  onClick={() => onNavigate('quiz')}
                  className="rounded-xl bg-white border border-slate-205 text-slate-700 font-extrabold px-4 py-2.5 text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  MCQ Exam Lab
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => onNavigate('admission')}
                  className="rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold px-4 py-2.5 text-xs transition-colors cursor-pointer"
                >
                  Admissions Checklist ➔
                </button>
                <button
                  onClick={() => onNavigate('chatbot')}
                  className="rounded-xl bg-white border border-slate-205 text-slate-700 font-extrabold px-4 py-2.5 text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Virtual AI Advisor
                </button>
              </>
            )}
            <button
              onClick={() => onSetRole(userRole === 'student' ? 'aspiring' : 'student')}
              className="rounded-xl bg-slate-900 hover:bg-slate-950 text-white font-extrabold px-4 py-2.5 text-xs transition-colors cursor-pointer"
            >
              Switch Role
            </button>
          </div>
        </div>
      )}

      {/* DEPARTMENTAL OVERVIEW & HOD WELCOME */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Welcome message column */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-55 font-bold text-[10px] text-emerald-900 uppercase rounded-md tracking-wider">
              Department Statement
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight leading-tight">
              Bridging Ancient Wisdom with Modern Proof
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Ghana's forests and savannahs contain botanical formulas utilized for centuries in primary healthcare. However, safety, clinical dosage, standardization, and pharmacokinetics are critical requirements for global adoption.
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Our department trains <strong>medical herbalists</strong> who understand clinical pathology, phytochemistry, systemic toxicology, and diagnostic imaging. We conduct academic inquiry into rare plant species and establish legal and clinical framework standards.
            </p>
          </div>
          
          <div className="border-t border-slate-100 pt-6 mt-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="h-14 w-14 rounded-full bg-gradient-to-tr from-emerald-800 to-amber-500 overflow-hidden shrink-0 flex items-center justify-center text-white font-extrabold text-lg shadow-md">
              HOD
            </div>
            <div className="space-y-1 text-left">
              <div className="flex items-center gap-1.5 font-display">
                <Quote className="h-4 w-4 text-emerald-700 shrink-0" />
                <h4 className="font-extrabold text-slate-800 text-sm">Dr. Benard Turkson</h4>
              </div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Head of Department, Senior Lecturer & Phytopharmacology Researcher</p>
              <em className="text-xs text-slate-500 leading-relaxed block font-semibold italic">
                "Our mission is to empower a generation of clinicians to deliver standardized, accessible botanical medical therapy safely."
              </em>
            </div>
          </div>
        </div>

        {/* Mission, Vision & Core Values column */}
        <div className="lg:col-span-5 bg-gradient-to-br from-emerald-950 to-[#0c1a11] text-emerald-100 rounded-3xl p-6 md:p-8 flex flex-col justify-between space-y-6 border border-emerald-900">
          <div className="space-y-6">
            <div>
              <span className="text-[10px] font-black uppercase text-emerald-400 tracking-wider">Our Vision</span>
              <h3 className="text-lg font-extrabold text-white mt-1">Global Center of Excellence</h3>
              <p className="text-xs text-emerald-200/80 mt-1.5 leading-relaxed">
                To be West Africa's leading authority in botanical medicine education, creating standard regulatory methodologies, high-yield agricultural protocols, and patented phytotherapies.
              </p>
            </div>

            <div className="border-t border-emerald-900 pt-5">
              <span className="text-[10px] font-black uppercase text-emerald-400 tracking-wider">Our Mission</span>
              <h3 className="text-lg font-extrabold text-white mt-1">Standardize & Practice Safely</h3>
              <p className="text-xs text-emerald-200/80 mt-1.5 leading-relaxed">
                Educate elite clinical Medical Herbalists, establish robust pre-clinical toxicity indicators, publish high-impact clinical trials on Ghanaian plants, and work with the Ministry of Health (MoH) for national health coverage integration.
              </p>
            </div>

            <div className="border-t border-emerald-900 pt-5">
              <span className="text-[10px] font-black uppercase text-emerald-400 tracking-wider">Core Values</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {['Scientific Rigor', 'Ethnic Conservation', 'Bio-Authenticity', 'Patient Safety'].map((item) => (
                  <span key={item} className="bg-emerald-900/60 border border-emerald-700/40 text-emerald-300 font-extrabold text-[9px] uppercase tracking-wider px-2.5 py-1 rounded-md">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* DEPARTMENT STATS OVERVIEW */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="stats_overview_grid">
        {stats.map((stat) => {
          const StatIcon = stat.icon;
          return (
            <div key={stat.label} className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm space-y-3 hover:shadow-md transition-shadow">
              <div className="inline-flex p-2 rounded-xl bg-emerald-50 text-emerald-800">
                <StatIcon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl sm:text-3.5xl font-extrabold tracking-tight text-slate-800 font-display">{stat.value}</p>
                <p className="text-[11px] font-bold text-slate-500 leading-snug">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* RECENT HIGHLIGHTS & ACHIEVEMENTS */}
      <div className="space-y-6">
        <div className="text-center space-y-1">
          <span className="text-[10px] font-black text-emerald-800 uppercase tracking-widest block">Academic Credentials</span>
          <h3 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight">Institutional Excellence & Strategic Assets</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">Providing our undergraduate scholars with unmatched resources for practical and pharmaceutical success.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {highlights.map((item) => {
            const ItemIcon = item.icon;
            return (
              <div key={item.title} className="bg-white rounded-3xl border border-slate-150 overflow-hidden shadow-sm hover:shadow-xl hover:border-emerald-305 transition-all flex flex-col group text-left">
                <div className="relative h-44 bg-slate-100 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-550" 
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 inline-flex p-2 rounded-xl bg-slate-900/80 text-amber-400 border border-slate-700/20 backdrop-blur-sm shadow-md">
                    <ItemIcon className="h-4 w-4" />
                  </div>
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between space-y-2">
                  <div className="space-y-1.5 animate-fade-in">
                    <h4 className="font-extrabold text-slate-800 text-sm leading-tight leading-none">{item.title}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold leading-snug">{item.desc}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* FEATURED CTA LINKS ROW */}
      <div className="bg-[#fad432]/10 border-2 border-[#fad432] rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6" id="home_cta_banner">
        <div className="space-y-2 text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 px-2.5 py-0.5 text-[9px] font-black uppercase text-amber-800">
            Admissions Open 2026/2027
          </div>
          <h3 className="font-black text-slate-800 text-base sm:text-lg">Ready to Advance Ghana's Health Sector?</h3>
          <p className="text-xs text-slate-600 max-w-xl leading-relaxed">
            Standard clinical medical herbalists are listed in the registry of the Ghana Health Service. Our curriculum spans clinical internships, botanical chemistry, and patient management.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 shrink-0">
          <button 
            onClick={() => onNavigate('admission')}
            className="rounded-xl bg-slate-900 text-white font-extrabold px-5 py-2.5 text-xs hover:bg-slate-950 transition-all cursor-pointer"
          >
            Requirements Guide
          </button>
          <button 
            onClick={() => onNavigate('contact')}
            className="rounded-xl bg-white border border-slate-300 text-slate-700 font-extrabold px-5 py-2.5 text-xs hover:bg-slate-50 transition-all cursor-pointer"
          >
            Consult Admin office
          </button>
        </div>
      </div>

    </div>
  );
}
