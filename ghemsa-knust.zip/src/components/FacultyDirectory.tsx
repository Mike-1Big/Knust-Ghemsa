import React, { useState } from 'react';
import { Mail, Search, BookOpen, User, Phone, Award, AwardIcon, Sparkles, AlertCircle, Building2, ExternalLink } from 'lucide-react';

interface AcademicProfile {
  name: string;
  title: string;
  role: string;
  qualification: string;
  researchInterest: string;
  publications: string[];
  email: string;
  phone: string;
  office: string;
}

export default function FacultyDirectory() {
  const [searchQuery, setSearchQuery] = useState('');

  React.useEffect(() => {
    document.title = "Faculty & Staff | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const facultyMembers: AcademicProfile[] = [
    {
      name: 'Dr. Benard Turkson',
      title: 'Senior Lecturer & Head of Department',
      role: 'Academic Staff',
      qualification: 'BSc. Herbal Medicine (KNUST), PhD in Pharmacognosy (University of Cape Coast), Member of GHAFTRAM',
      researchInterest: 'Phytochemical compound profiling, development of standardized antimicrobial herbal cosmetics, and clinical study of native wound-healing formulations.',
      publications: [
        'Turkson, B., et al. (2023). Efficacy and Safety Profile of Traditional Wound-Healing Preparations from Central Region, Ghana. Journal of Herbal Medicine Research, 114, 105820.',
        'Turkson, B., & Appiah, T. (2021). Antimicrobial Screening of Secondary Metabolites from Selected West African Asteraceae Species. African Journal of Natural Products, 8(2), 77-89.'
      ],
      email: 'benard.turkson@knust.edu.gh',
      phone: '+233 (0) 24 456 7890',
      office: 'Block A, Room 101 - Faculty of Pharmacy Building'
    },
    {
      name: 'Dr. Joseph Osei-Duro',
      title: 'Senior Lecturer & Senior Phytopharmacology Researcher',
      role: 'Academic Staff',
      qualification: 'BSc. Herbal Medicine (KNUST), PhD in Phytopharmacology (University of Illinois), Fellow of WAIP',
      researchInterest: 'Standardization of West African anti-malarial herbal mixtures, hepatic veno-occlusive toxicology, and phytopharmaceutical engineering.',
      publications: [
        'Osei-Duro, J., et al. (2022). Quantitative evaluation of Active Cryptolepine Markers in Ghanaian Cryptolepis Sanguinolenta Formulations. Journal of Ethnopharmacology, 289, 114980.',
        'Osei-Duro, J., & Mensah, F. (2020). Pre-clinical safety validation logs of Pyrolizidine Alkaloid residues in regional markets. West African Health Journal, 12(3), 45-56.'
      ],
      email: 'joseph.oseiduro@knust.edu.gh',
      phone: '+233 (0) 53 185 5909',
      office: 'Block A, Room 102 - Faculty of Pharmacy Building'
    },
    {
      name: 'Prof. Shirley Amponzah',
      title: 'Associate Professor & Research Chair',
      role: 'Academic Staff',
      qualification: 'BPharm (KNUST), PhD in Ethnobotany & Pharmacognosy (University of London, UK)',
      researchInterest: 'Phytochemical compound profiling of anti-glycemic tubers, bio-active conservation, and traditional medicine health integration strategies.',
      publications: [
        'Amponzah, S., & Boamah, C. (2023). Chromatographic Isolation of Hypoglycemic Flavanoids from Morinda Lucida Extracts. Phytochemistry Letters, 54, 112-118.',
        'Amponzah, S. (2021). The Traditional Medicine Practice Act of Ghana: A 20-Year Retrospective Regulatory Review. TMPC Policy Digest, 7(1), 12-19.'
      ],
      email: 'shirley.amponzah@knust.edu.gh',
      phone: '+233 (0) 24 394 8593',
      office: 'Block A, Room 204 - Faculty of Pharmacy Building'
    },
    {
      name: 'Dr. Caleb Boamah',
      title: 'Lecturer & Field Agronomy Lead',
      role: 'Academic Staff',
      qualification: 'BSc. Botany (Univ of Ghana), MPhil in Herbal Agronomy (KNUST), PhD in Plant Genetics (Leipzig University, Germany)',
      researchInterest: 'Domestication of endangered economic medicinal plants, micro-propagation of Lippia multiflora, and organic fertilizer optimization curves.',
      publications: [
        'Boamah, C., et al. (2024). Cryopreservation protocols for the critically endangered anti-plasmodial shrub Nauclea latifolia. African Journal of Biotechnology, 23(2), 89-97.'
      ],
      email: 'caleb.boamah@knust.edu.gh',
      phone: '+233 (0) 55 908 3432',
      office: 'Herbarium Annex, Room 12 - Botanical Gardens Offices'
    },
    {
      name: 'Dr. Evelyn Appiah',
      title: 'Lecturer & Clinical Supervisor',
      role: 'Academic Staff',
      qualification: 'BSc. Herbal Medicine (KNUST), Doctor of Medicine (MD - KNUST), Specialist Fellow in Clinical Therapeutics',
      researchInterest: 'Hepato-renal pathology under herbal extract regimens, herb-synthetic drug interactions in cardiovascular disease models, and patient case-clerking standards.',
      publications: [
        'Appiah, E., & Osei-Duro, J. (2021). Evaluating Glomerular Filtration Rates (GFR) in patients under chronic pyrolizidine alkaloid exposure: A 3-year clinical tracker. Case Reports in Clinical Medicine, 15(4), 112-120.'
      ],
      email: 'evelyn.appiah@knust.edu.gh',
      phone: '+233 (0) 20 894 3094',
      office: 'Block B, CLINIC WARD - University Hospital Annex'
    },
    {
      name: 'Mrs. Comfort Mensah',
      title: 'Departmental Administrative Secretary',
      role: 'Administrative Staff',
      qualification: 'BSc. Business Administration (KNUST), Certified Academic Registrar Coordinator',
      researchInterest: 'Departmental operations, student registers, transcript handoffs, and external clinical hospital scheduling rosters.',
      publications: [],
      email: 'comfort.mensah@knust.edu.gh',
      phone: '+233 (0) 32 206 0294',
      office: 'Block A, Room 100 (Front Desk Reception) - Faculty of Pharmacy Building'
    }
  ];

  const filteredFaculty = facultyMembers.filter(member => 
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.researchInterest.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.qualification.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-12 animate-fade-in" id="faculty_directory_root">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Faculty View)</span>
        <strong className="text-slate-700">Title:</strong> Faculty Directory | Dept of Herbal Medicine | KNUST Ghana<br />
        <strong className="text-slate-700">Description:</strong> Browse the academic and research profiles of the world-class instructors, clinical supervisors, and biochemists guiding KNUST Herbal Medicine degrees.
      </div>

      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block">Core Scholarly Directory</span>
          <h1 className="text-xl sm:text-3xl font-extrabold text-slate-800 tracking-tight leading-tight">
            Academic & Support Staff Profiles
          </h1>
          <p className="text-xs text-slate-500">Discover researchers, lab specialists, clinical instructors, and secretaries steering our department.</p>
        </div>

        {/* Live Profile Searcher */}
        <div className="relative shrink-0 w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-slate-400 pointer-events-none" />
          <input 
            type="text" 
            placeholder="Search by name or field..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-slate-205 rounded-xl pl-9 pr-4 py-2.5 text-xs outline-none focus:border-emerald-750 transition-all font-semibold"
          />
        </div>
      </div>

      {/* Detailed Profiles List */}
      <div className="grid grid-cols-1 gap-8">
        {filteredFaculty.length > 0 ? (
          filteredFaculty.map((member) => (
            <div 
              key={member.name} 
              className="bg-white rounded-3xl border border-slate-150 p-6 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start hover:shadow-lg hover:border-emerald-500/25 transition-all"
            >
              {/* Left Profile details block */}
              <div className="lg:col-span-4 space-y-4">
                <div className="flex items-center gap-3.5">
                  <div className="h-14 w-14 rounded-full bg-emerald-50 text-emerald-850 flex items-center justify-center border border-emerald-200 shadow-inner">
                    <User className="h-6 w-6 stroke-1.5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-800 text-sm md:text-base leading-tight">{member.name}</h3>
                    <p className="text-[10px] text-emerald-800 font-extrabold bg-emerald-50/50 border border-emerald-100/50 px-2 py-0.5 rounded inline-block mt-1 font-mono uppercase">{member.role}</p>
                  </div>
                </div>

                <div className="space-y-1 bg-slate-50 rounded-2xl p-4.5 text-xs border border-slate-100">
                  <p className="text-slate-700 font-black mb-1">{member.title}</p>
                  <p className="text-[11px] text-slate-500 font-medium leading-relaxed">{member.qualification}</p>
                  <div className="pt-3.5 space-y-1.5 font-mono text-[10.5px] font-bold text-slate-550 border-t border-slate-200/50 mt-2.5">
                    <p className="flex items-center gap-2 truncate text-[11px]">
                      <Mail className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                      <a href={`mailto:${member.email}`} className="hover:underline hover:text-emerald-800">{member.email}</a>
                    </p>
                    <p className="flex items-center gap-2 text-[11px]">
                      <Phone className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                      <span>{member.phone}</span>
                    </p>
                    <p className="flex items-center gap-2 text-[11px]">
                      <Building2 className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                      <span className="truncate">{member.office}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Right Profile Narrative Details Block */}
              <div className="lg:col-span-8 space-y-5 lg:border-l lg:border-slate-150 lg:pl-8">
                <div className="space-y-1.5">
                  <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Research Coordinates & Focus</h4>
                  <p className="text-xs text-slate-600 leading-relaxed font-semibold">{member.researchInterest}</p>
                </div>

                {member.publications.length > 0 && (
                  <div className="space-y-2.5">
                    <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                      <BookOpen className="h-3.5 w-3.5 text-emerald-800" /> Peer-Reviewed Publications Showcase
                    </h4>
                    
                    <div className="space-y-2">
                      {member.publications.map((pub, idx) => (
                        <div key={idx} className="bg-emerald-50/20 border border-emerald-100/30 rounded-xl p-3 flex gap-2.5 items-start">
                          <span className="h-5 w-5 bg-emerald-100 text-emerald-800 font-bold rounded-full text-[10px] flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <p className="text-[11px] text-slate-650 leading-relaxed font-medium font-serif italic flex-1">
                            {pub}
                          </p>
                          <a href="#" className="p-1 text-slate-400 hover:text-emerald-800 shrink-0">
                            <ExternalLink className="h-3.5 w-3.5" />
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-150 space-y-3">
            <AlertCircle className="h-10 w-10 text-slate-300 mx-auto" />
            <p className="text-xs text-slate-400 font-bold">No academic profiles matching your search query.</p>
          </div>
        )}
      </div>

    </div>
  );
}
