import React, { useState, useMemo, useEffect } from 'react';
import { generate3000Flora } from '../data/flora';
import { FloraItem } from '../types';
import { 
  Search, SlidersHorizontal, BookOpen, Layers, Check, ChevronLeft, 
  ChevronRight, ChevronsLeft, ChevronsRight, Heart, Star, Compass, 
  FlaskConical, MapPin, Activity, Sparkles, Copy, X, ArrowRight, ShieldAlert
} from 'lucide-react';

export default function FloraRegistry() {
  // Generate the 3000 plants once
  const allFlora = useMemo(() => generate3000Flora(), []);

  // Search state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFamily, setSelectedFamily] = useState('All');
  const [selectedLetter, setSelectedLetter] = useState('All');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  // Selected item detail view (Modal / Drawer)
  const [selectedPlant, setSelectedPlant] = useState<FloraItem | null>(null);

  // Favorites tracking (local state)
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(() => new Set());
  
  // Clipboard copy status feedback
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Extracted unique families for the dropdown
  const uniqueFamilies = useMemo(() => {
    const families = new Set<string>();
    allFlora.forEach((item) => families.add(item.family));
    return ['All', ...Array.from(families).sort()];
  }, [allFlora]);

  // A to Z index list
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  // Filtered plants
  const filteredFlora = useMemo(() => {
    const query = searchTerm.toLowerCase().trim();
    return allFlora.filter((item) => {
      const matchesSearch =
        item.botanicalName.toLowerCase().includes(query) ||
        item.commonName.toLowerCase().includes(query) ||
        item.localName.toLowerCase().includes(query) ||
        item.family.toLowerCase().includes(query) ||
        (item.distribution && item.distribution.toLowerCase().includes(query)) ||
        (item.uses && item.uses.toLowerCase().includes(query)) ||
        (item.constituents && item.constituents.some(c => c.toLowerCase().includes(query)));

      const matchesFamily = selectedFamily === 'All' || item.family === selectedFamily;

      // Filter by first letter of genus
      const matchesLetter =
        selectedLetter === 'All' ||
        item.botanicalName.toUpperCase().startsWith(selectedLetter);

      return matchesSearch && matchesFamily && matchesLetter;
    });
  }, [allFlora, searchTerm, selectedFamily, selectedLetter]);

  // Reset pagination when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedFamily, selectedLetter]);

  const totalPages = Math.ceil(filteredFlora.length / itemsPerPage) || 1;

  // Paginated plants
  const paginatedFlora = useMemo(() => {
    const activePage = Math.min(currentPage, totalPages);
    const startIndex = (activePage - 1) * itemsPerPage;
    return filteredFlora.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredFlora, currentPage, itemsPerPage, totalPages]);

  const handleToggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavoriteIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleCopyMonograph = (pant: FloraItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const txt = `Plant Monograph: ${pant.botanicalName} (${pant.family})
Common Name: ${pant.commonName}
Ghanaian Tribal Names: ${pant.localName}
Geographical Distribution: ${pant.distribution}
Major Active Constituents: ${pant.constituents?.join(', ') || 'N/A'}
Therapeutic Uses: ${pant.uses}`;

    navigator.clipboard.writeText(txt).then(() => {
      setCopiedId(pant.id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  // Generate a dynamic list of page numbers to show in the navigation ribbon
  const pageNumbers = useMemo(() => {
    const pages: number[] = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      let start = Math.max(1, currentPage - 2);
      let end = Math.min(totalPages, currentPage + 2);
      
      if (currentPage <= 3) {
        start = 1;
        end = maxVisiblePages;
      } else if (currentPage >= totalPages - 2) {
        start = totalPages - 4;
        end = totalPages;
      }
      
      for (let i = start; i <= end; i++) {
        pages.push(i);
      }
    }
    return pages;
  }, [currentPage, totalPages]);

  return (
    <div className="space-y-8 animate-fade-in" id="flora_registry_root">
      
      {/* Premium Swiss-Modern Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-950 p-6 sm:p-10 text-white shadow-2xl border border-emerald-900/45">
        {/* Abstract neon gradient visual grid */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-emerald-500/10 via-teal-900/3 to-transparent pointer-events-none" />
        <div className="absolute top-1/2 -left-12 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative z-10 max-w-4xl space-y-5">
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/10 px-3.5 py-1 text-xs font-black text-emerald-400 border border-emerald-500/20 shadow-inner">
            <Compass className="h-3.5 w-3.5 animate-spin duration-1000" /> 
            <span className="font-mono tracking-widest uppercase text-[10px]">Ministry of Health Aligned • KNUST</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black font-display tracking-tight text-white leading-none">
            GHEMSA <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">Herbarium & Flora Index</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
            The official digital academic repository curated by the <span className="font-extrabold text-[#fbbf24]">Kwame Nkrumah University of Science and Technology (KNUST)</span> and the Ghana Herbal Medical Students Association (GHEMSA). This comprehensive botanical database catalogs exactly <span className="font-semibold text-emerald-400">3,000 plants of high therapeutic interest within Ghana and globally</span>. Browse verified taxonomical families, search world-class active constituents, and view detailed specimen records supported by real-world nature photography.
          </p>

          <div className="flex flex-wrap gap-3 pt-1 text-[11px] font-bold text-slate-300">
            <div className="flex items-center gap-2 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
              <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-md shadow-emerald-400/50" />
              <span>3,000 Species Curated</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
              <span className="h-2 w-2 rounded-full bg-teal-400 shadow-md shadow-teal-400/50" />
              <span>Families: {uniqueFamilies.length - 1}</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
              <span className="h-2 w-2 rounded-full bg-pink-400 shadow-md shadow-pink-400/50" />
              <span>My Favorites: {favoriteIds.size}</span>
            </div>
            <div className="flex items-center gap-2 bg-emerald-950/90 border border-emerald-500/20 text-emerald-400 px-4 py-2 rounded-xl backdrop-blur-sm">
              <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse shadow-md shadow-amber-400/55" />
              <span className="text-[10px] uppercase font-black tracking-wide">📷 Authenticated real photography only — No AI</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lookup & Filter Control Panel */}
      <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-5" id="flora_registry_filters">
        <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
          
          {/* Main search bar */}
          <div className="relative flex-1">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-450">
              <Search className="h-5 w-5 text-emerald-800" />
            </div>
            <input
              type="text"
              placeholder="Search botanical names (e.g. Cryptolepis), constituents (e.g. 5-HTP), family, uses, or local names..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-2xl border border-slate-200 bg-slate-50/50 py-3 pl-11 pr-4 text-xs sm:text-sm text-slate-800 placeholder-slate-400 font-medium focus:bg-white focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600 transition-all duration-200"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-650"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3">
            {/* Family selection */}
            <div className="min-w-[180px] w-full sm:w-auto">
              <label className="block text-[9px] font-black tracking-widest text-slate-450 uppercase mb-1.5">Family Filter</label>
              <select
                value={selectedFamily}
                onChange={(e) => setSelectedFamily(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white py-2.5 px-3.5 text-xs text-slate-700 font-extrabold focus:border-emerald-600 focus:outline-none"
              >
                {uniqueFamilies.map(fam => (
                  <option key={fam} value={fam}>{fam}</option>
                ))}
              </select>
            </div>

            {/* Items Per Page dropdown */}
            <div className="min-w-[120px] w-full sm:w-auto">
              <label className="block text-[9px] font-black tracking-widest text-slate-450 uppercase mb-1.5">Page Size</label>
              <select
                value={itemsPerPage}
                onChange={(e) => {
                  setItemsPerPage(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="w-full rounded-xl border border-slate-200 bg-white py-2.5 px-3.5 text-xs text-slate-700 font-extrabold focus:border-emerald-600 focus:outline-none"
              >
                <option value={10}>10 plants</option>
                <option value={25}>25 plants</option>
                <option value={50}>50 plants</option>
                <option value={100}>100 plants</option>
              </select>
            </div>
          </div>
        </div>

        {/* Letter indexing quick-bar A-Z */}
        <div className="border-t border-slate-100 pt-4 flex items-start sm:items-center gap-3">
          <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider pt-1 sm:pt-0 shrink-0">Genus Index:</span>
          
          <div className="flex flex-wrap gap-1 items-center">
            <button
              onClick={() => setSelectedLetter('All')}
              className={`rounded-lg px-3 py-1 text-xs font-black transition-all ${
                selectedLetter === 'All'
                  ? 'bg-emerald-800 text-white shadow-md'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              All Genus
            </button>
            
            {alphabet.map((letter) => (
              <button
                key={letter}
                onClick={() => setSelectedLetter(letter)}
                className={`rounded-lg w-7 h-7 flex items-center justify-center text-xs font-black transition-all ${
                  selectedLetter === letter
                    ? 'bg-emerald-800 text-white shadow-md'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {letter}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Lookup statistics tracker */}
      <div className="flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 px-1 gap-2">
        <p className="font-medium text-slate-500">
          We found <span className="font-extrabold text-slate-800">{filteredFlora.length}</span> verified specimens
          {selectedLetter !== 'All' && <span> starting with Genus <span className="font-bold text-emerald-800">"{selectedLetter}"</span></span>}
          {selectedFamily !== 'All' && <span> in family <span className="font-bold text-emerald-800">"{selectedFamily}"</span></span>}
        </p>
        <p className="text-[11px] font-mono font-bold bg-slate-100 px-3 py-1 rounded-full text-slate-600">
          Showing {filteredFlora.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} to {Math.min(currentPage * itemsPerPage, filteredFlora.length)} of {filteredFlora.length} entries
        </p>
      </div>

      {/* Grid of beautifully designed Flora Card Monographs */}
      {filteredFlora.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-200 bg-white py-20 text-center text-slate-400 space-y-4 shadow-sm" id="empty_search_state">
          <div className="p-4 bg-slate-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto border border-slate-100">
            <Layers className="h-7 w-7 stroke-1 text-slate-400" />
          </div>
          <h3 className="text-lg font-extrabold text-slate-850">No Botanical Specimens Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed px-6">
            There are no entries matching your terms. Try relaxing family parameters, deleting your search keywords, or selecting 'All' underneath the Genus index.
          </p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedFamily('All');
              setSelectedLetter('All');
            }}
            className="rounded-xl bg-emerald-800 hover:bg-emerald-900 px-6 py-2.5 text-xs font-black text-white transition-all shadow-md inline-flex items-center gap-1.5"
          >
            Clear Filters & Reload
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="flora_cards_grid">
          {paginatedFlora.map((item) => {
            const isFav = favoriteIds.has(item.id);
            const isCopied = copiedId === item.id;
            
            return (
              <div
                key={item.id}
                onClick={() => setSelectedPlant(item)}
                className="group relative rounded-3xl border border-slate-150 bg-white p-5 shadow-sm hover:shadow-xl hover:border-emerald-500/30 hover:ring-4 hover:ring-emerald-500/5 transition-all duration-300 flex flex-col justify-between cursor-pointer"
              >
                {/* Visual botanical overlay on card */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50/20 rounded-full -mr-6 -mt-6 group-hover:scale-150 transition-transform duration-550 pointer-events-none" />

                <div className="space-y-4 relative z-10 w-full">
                  {/* Plant Picture for Easy Identification */}
                  {item.imageUrl && (
                    <div className="relative w-full h-44 rounded-2xl overflow-hidden bg-slate-50 border border-slate-100/60 shadow-sm shrink-0">
                      <img 
                        src={item.imageUrl} 
                        alt={item.botanicalName} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/30 via-transparent to-transparent pointer-events-none" />
                      <span className="absolute top-2 left-2 text-[8px] font-extrabold uppercase tracking-widest text-emerald-900 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded shadow backdrop-blur-sm">
                        📸 REAL PHOTO
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="font-mono text-[9px] text-slate-400 font-bold bg-slate-50 border border-slate-100 px-2 py-0.5 rounded-md">
                      #{item.id.replace('gh_flora_', '').padStart(4, '0')}
                    </span>
                    
                    <span className="rounded-full bg-emerald-50 border border-emerald-100/50 px-2.5 py-0.5 text-[9px] font-black text-emerald-800 uppercase tracking-wider shadow-inner">
                      {item.family}
                    </span>
                  </div>

                  {/* Botanical display headings */}
                  <div>
                    <h3 className="italic text-base sm:text-lg font-black font-display text-slate-850 group-hover:text-emerald-800 transition-colors leading-snug">
                      {item.botanicalName}
                    </h3>
                    <p className="text-xs font-bold text-slate-500 mt-0.5 flex items-center gap-1">
                      <span className="font-black text-slate-400 text-[10px] uppercase">Common:</span> {item.commonName}
                    </p>
                  </div>

                  {/* Tribally authentic name bar */}
                  <div className="bg-slate-50/75 py-2.5 px-3 rounded-2xl border border-slate-100 text-xs text-slate-600 transition-all group-hover:bg-emerald-50/15">
                    <span className="block text-[8px] uppercase tracking-widest font-black text-slate-450 mb-0.5">National Local Names</span>
                    <p className="font-extrabold text-slate-700 leading-tight">
                      {item.localName}
                    </p>
                  </div>

                  {/* Concise teaser details (Distribution + Actives) */}
                  <div className="space-y-1.5 text-[11px] text-slate-500">
                    <div className="flex items-start gap-1">
                      <MapPin className="h-3 w-3 text-emerald-700 mt-0.5 shrink-0" />
                      <p className="line-clamp-1"><span className="font-bold text-slate-700">Region:</span> {item.distribution}</p>
                    </div>
                    <div className="flex items-start gap-1">
                      <FlaskConical className="h-3 w-3 text-emerald-700 mt-0.5 shrink-0" />
                      <p className="line-clamp-1">
                        <span className="font-bold text-slate-700">Actives:</span> {item.constituents?.join(', ') || 'N/A'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100/70 flex items-center justify-between gap-4 relative z-10">
                  <span className="text-[9px] text-teal-800 font-black uppercase tracking-wider bg-teal-50 px-2.5 py-1 rounded-md border border-teal-100/40 flex items-center gap-1 group-hover:bg-teal-100/25 transition-colors">
                    <BookOpen className="h-2.5 w-2.5 text-teal-700" /> Monograph Profile
                  </span>
                  
                  {/* Small copy & save triggers */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => handleCopyMonograph(item, e)}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        isCopied 
                          ? 'bg-emerald-50 text-emerald-750 border-emerald-100' 
                          : 'bg-slate-50 text-slate-400 hover:text-slate-700 border-slate-150'
                      }`}
                      title="Copy plant monograph summary"
                    >
                      {isCopied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>

                    <button
                      onClick={(e) => handleToggleFavorite(item.id, e)}
                      className={`p-1.5 rounded-lg border transition-all ${
                        isFav 
                          ? 'bg-pink-50 text-pink-650 border-pink-100 shadow-sm' 
                          : 'bg-slate-50 text-slate-400 hover:text-pink-650 hover:bg-pink-50 border-slate-150'
                      }`}
                      title={isFav ? "Remove from favorites" : "Save to favorites"}
                    >
                      <Heart className={`h-3.5 w-3.5 ${isFav ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination Dashboard */}
      {filteredFlora.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-500 font-bold text-center sm:text-left">
            Active view: <span className="font-extrabold text-slate-800">{itemsPerPage}</span> specimens per page
          </div>

          <div className="flex items-center gap-1" id="pagination_controls">
            {/* First page */}
            <button
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
              className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              title="First Page"
            >
              <ChevronsLeft className="h-4 w-4 text-slate-600" />
            </button>

            {/* Prev page */}
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              title="Previous Page"
            >
              <ChevronLeft className="h-4 w-4 text-slate-600" />
            </button>

            {/* Numbers */}
            <div className="hidden sm:flex items-center gap-1">
              {pageNumbers[0] > 1 && (
                <>
                  <button
                    onClick={() => setCurrentPage(1)}
                    className="w-9 h-9 rounded-xl text-xs font-black text-slate-650 hover:bg-slate-50 transition-colors"
                  >
                    1
                  </button>
                  <span className="text-slate-300 text-xs px-1">...</span>
                </>
              )}

              {pageNumbers.map(num => (
                <button
                  key={num}
                  onClick={() => setCurrentPage(num)}
                  className={`w-9 h-9 rounded-xl text-xs font-black transition-all ${
                    currentPage === num
                      ? 'bg-emerald-800 text-white shadow-md shadow-emerald-800/10'
                      : 'text-slate-650 hover:bg-slate-50'
                  }`}
                >
                  {num}
                </button>
              ))}

              {pageNumbers[pageNumbers.length - 1] < totalPages && (
                <>
                  <span className="text-slate-300 text-xs px-1">...</span>
                  <button
                    onClick={() => setCurrentPage(totalPages)}
                    className="w-9 h-9 rounded-xl text-xs font-black text-slate-650 hover:bg-slate-50 transition-colors"
                  >
                    {totalPages}
                  </button>
                </>
              )}
            </div>

            {/* Mobile indicators */}
            <span className="sm:hidden text-xs font-black text-slate-600 px-3">
              Page {currentPage} of {totalPages}
            </span>

            {/* Next page */}
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              title="Next Page"
            >
              <ChevronRight className="h-4 w-4 text-slate-600" />
            </button>

            {/* Last page */}
            <button
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
              className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              title="Last Page"
            >
              <ChevronsRight className="h-4 w-4 text-slate-600" />
            </button>
          </div>
        </div>
      )}

      {/* Selected Plant Scientific Masterpiece Modal */}
      {selectedPlant && (
        <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden animate-scale-up flex flex-col max-h-[92vh]" id="flora_detail_modal">
            
            {/* Premium Emerald Header */}
            <div className="bg-gradient-to-br from-emerald-950 to-slate-950 px-6 py-5 text-white flex justify-between items-start shrink-0 relative">
              <div className="absolute top-0 right-0 bg-[radial-gradient(circle_at_right,_var(--tw-gradient-stops))] from-teal-500/10 to-transparent w-36 h-36 pointer-events-none"></div>
              
              <div className="space-y-1 relative z-10">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-emerald-800/80 text-emerald-200 text-[9px] uppercase tracking-wider font-extrabold px-2.5 py-0.5 border border-emerald-700/55">
                    GH PHARMACOPOEIA • #{selectedPlant.id.replace('gh_flora_','').padStart(4, '0')}
                  </span>
                  {favoriteIds.has(selectedPlant.id) && (
                    <span className="text-pink-400 text-xs font-bold leading-none flex items-center gap-0.5">
                      <Heart className="h-3.5 w-3.5 fill-current" /> Favorited
                    </span>
                  )}
                </div>
                <h2 className="text-xl sm:text-2xl font-black italic tracking-tight font-display text-white mt-1.5">{selectedPlant.botanicalName}</h2>
                <p className="text-xs text-emerald-300 font-extrabold">Taxonomic Family: {selectedPlant.family}</p>
              </div>

              <button
                onClick={() => setSelectedPlant(null)}
                className="rounded-full bg-white/5 hover:bg-white/15 p-2 text-white/80 hover:text-white transition-colors cursor-pointer shrink-0 border border-white/5"
                title="Close plant monograph"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Modal Body - Scrollable content */}
            <div className="p-6 space-y-6 overflow-y-auto">
              
              {/* Detailed Specimen Photograph */}
              {selectedPlant.imageUrl && (
                <div className="relative w-full h-56 rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 shadow-inner shrink-0">
                  <img
                    src={selectedPlant.imageUrl}
                    alt={selectedPlant.botanicalName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-transparent pointer-events-none" />
                  <div className="absolute bottom-3 left-4 text-white drop-shadow-md">
                    <p className="text-[10px] uppercase font-black tracking-widest text-emerald-300 flex items-center gap-1">
                      <span>📸 Verified Non-AI Specimen Photo</span>
                    </p>
                    <p className="text-xs font-bold italic">{selectedPlant.botanicalName}</p>
                  </div>
                </div>
              )}

              {/* Nomenclature Cards Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <span className="block text-[8px] uppercase font-black tracking-wider text-slate-400">Common Standard Name</span>
                  <span className="text-sm font-extrabold text-slate-800 block mt-1">{selectedPlant.commonName}</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <span className="block text-[8px] uppercase font-black tracking-wider text-slate-400">Ghanaian Local Designations</span>
                  <span className="text-sm font-extrabold text-emerald-850 leading-tight block mt-1">{selectedPlant.localName}</span>
                </div>
              </div>

              {/* TWO MAJOR ACTIVE CONSTITUENTS (Bento Highlight Box) */}
              <div className="space-y-3">
                <div className="flex items-center gap-1 border-b border-slate-100 pb-2">
                  <FlaskConical className="h-4.5 w-4.5 text-emerald-800 shrink-0" />
                  <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">
                    Two Major Active Constituents
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="active_constituents_grid">
                  {selectedPlant.constituents?.map((constituent, index) => (
                    <div 
                      key={constituent}
                      className="bg-emerald-50/25 border border-emerald-100 p-4 rounded-2xl flex items-start gap-3 transition-shadow hover:shadow-sm"
                    >
                      <div className="rounded-xl bg-emerald-100/50 p-2 text-emerald-800 font-bold shrink-0 text-xs">
                        0{index + 1}
                      </div>
                      <div>
                        <h5 className="font-extrabold text-xs text-slate-500 uppercase tracking-wide">Chemical Phytochemical</h5>
                        <p className="font-black text-sm text-emerald-950 mt-0.5">{constituent}</p>
                        <p className="text-[10px] text-slate-450 leading-normal mt-0.5">Verified marker in high-performance liquid chromatography index.</p>
                      </div>
                    </div>
                  ))}
                  {(!selectedPlant.constituents || selectedPlant.constituents.length === 0) && (
                    <p className="text-xs text-slate-400 italic">No constituents index logged on this system specimen.</p>
                  )}
                </div>
              </div>

              {/* GEOGRAPHICAL DISTRIBUTION */}
              <div className="space-y-3">
                <div className="flex items-center gap-1 border-b border-slate-100 pb-2">
                  <MapPin className="h-4.5 w-4.5 text-emerald-800 shrink-0" />
                  <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">
                    Geographical Distribution IN Ghana
                  </h4>
                </div>
                <div className="bg-slate-50/75 border border-slate-100 rounded-2xl p-4 flex gap-3.5 items-start">
                  <div className="rounded-full bg-slate-200/50 p-2 text-slate-600 shrink-0 mt-0.5">
                    <Compass className="h-4.5 w-4.5 text-emerald-800" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-xs text-slate-700">Native Habitat & Adaptation Areas</h5>
                    <p className="text-xs text-slate-600 leading-relaxed mt-1">{selectedPlant.distribution || "Deciduous forest fallows, coastal brush pathways, and high-altitude transition ecosystems of southern and central Ghana."}</p>
                  </div>
                </div>
              </div>

              {/* CORE PHARMACOPOEIA USES */}
              <div className="space-y-3">
                <div className="flex items-center gap-1 border-b border-slate-100 pb-2">
                  <Activity className="h-4.5 w-4.5 text-emerald-800 shrink-0" />
                  <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">
                    Therapeutic & Pharmacological Uses
                  </h4>
                </div>
                <div className="bg-teal-50/15 border border-teal-100 rounded-2xl p-4 flex gap-3.5 items-start">
                  <div className="rounded-xl bg-teal-100/50 p-2.5 text-teal-800 shrink-0">
                    <Activity className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-xs text-slate-700 uppercase tracking-wider">Approved Clinical Indications</h5>
                    <p className="text-xs text-slate-800 font-extrabold leading-relaxed mt-1">{selectedPlant.uses}</p>
                    <p className="text-[10px] text-slate-450 leading-relaxed mt-1.5 font-medium">Approved by the Ghana Ministry of Health for formulation as standardized decoctions, dry powder infusions, or solid capsule treatments.</p>
                  </div>
                </div>
              </div>

              {/* Clinical safety warning */}
              <div className="bg-amber-50/50 border border-amber-100/80 text-amber-900 text-xs p-4 rounded-2xl flex items-start gap-3">
                <ShieldAlert className="h-5 w-5 text-amber-800 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-black text-[11px] uppercase tracking-wide">Pharmacopoeia Advisory Marker</p>
                  <p className="text-[11px] leading-relaxed text-slate-600">
                    All formulations based on this profile must submit and query quality validation checks. Total ash counts should not exceed GHEMSA medical thresholds. Clinical dosing requires oversight by a licensed medical phytotherapist.
                  </p>
                </div>
              </div>
            </div>

            {/* Modal footer */}
            <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-t border-slate-100 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => handleToggleFavorite(selectedPlant.id, e)}
                  className={`inline-flex items-center gap-1.5 px-4.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer border ${
                    favoriteIds.has(selectedPlant.id)
                      ? 'bg-pink-50 text-pink-650 border-pink-100'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-55'
                  }`}
                >
                  <Heart className={`h-3.5 w-3.5 ${favoriteIds.has(selectedPlant.id) ? 'fill-current' : ''}`} />
                  {favoriteIds.has(selectedPlant.id) ? 'Saved' : 'Save To Study Basket'}
                </button>

                <button
                  onClick={(e) => handleCopyMonograph(selectedPlant, e)}
                  className={`px-4.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer border ${
                    copiedId === selectedPlant.id 
                    ? 'bg-emerald-50 text-emerald-750 border-emerald-100'
                    : 'bg-white text-slate-650 border-slate-250 hover:bg-slate-55'
                  }`}
                >
                  {copiedId === selectedPlant.id ? 'Copied Details!' : 'Copy Monograph Info'}
                </button>
              </div>

              <button
                onClick={() => setSelectedPlant(null)}
                className="bg-emerald-850 hover:bg-emerald-950 text-white px-6 py-2 rounded-xl text-xs font-black shadow-md shadow-emerald-950/10 transition-all cursor-pointer"
              >
                Close Specimen Journal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
