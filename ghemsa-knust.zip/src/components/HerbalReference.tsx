import React, { useState } from 'react';
import { HERBAL_RESOURCES } from '../data/courses';
import { Search, Sprout, ShieldAlert, Sparkles, AlertCircle, FileText, Loader2, ServerCrash, FolderCheck, CheckCircle2, FlaskConical, ArrowRight } from 'lucide-react';
import { findOrCreateAppFolder, uploadNoteToDrive } from '../auth';
import { getApiUrl } from '../utils/api';

interface HerbalReferenceProps {
  accessToken: string | null;
  onLoginRequest: () => void;
}

export default function HerbalReference({ accessToken, onLoginRequest }: HerbalReferenceProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHerb, setSelectedHerb] = useState(HERBAL_RESOURCES[0]);

  // AI formulation state
  const [targetIndication, setTargetIndication] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [formulationResult, setFormulationResult] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);

  // Drive sync state
  const [syncingToDrive, setSyncingToDrive] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);

  const filteredHerbs = HERBAL_RESOURCES.filter(
    (herb) =>
      herb.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      herb.botanicalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      herb.localName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      herb.family.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateAIFormulation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetIndication.trim()) return;

    setIsGenerating(true);
    setErrorText(null);
    setFormulationResult(null);
    setSyncSuccess(false);

    try {
      // Create context block with our natural herbal database to reference
      const contextText = HERBAL_RESOURCES.map((herb) => (
        `Plant name: ${herb.name}\n` +
        `Botanical: ${herb.botanicalName} (${herb.family})\n` +
        `Acan Local: ${herb.localName}\n` +
        `Actives: ${herb.activeConstituents.join(', ')}\n` +
        `Pharmacological Actions: ${herb.pharmacologicalActions.join(', ')}\n` +
        `Preparation: ${herb.preparation}\n` +
        `Warnings: ${herb.contraindications}\n`
      )).join('\n---\n');

      const response = await fetch(getApiUrl('/api/gemini/generate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Using GHEMSA botanical assets where applicable, draft a clinical Herbal Drug Formulation recipe for this target indication: "${targetIndication}". Highlight botanical choices, extraction safety guidelines, dosing, and critical toxicological warnings.`,
          context: contextText,
        }),
      });

      if (!response.ok) {
        throw new Error('Our GHEMSA AI companion is currently recovering. Please try again.');
      }

      const data = await response.json();
      setFormulationResult(data.text);
    } catch (err: any) {
      console.error('AI formulation error:', err);
      setErrorText(err.message || 'Server error drafting formulation.');
    } finally {
      setIsGenerating(false);
    }
  };

  const syncFormulationToDrive = async () => {
    if (!accessToken) {
      onLoginRequest();
      return;
    }
    if (!formulationResult) return;

    setSyncingToDrive(true);
    try {
      const folderId = await findOrCreateAppFolder(accessToken);
      const title = `AI Formulated Recipe - ${targetIndication.slice(0, 30)}`;
      await uploadNoteToDrive(accessToken, folderId, title, formulationResult);
      setSyncSuccess(true);
    } catch (err) {
      console.error('Failed sync formulation:', err);
      alert('Error uploading to Google Drive. Check permissions.');
    } finally {
      setSyncingToDrive(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="herbal_reference_view_root">
      {/* Title */}
      <div className="border-b border-slate-100 pb-5">
        <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
          <Sprout className="h-6 w-6 text-emerald-700" /> Botanical Monographs & Formulation Lab
        </h1>
        <p className="text-sm text-slate-500">
          Inspect clinical plant profiles local to Ghana, or utilize the GHEMSA AI Lab to draft synergistic formulations.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar Herb Directory */}
        <div className="space-y-4" id="reference_sidebar_explorer">
          <div className="relative">
            <input
              type="text"
              placeholder="Search botanical profiles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-4 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          </div>

          <div className="rounded-xl border border-slate-100 bg-white h-[440px] overflow-y-auto p-2 space-y-1 scrollbar-thin">
            {filteredHerbs.map((herb) => (
              <button
                key={herb.id}
                onClick={() => setSelectedHerb(herb)}
                className={`w-full text-left p-3 rounded-lg text-xs transition-all flex justify-between items-center ${
                  selectedHerb.id === herb.id
                    ? 'bg-emerald-50 text-emerald-950 font-bold border-l-4 border-emerald-700'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="space-y-0.5">
                  <span className="font-bold block tracking-tight">{herb.name}</span>
                  <span className="italic block text-[10px] text-slate-400">{herb.botanicalName}</span>
                </div>
                <ArrowRight className={`h-3 w-3 text-slate-300 ${selectedHerb.id === herb.id ? 'text-emerald-700' : ''}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Selected Herb Monographs details */}
        <div className="lg:col-span-2 space-y-6" id="monograph_detail_panel">
          {selectedHerb && (
            <div className="rounded-2xl border border-slate-100 bg-white p-6 md:p-8 shadow-sm space-y-6">
              {/* Botanical header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-50 pb-5">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                    Family: {selectedHerb.family}
                  </span>
                  <h2 className="text-2xl font-black text-slate-800">{selectedHerb.name}</h2>
                  <p className="text-sm italic font-medium text-slate-500">{selectedHerb.botanicalName}</p>
                </div>
                <div className="text-right sm:text-right text-xs">
                  <span className="text-slate-400">Ghanaian Name:</span>
                  <p className="font-bold text-slate-700 text-sm mt-0.5">{selectedHerb.localName}</p>
                </div>
              </div>

              {/* Grid indices */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                <div className="space-y-1.5 p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="font-black text-slate-700 uppercase tracking-widest block">Active Chemical Constituents</span>
                  <ul className="list-disc pl-4 space-y-1 text-slate-600">
                    {selectedHerb.activeConstituents.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-1.5 p-4 bg-emerald-50/[0.25] rounded-xl border border-emerald-100/50">
                  <span className="font-black text-emerald-800 uppercase tracking-widest block">Pharmacological Actions</span>
                  <ul className="list-disc pl-4 space-y-1 text-emerald-950">
                    {selectedHerb.pharmacologicalActions.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Prep & Contra */}
              <div className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <span className="font-bold text-slate-800">Therapeutic Indications</span>
                  <p className="text-slate-600 leading-relaxed bg-slate-50/50 px-4 py-3 rounded-lg border border-slate-100">
                    {selectedHerb.therapeuticUses.join(', ')}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <span className="font-bold text-slate-800">Clinical Compounding & Preparation</span>
                  <p className="text-slate-600 leading-relaxed bg-slate-50/50 px-4 py-3 rounded-lg border border-slate-100">
                    {selectedHerb.preparation}
                  </p>
                </div>

                <div className="rounded-xl border border-rose-100 bg-rose-50/30 p-4 text-rose-950 flex items-start gap-3">
                  <ShieldAlert className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <span className="font-bold block text-slate-900">Clinical Safety & Contraindications</span>
                    <p className="text-rose-900 leading-relaxed">{selectedHerb.contraindications}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* AI Compounding Lab Section */}
      <div 
        className="rounded-2xl border border-slate-100 bg-white p-6 md:p-8 shadow-sm space-y-6 relative overflow-hidden"
        id="ghemsa_ai_formulation_section"
      >
        <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
          <FlaskConical className="h-40 w-40 text-emerald-800" />
        </div>
        
        <div className="max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700 border border-emerald-100">
            <Sparkles className="h-3.5 w-3.5 animate-bounce" /> Clinical Assistant
          </div>
          <h2 className="text-xl font-black text-slate-800">GHEMSA Clinical Formulation Lab</h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            Enter physical diagnoses or specific therapeutic goals. Our AI engine compiles custom, standardized compounding recipes using the official Ghana Herbal Pharmacopoeia standards.
          </p>
        </div>

        <form onSubmit={handleCreateAIFormulation} className="max-w-3xl space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              required
              placeholder="e.g. anti-pyretic supportive decoction, or wound powder for scabies rash..."
              value={targetIndication}
              onChange={(e) => setTargetIndication(e.target.value)}
              className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-800 placeholder-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={isGenerating}
              className="rounded-xl bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-xs py-3 px-6 select-none transition-all shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Blending actives...
                </>
              ) : (
                'Formulate Recipe'
              )}
            </button>
          </div>
        </form>

        {/* Formulation results block */}
        {errorText && (
          <div className="rounded-xl border border-rose-100 bg-rose-50/50 p-4 text-xs text-rose-800 flex items-center gap-2 max-w-3xl">
            <AlertCircle className="h-4.5 w-4.5" /> {errorText}
          </div>
        )}

        {formulationResult && (
          <div className="space-y-4 max-w-4xl border border-slate-100 rounded-xl bg-slate-50/50 p-6 animate-slide-in" id="formulation_output_box">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <FileText className="h-4 w-4 text-emerald-700" /> Compounded Monograph Draft
              </span>
              
              {/* Google Drive export option! */}
              {syncSuccess ? (
                <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-emerald-800 bg-emerald-100 border border-emerald-200 px-3 py-1 pb-1.5 rounded-lg">
                  <CheckCircle2 className="h-4 w-4" /> Exported to Drive Folder!
                </span>
              ) : syncingToDrive ? (
                <button
                  disabled
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 border border-emerald-100 px-3 py-1 pb-1.5 text-xs font-bold text-emerald-800"
                >
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> Exporting...
                </button>
              ) : (
                <button
                  onClick={syncFormulationToDrive}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white px-3 py-1 pb-1.5 text-xs font-bold transition-all shadow-sm"
                >
                  <FolderCheck className="h-4 w-4" /> Save to Google Drive
                </button>
              )}
            </div>

            {/* Markdown content container */}
            <div className="prose prose-emerald prose-xs max-w-none text-slate-700 leading-relaxed font-sans whitespace-pre-wrap bg-white p-5 rounded-lg border border-slate-100">
              {formulationResult}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
