import React, { useState, useEffect, useRef } from 'react';
import { BookOpen, FolderDown, Search, CheckCircle, Loader2, RefreshCw, Layers, ExternalLink, Upload, FileText, X, AlertCircle, Sparkles } from 'lucide-react';
import { LEARNING_MATERIALS } from '../data/courses';
import { findOrCreateAppFolder, uploadNoteToDrive, db } from '../auth';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import CurriculumRevision from './CurriculumRevision';

interface LearningMaterialsProps {
  currentLevel: 100 | 200 | 300 | 400;
  accessToken: string | null;
  onLoginRequest: () => void;
}

export default function LearningMaterials({ currentLevel, accessToken, onLoginRequest }: LearningMaterialsProps) {
  const [filterType, setFilterType] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Custom-uploaded materials state
  const [customMaterials, setCustomMaterials] = useState<any[]>([]);
  const [isLoadingDb, setIsLoadingDb] = useState(false);

  // Curriculum revision active state
  const [activeRevisionMaterial, setActiveRevisionMaterial] = useState<any | null>(null);

  // Upload Slide Form State
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    type: 'Lecture Slide',
    description: '',
    courseCode: '',
    courseName: '',
  });

  // Drag and drop states
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState(false);

  // Tracking sync states of materials
  const [syncStates, setSyncStates] = useState<Record<string, 'idle' | 'syncing' | 'success' | 'detail' | 'error'>>({});

  const types = ['All', 'Lecture Slide', 'Lab Manual', 'Monograph', 'Reference Sheet'];

  // Load custom materials on mount
  const loadCustomResources = async () => {
    setIsLoadingDb(true);
    try {
      const qSnap = await getDocs(collection(db, 'uploaded_materials'));
      const list: any[] = [];
      qSnap.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() });
      });
      
      // Save local backup as cache
      if (list.length > 0) {
        localStorage.setItem('ghemsa_uploaded_slides', JSON.stringify(list));
        setCustomMaterials(list);
      } else {
        const saved = localStorage.getItem('ghemsa_uploaded_slides');
        if (saved) {
          setCustomMaterials(JSON.parse(saved));
        }
      }
    } catch (err) {
      console.warn('Firestore fetch failed/offline, using local storage cache fallback:', err);
      const saved = localStorage.getItem('ghemsa_uploaded_slides');
      if (saved) {
        setCustomMaterials(JSON.parse(saved));
      }
    } finally {
      setIsLoadingDb(false);
    }
  };

  useEffect(() => {
    loadCustomResources();
  }, []);

  // Merge static resource with dynamic custom uploaded ones
  const allResources = [...LEARNING_MATERIALS, ...customMaterials];

  const filteredMaterials = allResources.filter((mat) => {
    const matchesLevel = mat.level === currentLevel;
    const matchesType = filterType === 'All' || mat.type === filterType;
    const matchesSearch =
      mat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mat.courseCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mat.courseName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesLevel && matchesType && matchesSearch;
  });

  const handleSyncToDrive = async (materialId: string, title: string, desc: string, code: string, type: string) => {
    if (!accessToken) {
      onLoginRequest(); // Force auth trigger
      return;
    }

    setSyncStates((prev) => ({ ...prev, [materialId]: 'syncing' }));

    try {
      const folderId = await findOrCreateAppFolder(accessToken);

      const markdownContent = `# GHEMSA KNUST Learning Resource\n\n` +
        `**Course:** ${code} - L${currentLevel} Core\n` +
        `**Material Title:** ${title}\n` +
        `**Type Reference:** ${type}\n` +
        `**Date Sync:** ${new Date().toLocaleDateString()}\n\n` +
        `## Overview Summary\n${desc}\n\n` +
        `## Academic Review Scratchpad\n*Use this document as an active study deck for exams. Core classification and pharmacognosy parameters of Ghanaian plants should be filled below.*\n\n` +
        `---\n*GHEMSA Academic Portal Sync • Kwame Nkrumah University of Science & Technology.*`;

      await uploadNoteToDrive(accessToken, folderId, `[L${currentLevel}] ${title}`, markdownContent);

      setSyncStates((prev) => ({ ...prev, [materialId]: 'success' }));
    } catch (err) {
      console.error('Failed to sync material to Google Drive:', err);
      setSyncStates((prev) => ({ ...prev, [materialId]: 'error' }));
    }
  };

  // Drag handlings
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  // Process File selection
  const processFile = (file: File) => {
    setUploadedFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setFileBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Submit slide form
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setUploadSuccess(false);

    const { title, courseCode, courseName, description, type } = formData;
    if (!title || !courseCode || !courseName || !description) {
      setFormError('All fields (Title, Course Code, Course Title, and Summary) are required.');
      return;
    }

    setIsSubmitting(true);
    try {
      const newMaterial = {
        id: `custom_mat_${Date.now()}`,
        title,
        type,
        description,
        level: currentLevel,
        courseCode: courseCode.toUpperCase(),
        courseName,
        fileName: uploadedFile ? uploadedFile.name : 'LectureNotesSummary.txt',
        fileDataUrl: fileBase64 || 'data:text/plain;base64,R0hFTVNBIExlY3R1cmUgTm90ZXM=',
        uploadedBy: 'Student Administrator',
        createdAt: new Date().toISOString()
      };

      // 1. Try to post to Firestore
      try {
        await addDoc(collection(db, 'uploaded_materials'), newMaterial);
      } catch (fError) {
        console.warn('Could not save to active Firebase collection (offline/permission), falling back to local list cache.', fError);
      }

      // 2. Add to local state and update local storage as reliable backup
      const updatedList = [...customMaterials, newMaterial];
      setCustomMaterials(updatedList);
      localStorage.setItem('ghemsa_uploaded_slides', JSON.stringify(updatedList));

      setUploadSuccess(true);
      setFormData({
        title: '',
        type: 'Lecture Slide',
        description: '',
        courseCode: '',
        courseName: '',
      });
      setUploadedFile(null);
      setFileBase64('');
      
      // Close form delay
      setTimeout(() => {
        setIsUploadOpen(false);
        setUploadSuccess(false);
      }, 1500);

    } catch (err: any) {
      console.error('Upload failed:', err);
      setFormError('Uploading slides failed. Try checking your storage connectivity.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Trigger download of base64
  const handleDownloadFile = (fileName: string, mime: string, base64: string) => {
    const link = document.createElement('a');
    link.href = base64;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="learning_materials_root">
      {/* Header with quick contact number callout */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-emerald-700" /> Study Guides & Slide Decks
          </h1>
          <p className="text-sm text-slate-500">
            Browse core documents for <span className="font-bold text-emerald-800">Level {currentLevel}</span> and export backups to your Google Drive
          </p>
        </div>

        {/* Buttons & Search */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsUploadOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white px-4 py-2 text-xs font-black shadow-sm transition-all cursor-pointer"
            id="btn_upload_slides_path"
          >
            <Upload className="h-4 w-4" /> Upload New Slides
          </button>

          <div className="relative w-full sm:w-64">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="h-4 w-4" />
            </div>
            <input
              type="search"
              placeholder="Search slides, courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-4 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Slide Uploader Modal Portal Modal */}
      {isUploadOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-scale-up" id="slides_upload_form_modal">
            {/* Modal Head */}
            <div className="bg-emerald-800 px-6 py-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                <h3 className="font-black text-base">GHEMSA Slides Upload Portal</h3>
              </div>
              <button
                onClick={() => {
                  setIsUploadOpen(false);
                  setFormError('');
                }}
                className="rounded-full hover:bg-white/10 p-1.5 hover:text-white transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body form */}
            <form onSubmit={handleFormSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              {formError && (
                <div className="bg-rose-50 border border-rose-100 text-rose-800 text-xs p-3.5 rounded-lg flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <p className="font-bold underline">{formError}</p>
                </div>
              )}

              {uploadSuccess && (
                <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs p-3.5 rounded-lg flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 shrink-0 mt-0.5 text-emerald-700" />
                  <p className="font-bold">Slides successfully shared! Adding to the level courses database.</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">KNUST Class Level</label>
                  <input
                    type="text"
                    disabled
                    value={`Level ${currentLevel}`}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 px-3 text-xs font-bold text-slate-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Material Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData((prev) => ({ ...prev, type: e.target.value }))}
                    className="w-full rounded-lg border border-slate-200 bg-white py-2 px-3 text-xs text-slate-700 font-bold focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="Lecture Slide">Lecture Slide</option>
                    <option value="Lab Manual">Lab Manual</option>
                    <option value="Monograph">Monograph</option>
                    <option value="Reference Sheet">Reference Sheet</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Course Code</label>
                  <input
                    type="text"
                    placeholder="e.g. HRM 353"
                    value={formData.courseCode}
                    onChange={(e) => setFormData((prev) => ({ ...prev, courseCode: e.target.value }))}
                    className="w-full rounded-lg border border-slate-200 bg-white py-2 px-3 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Course Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Phytotherapy & Therapeutics"
                    value={formData.courseName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, courseName: e.target.value }))}
                    className="w-full rounded-lg border border-slate-200 bg-white py-2 px-3 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Material / Slide Title</label>
                <input
                  type="text"
                  placeholder="e.g. Isolation Protocols and Chromatographic Separation"
                  value={formData.title}
                  onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 bg-white py-2 px-3 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Summary Study Notes</label>
                <textarea
                  placeholder="Describe key formulas, page references, important chemical compounds or diagnostic parameters covered..."
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  className="w-full rounded-lg border border-slate-200 bg-white py-2 px-3 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Usability Pattern Drag and Drop Area */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Attach Slide Deck / Document</label>
                <div
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer ${
                    dragActive
                      ? 'border-emerald-500 bg-emerald-50'
                      : uploadedFile
                      ? 'border-teal-300 bg-teal-50/20'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50'
                  }`}
                  onClick={() => document.getElementById('slide-file-selector')?.click()}
                >
                  <input
                    type="file"
                    id="slide-file-selector"
                    className="hidden"
                    onChange={handleFileChange}
                    accept=".pdf,.ppt,.pptx,.doc,.docx,.txt,.md,.png,.jpg"
                  />
                  {uploadedFile ? (
                    <div className="space-y-2 text-xs">
                      <div className="rounded-full bg-teal-100 p-2 text-teal-800 w-10 h-10 flex items-center justify-center mx-auto">
                        <FileText className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-extrabold text-slate-700 truncate max-w-xs mx-auto">{uploadedFile.name}</p>
                        <p className="text-[10px] text-slate-400">{(uploadedFile.size / 1024).toFixed(1)} KB • Click to replace</p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2 text-xs">
                      <div className="rounded-full bg-slate-100 p-2.5 text-slate-400 w-10.5 h-10.5 flex items-center justify-center mx-auto">
                        <Upload className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-600">Drag & drop your slide here, or <span className="text-emerald-800 font-extrabold underline">browse file</span></p>
                        <p className="text-[10px] text-slate-400 mt-1">Supports PDF, slides (PPT), documents (DOC, TXT, MD) or anatomy images</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Modal footer submit */}
              <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsUploadOpen(false);
                    setFormError('');
                  }}
                  className="rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-4 py-2 text-xs font-bold text-slate-600 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white px-5 py-2 text-xs font-black shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" /> Sharing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-3.5 w-3.5" /> Submit Material
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Filter Chips */}
      <div className="flex flex-wrap gap-2 animate-fade-in" id="filter_chips_wrap">
        {types.map((type) => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
              filterType === type
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      {isLoadingDb && (
        <div className="flex justify-center items-center py-6 gap-2 text-slate-400 text-xs">
          <Loader2 className="h-4 w-4 animate-spin text-emerald-800" />
          <span>Synchronizing library resources with live cloud database...</span>
        </div>
      )}

      {/* Grid of Materials */}
      {filteredMaterials.length === 0 ? (
        <div className="rounded-xl border border-slate-100 bg-white py-12 text-center text-slate-400 space-y-3">
          <Layers className="h-12 w-12 mx-auto stroke-1" />
          <p className="text-xs">No study resources found matching the specified parameters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="materials_cards_grid">
          {filteredMaterials.map((mat) => {
            const status = syncStates[mat.id] || 'idle';
            const isCustom = mat.id.startsWith('custom_mat_');

            return (
              <div
                key={mat.id}
                className={`rounded-xl border p-6 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between ${
                  isCustom 
                    ? 'border-emerald-200 bg-emerald-50/15 ring-1 ring-emerald-500/10'
                    : 'border-slate-100 bg-white'
                }`}
              >
                <div className="space-y-4">
                  {/* Category badging */}
                  <div className="flex items-center justify-between">
                    <span className={`inline-block rounded px-2.5 py-1 text-xs font-bold uppercase tracking-wide ${
                      isCustom 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-teal-50 text-teal-800'
                    }`}>
                      {mat.type} {isCustom && '• Shared'}
                    </span>
                    <span className="text-xs font-bold text-slate-400">{mat.courseCode}</span>
                  </div>

                  {/* Course name */}
                  <div className="space-y-1">
                    <h3 className="text-sm font-semibold text-slate-400">{mat.courseName}</h3>
                    <h2 className="text-base font-extrabold text-slate-800 leading-tight">
                      {mat.title}
                    </h2>
                  </div>

                  {/* Summary */}
                  <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                    {mat.description}
                  </p>

                  {/* If custom, show attached slide filename */}
                  {isCustom && mat.fileName && (
                    <div className="flex items-center gap-1.5 bg-slate-100/60 transition-all hover:bg-slate-100 rounded-lg p-2.5 border border-slate-200">
                      <FileText className="h-4 w-4 text-emerald-800 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-bold text-slate-700 truncate">{mat.fileName}</p>
                        <p className="text-[8px] font-bold text-emerald-800 uppercase tracking-tight mt-0.5">Ready for review</p>
                      </div>
                      <button
                        onClick={() => handleDownloadFile(mat.fileName, 'application/octet-stream', mat.fileDataUrl)}
                        className="rounded bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold px-2.5 py-1 text-[9px] cursor-pointer"
                      >
                        Download
                      </button>
                    </div>
                  )}
                </div>

                {/* Foot Action Buttons */}
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-3 flex-wrap">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                    Level {mat.level} Core
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveRevisionMaterial(mat)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 border border-emerald-100 hover:bg-emerald-100 text-emerald-800 font-extrabold px-3 py-1.5 text-xs shadow-sm transition-all cursor-pointer"
                      title="Start custom curriculum revision"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-emerald-800" />
                      <span>Syllabus Revision</span>
                    </button>

                    {status === 'success' ? (
                      <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100 animate-slide-in">
                        <CheckCircle className="h-4 w-4" /> Synced to Drive!
                      </div>
                    ) : status === 'syncing' ? (
                      <button
                        disabled
                        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 border border-emerald-100 px-4 py-1.5 text-xs font-bold text-emerald-800"
                      >
                        <Loader2 className="h-3.5 w-3.5 animate-spin" /> Synchronizing...
                      </button>
                    ) : status === 'error' ? (
                      <button
                        onClick={() => handleSyncToDrive(mat.id, mat.title, mat.description, mat.courseCode, mat.type)}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-rose-50 border border-rose-100 hover:bg-rose-100 px-4 py-1.5 text-xs font-bold text-rose-800 transition-colors"
                      >
                        <RefreshCw className="h-3.5 w-3.5" /> Re-try
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSyncToDrive(mat.id, mat.title, mat.description, mat.courseCode, mat.type)}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 border border-emerald-950 shadow-sm text-white px-4 py-1.5 text-xs font-bold transition-all cursor-pointer"
                        id={`btn_sync_${mat.id}`}
                      >
                        <FolderDown className="h-4 w-4" /> Backup
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Info Notice */}
      <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-5 flex items-start gap-4">
        <div className="rounded-full bg-slate-100 p-2 text-slate-400 shrink-0">
          <ExternalLink className="h-5 w-5" />
        </div>
        <div className="space-y-1 text-xs text-slate-600 leading-relaxed">
          <p className="font-bold text-slate-700">How Drive Synchronization Works</p>
          <p>
            When you back up a guide, the portal generates a pristine study monograph in standard Markdown (.md) and stores it in your Google Drive under a folder named <span className="font-bold text-slate-800">"GHEMSA KNUST Study Notebook"</span>. You can read, print, or edit this text directly via Google Docs anytime!
          </p>
        </div>
      </div>

      {activeRevisionMaterial && (
        <CurriculumRevision
          material={activeRevisionMaterial}
          onClose={() => setActiveRevisionMaterial(null)}
        />
      )}
    </div>
  );
}
