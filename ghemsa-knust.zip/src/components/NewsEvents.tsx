import React, { useState } from 'react';
import { Calendar, User, Search, Award, Sprout, ShieldCheck, Heart, ArrowRight, Building, BookOpen, Clock } from 'lucide-react';

interface NewsItem {
  id: string;
  category: 'Research' | 'Seminar' | 'Community' | 'Achievement';
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  readTime: string;
}

export default function NewsEvents() {
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);

  React.useEffect(() => {
    document.title = "News & Events | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const newsList: NewsItem[] = [
    {
      id: 'news_00',
      category: 'Achievement',
      title: 'Dr. Benard Turkson Assumes Office as the New Head of Department of Herbal Medicine',
      excerpt: 'Dr. Benard Turkson, a seasoned scholar and pharmacognosy researcher, has officially assumed the role of Head of Department at KNUST.',
      content: 'The College of Health Sciences is pleased to announce the appointment of Dr. Benard Turkson as the new Head of Department of Herbal Medicine at KNUST. He takes over the leadership with a deep commitment to elevating standard scientific inquiry into Ghanaian phytomedical therapies, advancing research lab capabilities, and strengthening student clinical programs.\n\n"I am highly honored to lead this unique, highly prestigious department," stated Dr. Turkson in his inaugural departmental address. "My focus will be to expand our pharmacopoeia digital assets, coordinate tighter clinical hospital training linkages for our scholars, and establish robust validation parameters for native formulations ready for commercial manufacture."\n\nFaculty, administrative staff, and the student body (GHEMSA) warmly congratulate Dr. Turkson on this appointment and express their gratitude to Dr. Joseph Osei-Duro for his dedicated years of leadership as he transitions back to his primary role as a senior researcher of phytopharmacology.',
      date: 'June 12, 2026',
      author: 'Office of the College Registrar',
      readTime: '2 min read'
    },
    {
      id: 'news_01',
      category: 'Research',
      title: 'KNUST Department of Herbal Medicine Secures GHS 450,000 Research Grant for Active Marker Stabilization',
      excerpt: 'The Ministry of Education, in partnership with GTEC, selects the department to lead a 3-year study analyzing the thermal preservation coordinates of Cryptolepis liquid decoctions.',
      content: 'Under the leadership of Principal Investigator Prof. Shirley Amponzah, the department has been awarded a major grant of GHS 450,000. The project, titled "Thermal Stability Profiles and Active Compound Preservation of Anti-plasmodial Formulations," will seek to address the active molecular decay that currently limits the shelf-life of indigenous liquid products in West Africa.\n\n"One of the major issues facing traditional medicines is the precipitation of key alkaloids during transport and warehouse storage," explained Prof. Amponzah. "This funding will enable us to configure active co-solvents and thermodynamic stabilizers to guarantee a reliable 12-month shelf life without altering the molecular chemistry."\n\nThe laboratory work will be executed primarily inside our updated Phytochemistry Isolation Laboratory with advanced High-Performance Liquid Chromatography (HPLC) screening. Level 400 research student teams will also be attached as junior research assistants, providing them with top-tier industrial exposure.',
      date: 'June 10, 2026',
      author: 'Office of College Publications',
      readTime: '3 min read'
    },
    {
      id: 'news_02',
      category: 'Achievement',
      title: 'Dr. Joseph Osei-Duro Appointed to World Health Organisation (WHO) Advisory Council on Pharmacognosy',
      excerpt: 'Our distinguished senior researcher was selected to coordinate regulatory criteria for traditional therapies across Sub-Saharan Africa.',
      content: 'We are proud to announce that our very own senior researcher and lecturer, Dr. Joseph Osei-Duro, has been appointed to the World Health Organisation (WHO) Expert Advisory Advisory Panel on traditional medicinals.\n\nIn this global regulatory role, Dr. Osei-Duro will serve a three-year tenure collaborating with researchers from India, China, Brazil, and international agencies. The panel is tasked with editing the 6th edition of the "WHO Guidelines for the Safety Evaluation of Botanical Medicines," expanding reference standards for heavy metal residues, pesticides, and active bio-marker quantitative testing.\n\n"This election reflects decades of rigorous academic persistence inside KNUST," noted Dr. Osei-Duro. "My focal focus will be to secure that ethnic African medicinal compounds receive appropriate, standard, and fair scientific evaluations, facilitating their smooth entry into global pharmaceutical supply chains."',
      date: 'May 28, 2026',
      author: 'KNUST Global Press Desk',
      readTime: '2 min read'
    },
    {
      id: 'news_03',
      category: 'Community',
      title: 'GHEMSA Student Outreaches Conducted Successfully at Kumasi Central Market',
      excerpt: 'Over 600 traders screened and advised on safe herbal remedies, toxic plant residues, and standard dosing precautions.',
      content: 'Undergraduate student clinicians from the Ghana Herbal Medical Students Association (GHEMSA) partnered with the Traditional Medicine Practice Council (TMPC) to run a mobile diagnostic and awareness desk inside Kumasi Central Market.\n\nLed by Level 400 clinical supervisor Dr. Evelyn Appiah, students performed blood sugar screenings, blood pressure checks, and holistic patient counseling. A primary goal of the field exercise was to identify dangerous herb-herb interactions and educate market herbal traders on sanitary handling practices.\n\n"Many consumers believe that because a plant is natural, it is automatically safe," said GHEMSA President George Boateng. "We identified cases where patients were taking three different plant formulations simultaneously, unaware that their coupled toxicity was putting severe strain on their hepatic systems. Helping traders identify such hazards directly saves lives in our community."',
      date: 'May 14, 2026',
      author: 'GHEMSA Executive Council',
      readTime: '3 min read'
    },
    {
      id: 'news_04',
      category: 'Seminar',
      title: '21st International Symposium on Sustainable Phytomedicines Scheduled in Kumasi',
      excerpt: 'KNUST to host global scientists, clinical herbalists, and pharmaceutical directors for three days of keynotes and research panels.',
      content: 'Mark your calendars! The Department of Herbal Medicine, KNUST, is pleased to host the 21st Joint Symposium on Phytomedicines (JSP-2026) in the Great Hall of Kumasi from October 12 to 14, 2026.\n\nUnder the focal theme "Sustainable Wild-Harvesting and Clinical Integration of Tropical Bio-Resources," the symposium welcomes over 300 international delegates. Keynote presenters include researchers from the University of Oxford, UK, and the National Institute of Natural Products, South Africa.\n\nSelected student posters will be displayed in the foyer, and the top three presentations from Level 400 researchers will receive prestigious cash research prizes sponsored by the Centre for Plant Medicine Research (CPMR). Registration is currently open inside the main administration office.',
      date: 'April 30, 2026',
      author: 'Faculty Seminar Committee',
      readTime: '4 min read'
    }
  ];

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Research': return 'bg-sky-50 text-sky-800 border-sky-100';
      case 'Achievement': return 'bg-amber-50 text-amber-805 border-amber-100';
      case 'Community': return 'bg-emerald-50 text-emerald-800 border-emerald-100';
      case 'Seminar': return 'bg-purple-50 text-purple-800 border-purple-100';
      default: return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  }

  return (
    <div className="space-y-12 animate-fade-in" id="news_events_root">
      
      {/* SEO Title Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (News View)</span>
        <strong className="text-slate-700">Title:</strong> Department News & Events | KNUST Herbal Medicine<br />
        <strong className="text-slate-700">Description:</strong> Stay updated on recent research grant accomplishments, GHEMSA health outreach updates, and upcoming international pharmacognosy symposiums in Kumasi.
      </div>

      {/* Header section */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block font-mono">Pressroom & Events Calendar</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Current Announcements & Press
        </h1>
        <p className="text-xs sm:text-base text-slate-500 max-w-3xl leading-relaxed">
          Stay connected with the vibrant scientific life of our department. Explore recent research achievements, local student-led medical outreaches, and national conference bulletins.
        </p>
      </div>

      {/* RENDER ACTIVE NEWS MODAL (Simulated inline view) */}
      {selectedArticle ? (
        <div className="bg-white rounded-3xl border-2 border-emerald-800/10 p-6 md:p-8 space-y-6 animate-fade-in" id="active_news_detail">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <button 
              onClick={() => setSelectedArticle(null)}
              className="text-xs font-black text-emerald-850 hover:text-emerald-950 flex items-center gap-1.5 cursor-pointer bg-slate-50 border border-slate-200 hover:border-slate-300 px-3 py-1.5 rounded-xl transition-all"
            >
              ← Back to News Feed
            </button>
            <div className="flex items-center gap-2.5 text-xs text-slate-400 font-bold">
              <Calendar className="h-4 w-4" /> <span>{selectedArticle.date}</span>
              <span>•</span>
              <User className="h-4 w-4" /> <span>{selectedArticle.author}</span>
            </div>
          </div>

          <div className="space-y-3">
            <span className={`inline-block border text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md ${getCategoryColor(selectedArticle.category)}`}>
              {selectedArticle.category} Article
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-850 tracking-tight leading-snug">{selectedArticle.title}</h2>
          </div>

          {/* Core Content Render split by paragraphs */}
          <div className="text-xs sm:text-sm text-slate-650 leading-relaxed font-semibold space-y-4 max-w-3xl border-l-2 border-slate-100 pl-4 py-1">
            {selectedArticle.content.split('\n\n').map((para, index) => (
              <p key={index}>{para}</p>
            ))}
          </div>

          <div className="bg-slate-50 rounded-2xl p-4.5 text-xs border border-slate-100 flex items-center justify-between gap-4">
            <span className="text-slate-400 font-bold">Need more press coordination detail? contact: <a href="mailto:media.herbal@knust.edu.gh" className="text-emerald-805 hover:underline font-extrabold">media.herbal@knust.edu.gh</a></span>
            <span className="font-mono text-slate-400 font-bold shrink-0">{selectedArticle.readTime}</span>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8" id="news_articles_grid">
          {newsList.map((article) => (
            <div 
              key={article.id} 
              className="bg-white rounded-3xl border border-slate-150 p-6 flex flex-col justify-between space-y-5 hover:shadow-lg transition-all hover:border-emerald-500/25 cursor-pointer group"
              onClick={() => setSelectedArticle(article)}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className={`border text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-md ${getCategoryColor(article.category)}`}>
                    {article.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400">
                    <Clock className="h-3.5 w-3.5 text-slate-350" />
                    <span>{article.readTime}</span>
                  </div>
                </div>

                <h3 className="font-extrabold text-slate-800 text-sm md:text-base leading-snug group-hover:text-emerald-850 transition-colors">
                  {article.title}
                </h3>

                <p className="text-xs text-slate-500 leading-relaxed font-semibold line-clamp-3">
                  {article.excerpt}
                </p>
              </div>

              <div className="border-t border-slate-100/60 pt-4 flex items-center justify-between text-xs font-semibold text-slate-400">
                <span className="font-bold">{article.date}</span>
                <span className="text-emerald-800 font-black flex items-center gap-1 group-hover:translate-x-1 transition-all">
                  Read Article <ArrowRight className="h-4 w-4" />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SEMINARS CALENDAR TIMETABLE SECTION */}
      {!selectedArticle && (
        <div className="space-y-6 pt-4">
          <div>
            <h3 className="font-extrabold text-slate-800 text-sm md:text-base">Upcoming Seminars and Academic Events</h3>
            <p className="text-xs text-slate-500">Continuous science development hours for staff, students, and practitioners.</p>
          </div>

          <div className="bg-white rounded-3xl border border-slate-150 divide-y divide-slate-100 overflow-hidden shadow-sm">
            {[
              {
                date: 'July 18, 2026',
                time: '10:00 AM UTC',
                title: 'Assessing Heavy Metal Residuals in Herbal Powders: Standard Digestion Methodologies',
                speaker: 'Dr. Evelyn Appiah (Clinical Therapeutics Specialist)',
                room: 'Seminar Room A, Block A'
              },
              {
                date: 'August 05, 2026',
                time: '02:00 PM UTC',
                title: 'Indigenous Synergies: Combining Multiple Saponin Markers for Inflammatory Relief',
                speaker: 'Prof. Shirley Amponzah (Ethnobotany & Pharmacognosy Chair)',
                room: 'Main Phytochemistry Lab Lab B'
              },
              {
                date: 'September 12, 2026',
                time: '09:00 AM UTC',
                title: 'TMPC Professional Licensure Preparation: A Practice Mock Walkthrough for level 400',
                speaker: 'Traditional Medicine Council Representatives',
                room: 'BSc Lecture Theatre Room 1'
              }
            ].map((ev) => (
              <div key={ev.title} className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                <div className="space-y-1 text-left flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] bg-emerald-50 border border-emerald-100 font-mono font-black text-emerald-805 px-2 py-0.5 rounded">
                      {ev.date}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 font-bold">{ev.time}</span>
                  </div>
                  <h4 className="font-extrabold text-slate-800 text-xs md:text-sm">{ev.title}</h4>
                  <p className="text-xs text-slate-450 font-bold">{ev.speaker}</p>
                </div>
                <span className="text-xs text-slate-400 font-mono font-bold shrink-0 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200/50">
                  📍 {ev.room}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
