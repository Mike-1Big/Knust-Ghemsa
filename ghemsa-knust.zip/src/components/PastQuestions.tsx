import { useState } from 'react';
import { PAST_QUESTIONS } from '../data/courses';
import { Award, CheckCircle2, AlertCircle, ArrowLeft, ArrowRight, RotateCcw, Brain, Check, HelpCircle } from 'lucide-react';

interface PastQuestionsProps {
  currentLevel: 100 | 200 | 300 | 400;
}

export default function PastQuestions({ currentLevel }: PastQuestionsProps) {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOpt, setSelectedOpt] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [sessionScore, setSessionScore] = useState<number>(0);
  const [questionsAnswered, setQuestionsAnswered] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  // Filter questions for this selected level
  const questions = PAST_QUESTIONS.filter((q) => q.level === currentLevel);

  const handleOptionSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedOpt(option);
  };

  const handleCheckAnswer = () => {
    if (!selectedOpt || isAnswered) return;
    
    setIsAnswered(true);
    setQuestionsAnswered((prev) => prev + 1);

    const currentQ = questions[currentIdx];
    if (selectedOpt === currentQ.correctAnswer) {
      setSessionScore((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOpt(null);
    setIsAnswered(false);

    if (currentIdx < questions.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const restartQuiz = () => {
    setCurrentIdx(0);
    setSelectedOpt(null);
    setIsAnswered(false);
    setSessionScore(0);
    setQuestionsAnswered(0);
    setQuizFinished(false);
  };

  if (questions.length === 0) {
    return (
      <div className="rounded-xl border border-slate-100 bg-white p-12 text-center text-slate-400 space-y-3" id="no_pq_found">
        <Brain className="h-12 w-12 mx-auto stroke-1 text-slate-300" />
        <h3 className="text-sm font-bold text-slate-700">No Past Questions Uploaded</h3>
        <p className="text-xs max-w-sm mx-auto leading-relaxed">
          The exam board is currently compiling exam sets for Level {currentLevel}. Choose another academic level of study from the main Dashboard.
        </p>
      </div>
    );
  }

  const currentQ = questions[currentIdx];

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in" id="past_questions_view_container">
      {/* Quiz Header Info */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-[10px] uppercase font-bold text-emerald-800 bg-emerald-50 px-2 py-1 rounded">
            Level {currentLevel} Boards
          </span>
          <h1 className="text-xl font-bold text-slate-800 mt-1.5 flex items-center gap-1.5">
            <Brain className="h-5 w-5 text-emerald-700 animate-pulse" /> Past Questions Trainer
          </h1>
        </div>
        <div className="text-right">
          <span className="text-xs font-bold text-slate-400">Score Tracker: </span>
          <span className="text-xs font-black text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
            {sessionScore}/{questionsAnswered}
          </span>
        </div>
      </div>

      {quizFinished ? (
        /* Results Card */
        <div 
          className="rounded-2xl border border-emerald-100 bg-white p-8 text-center space-y-6 shadow-sm shadow-emerald-500/5"
          id="quiz_results_card"
        >
          <div className="inline-flex rounded-full bg-emerald-50 p-6 text-emerald-600">
            <Award className="h-16 w-16" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-800">Review Board Completed!</h2>
            <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
              Wonderful job completing your GHEMSA Level {currentLevel} review track. Daily retrieval practice consolidates your microscopic pharmacognosy keys and formulation indices.
            </p>
          </div>

          <div className="bg-slate-50 rounded-xl p-5 border border-slate-100 max-w-xs mx-auto flex justify-around">
            <div className="text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Final Score</span>
              <p className="text-3xl font-black text-slate-800 mt-1">{sessionScore} / {questions.length}</p>
            </div>
            <div className="border-r border-slate-200"></div>
            <div className="text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Accuracy</span>
              <p className="text-3xl font-black text-emerald-700 mt-1">
                {Math.round((sessionScore / questions.length) * 100)}%
              </p>
            </div>
          </div>

          <button
            onClick={restartQuiz}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-800 hover:bg-emerald-950 px-5 py-2.5 text-sm font-bold text-white transition-colors shadow-sm"
          >
            <RotateCcw className="h-4 w-4" /> Restart Training
          </button>
        </div>
      ) : (
        /* Active Question Display */
        <div className="space-y-6" id="active_question_slide">
          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-700 h-full transition-all duration-300"
              style={{ width: `${((currentIdx) / questions.length) * 100}%` }}
            ></div>
          </div>

          {/* Question Card */}
          <div className="rounded-2xl border border-slate-100 bg-white p-6 md:p-8 shadow-sm space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-50 pb-4 text-xs">
              <span className="font-bold text-slate-400">{currentQ.courseCode} — {currentQ.courseName}</span>
              <span className="font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">Exams: {currentQ.year}</span>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-xs font-bold text-emerald-800">
                  Q{currentIdx + 1}
                </span>
                <h2 className="text-base font-black text-slate-800 leading-relaxed pt-0.5">
                  {currentQ.questionText}
                </h2>
              </div>

              {/* Multiple Choice Options List */}
              <div className="grid grid-cols-1 gap-3 mt-6" id="mcq_options_list">
                {currentQ.options?.map((option, idx) => {
                  const optionLetter = String.fromCharCode(65 + idx);
                  const isSelected = selectedOpt === option;
                  const isCorrect = option === currentQ.correctAnswer;
                  
                  // Color styling based on answer state
                  let itemStyle = 'border-slate-100 hover:bg-slate-50 hover:border-slate-300';
                  let letterStyle = 'bg-slate-100 text-slate-500';

                  if (isSelected) {
                    itemStyle = 'bg-emerald-50/40 border-emerald-500';
                    letterStyle = 'bg-emerald-500 text-white';
                  }

                  if (isAnswered) {
                    if (isCorrect) {
                      itemStyle = 'bg-emerald-50 border-emerald-400 text-emerald-950 font-medium';
                      letterStyle = 'bg-emerald-600 text-white';
                    } else if (isSelected) {
                      itemStyle = 'bg-rose-50 border-rose-300 text-rose-950';
                      letterStyle = 'bg-rose-500 text-white';
                    } else {
                      itemStyle = 'border-slate-100 opacity-60 pointer-events-none';
                    }
                  }

                  return (
                    <button
                      key={option}
                      disabled={isAnswered}
                      onClick={() => handleOptionSelect(option)}
                      className={`w-full text-left rounded-xl border p-4 transition-all flex items-center justify-between gap-4 ${itemStyle}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`flex h-7 w-7 items-center justify-center rounded-lg text-xs font-black ${letterStyle}`}>
                          {optionLetter}
                        </span>
                        <span className="text-sm text-slate-800">{option}</span>
                      </div>
                      {isAnswered && isCorrect && <Check className="h-4.5 w-4.5 text-emerald-600 stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Answer Checker & Explanations panel */}
            <div className="pt-4 flex flex-col gap-4">
              {!isAnswered ? (
                <button
                  onClick={handleCheckAnswer}
                  disabled={!selectedOpt}
                  className="w-full text-center rounded-xl bg-emerald-800 font-bold text-white py-3 hover:bg-emerald-900 disabled:opacity-50 disabled:pointer-events-none transition-all shadow-sm"
                  id="btn_submit_ans"
                >
                  Verify Diagnosis
                </button>
              ) : (
                <div className="space-y-4 animate-slide-in" id="explanation_box">
                  <div className={`rounded-xl p-4 flex items-start gap-3 ${
                    selectedOpt === currentQ.correctAnswer 
                      ? 'bg-emerald-50/50 border border-emerald-100 text-emerald-950' 
                      : 'bg-rose-50/30 border border-rose-100 text-rose-950'
                  }`}>
                    {selectedOpt === currentQ.correctAnswer ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
                    )}
                    <div className="space-y-1">
                      <p className="text-xs font-bold">
                        {selectedOpt === currentQ.correctAnswer ? 'Correct Diagnosis!' : 'Incorrect Answer'}
                      </p>
                      <p className="text-xs opacity-90 leading-relaxed">
                        {currentQ.explanation}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={handleNextQuestion}
                    className="w-full text-center rounded-xl bg-slate-800 py-3 font-bold text-white hover:bg-slate-900 flex items-center justify-center gap-2 transition-all shadow-sm"
                    id="btn_next_question"
                  >
                    {currentIdx < questions.length - 1 ? 'Next Question' : 'Complete Review Board'} <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Prompt tip */}
          <div className="text-center text-xs text-slate-400 font-medium">
            Question {currentIdx + 1} of {questions.length} • Practice compiles neural retrieval.
          </div>
        </div>
      )}
    </div>
  );
}
