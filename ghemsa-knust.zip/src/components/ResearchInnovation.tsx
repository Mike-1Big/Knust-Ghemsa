import React from 'react';
import { Award, Beaker, Sprout, ShieldAlert, Heart, Calendar, Landmark, BookOpen, Quote, Shield, Network, Brain } from 'lucide-react';

export default function ResearchInnovation() {
  React.useEffect(() => {
    document.title = "Research & Innovation | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const researchArenas = [
    {
      title: 'Phytochemistry & Compound Profiling',
      desc: 'Isolating primary and secondary botanical metabolites, identifying volatile oils, and compiling high precision HPLC/GC-MS fingerprint arrays for Ghanaian plant species.',
      icon: Beaker,
      tag: 'Analytical Chemistry'
    },
    {
      title: 'Ethnopharmacology & Clinical Models',
      desc: 'Testing therapeutic capacities using standard pre-clinical assays, and mapping physiological pathways for chronic conditions (e.g. malaria, type II diabetes, and inflammatory indices).',
      icon: Heart,
      tag: 'Physiology'
    },
    {
      title: 'Phytotox-Risk & Safety Calibration',
      desc: 'Defining lethal dose limits (LD50), cataloging liver veno-occlusive risks, and establishing safe consumer thresholds for traditional herbal compounds.',
      icon: ShieldAlert,
      tag: 'Toxicology'
    },
    {
      title: 'Conservation & Tissue Propagation',
      desc: 'Conducting micropropagation on endangered antiplasmodial shrubs, monitoring soil chemistry effects, and training local farm centers on sustainably harvesting bark and roots.',
      icon: Sprout,
      tag: 'Agronomy'
    }
  ];

  const labs = [
    {
      name: 'Phytochemistry Isolation Laboratory',
      lead: 'Prof. Shirley Amponzah',
      equipment: ['High-Performance Liquid Chromatography (HPLC)', 'Gas Chromatography-Mass Spectrometry (GC-MS)', 'Rotary Evaporators with recirculating chillers', 'Vacuum Spray Dryers'],
      desc: 'Our primary analytical suite used to isolate alkaloids, flavanoids, and saponins from complex herbal formulas.'
    },
    {
      name: 'Experimental Toxicology Unit & Animal Complex',
      lead: 'Dr. Joseph Osei-Duro',
      equipment: ['Automated hematology analyzers', 'Tissue homogenizers & microcentrifuges', 'Digital plethysmometers', 'ELISA microplate plate readers'],
      desc: 'Dedicated facility evaluating acute and sub-chronic tox panels in in-vivo rodent models complying with OECD guidelines.'
    },
    {
      name: 'KNUST Botanical Nursery & Herbarium Annex',
      lead: 'Dr. Caleb Boamah',
      equipment: ['Tissue culture growth chambers', 'Moisture determination balances', 'Stereomicroscopes with HD digital imaging', 'Specimen sterilization autoclaves'],
      desc: 'Maintains cataloged vouchers of over 1,500 local plants alongside experimental conservation propagation beds.'
    }
  ];

  const ongoingProjects = [
    {
      title: 'Standardisation and Stability Tuning of Cryptolepis Sanguinolenta Liquid Decoctions',
      sponsor: 'Ghana Ministry of Education / GTEC Research Fund',
      duration: '2024 - 2027',
      budget: 'GHS 450,000',
      summary: 'Securing the thermal stability of active cryptolepine molecules in standard commercial liquid formulas to prevent bacterial contamination and visual clouding over a 12-month storage span.'
    },
    {
      title: 'Evaluating Herb-synthetic Drug Interactions in Patients Diagnosed with Type II Diabetes',
      sponsor: 'World Health Organisation (WHO) Sub-Saharan Taskforce',
      duration: '2025 - 2026',
      budget: 'USD 85,000',
      summary: 'Monitoring clinical metabolic shifts and glycemic parameters in double-phase patients co-administering synthetic Metformin alongside traditional Morinda Lucida leaf tea.'
    }
  ];

  return (
    <div className="space-y-12 animate-fade-in" id="research_innovation_root">
      
      {/* SEO metadata preview block */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Research View)</span>
        <strong className="text-slate-700">Title:</strong> Botanical Research & Lab Assets | KNUST Ghana<br />
        <strong className="text-slate-705">Description:</strong> Browse our four primary research spheres, ongoing WHO-funded drug interaction trials, and our premier high-performance analytic liquid chromatography (HPLC) laboratories.
      </div>

      {/* Header section */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-805 tracking-widest block">Scientific Inquiries & Discoveries</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Translating Herbal Science Into Tested Diagnostics
        </h1>
        <p className="text-xs sm:text-base text-slate-500 max-w-3xl leading-relaxed">
          The Department of Herbal Medicine is a premium hub for botanical inquiry in sub-Saharan Africa. Our laboratories lead scientific rigorous research into raw herbal safety, standardizing therapeutic doses, and building novel patents.
        </p>
      </div>

      {/* Primary Research Arenas Grid */}
      <div className="space-y-6">
        <h3 className="font-extrabold text-slate-800 text-sm md:text-base">Primary Core Research Competencies</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {researchArenas.map((arena) => {
            const ArenaIcon = arena.icon;
            return (
              <div key={arena.title} className="bg-white rounded-3xl border border-slate-150 p-6 flex items-start gap-4 hover:border-emerald-300 transition-all shadow-sm">
                <div className="p-3 bg-emerald-50 text-emerald-900 rounded-2xl shrink-0">
                  <ArenaIcon className="h-5.5 w-5.5" />
                </div>
                <div className="space-y-1.5 text-left">
                  <span className="text-[9px] uppercase font-black tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">{arena.tag}</span>
                  <h4 className="font-extrabold text-slate-800 text-sm mt-1 leading-snug">{arena.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">{arena.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LABS AND FACILITIES IN DETAIL */}
      <div className="space-y-6 pt-4">
        <div>
          <h3 className="font-extrabold text-slate-800 text-sm md:text-base">State-of-the-Art Research Laboratories</h3>
          <p className="text-xs text-slate-500">Equipping our undergraduate and postgraduate research students with standardized analytical testing apparatuses.</p>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {labs.map((laboratory) => (
            <div key={laboratory.name} className="bg-gradient-to-br from-[#0c1c12] to-[#040a06] text-white rounded-3xl p-6 md:p-8 border border-emerald-950 flex flex-col lg:flex-row items-stretch gap-6">
              <div className="lg:col-span-5 flex flex-col justify-between space-y-4 lg:w-1/2">
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-black text-emerald-450 tracking-wider">Research Suite</span>
                  <h4 className="font-extrabold text-white text-base md:text-lg leading-tight">{laboratory.name}</h4>
                  <p className="text-xs text-emerald-200/80 leading-relaxed font-semibold">{laboratory.desc}</p>
                </div>
                <div className="text-xs text-slate-400">
                  <strong className="text-emerald-305 block font-bold">Principal Investigator:</strong> {laboratory.lead}
                </div>
              </div>

              <div className="bg-emerald-950/60 border border-emerald-900/60 rounded-2xl p-5 space-y-3 flex-1">
                <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-extrabold block">Essential Laboratory Equipment</span>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  {laboratory.equipment.map((equip) => (
                    <li key={equip} className="flex gap-2 text-emerald-100 font-bold items-start">
                      <span className="text-emerald-400 leading-none mt-0.5">•</span>
                      <span>{equip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ACTIVE SPONSORED PROJECTS */}
      <div className="space-y-6 pt-4">
        <div>
          <h3 className="font-extrabold text-slate-800 text-sm md:text-base">Sponsored Clinical Trials & Projects Spotlight</h3>
          <p className="text-xs text-slate-500">Showcasing current national and international sponsored scientific investments inside our department.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {ongoingProjects.map((project) => (
            <div key={project.title} className="bg-white rounded-3xl border border-slate-150 p-6 flex flex-col justify-between space-y-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  <span className="text-[9px] uppercase font-black tracking-widest text-[#5c4a16] bg-amber-100 border border-amber-200 px-2 py-0.5 rounded-md">Active Study</span>
                  <span className="text-[9px] font-mono text-slate-450 font-bold mt-0.5">{project.duration}</span>
                </div>
                <h4 className="font-extrabold text-slate-800 text-xs md:text-sm leading-snug">{project.title}</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-semibold">{project.summary}</p>
              </div>

              <div className="border-t border-slate-100 pt-3 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold uppercase">Funding Authority</span>
                  <span className="font-extrabold text-slate-700 block truncate max-w-[180px]">{project.sponsor}</span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] text-slate-400 block font-bold uppercase">Allocated Grant</span>
                  <span className="font-extrabold text-emerald-800 block">{project.budget}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* COLLABORATORS AND ASSOCIATED BRANDS */}
      <div className="bg-slate-50 border border-slate-150 rounded-3xl p-6 text-center space-y-4">
        <span className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest block">Affiliated Regulatory & Collaborative Network</span>
        <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12 opacity-65 grayscale hover:grayscale-0 transition-all">
          <span className="font-black text-slate-600 tracking-tight text-xs md:text-sm">Ghana Food & Drugs Authority (FDA)</span>
          <span className="font-black text-slate-600 tracking-tight text-xs md:text-sm">WHO Africa Focal Office</span>
          <span className="font-black text-slate-600 tracking-tight text-xs md:text-sm">Center for Plant Medicine Research (Mampong)</span>
          <span className="font-black text-slate-600 tracking-tight text-xs md:text-sm">Ghana Standards Authority (GSA)</span>
        </div>
      </div>

    </div>
  );
}
