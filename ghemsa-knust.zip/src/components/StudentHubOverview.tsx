import React from 'react';
import { Users, GraduationCap, FileText, Calendar, Compass, ShieldAlert, Cpu, Award, ArrowRight, Sparkles, BookOpen, Brain, PenTool, Sprout } from 'lucide-react';

interface StudentHubOverviewProps {
  onNavigate: (tab: string) => void;
}

export default function StudentHubOverview({ onNavigate }: StudentHubOverviewProps) {
  React.useEffect(() => {
    document.title = "Student Hub | Dept of Herbal Medicine | KNUST Ghana";
  }, []);

  const internalTools = [
    {
      title: 'MCQ Past Questions Lab',
      desc: 'Simulate official curriculum tests and active recall sessions with detailed toxicological and pharmacological feedback.',
      tab: 'quiz',
      icon: Brain,
      badge: 'Active Training'
    },
    {
      title: 'Course Study Guides',
      desc: 'Browse official syllabus slides, clinical diagnostic handbooks, and laboratory extraction manuals.',
      tab: 'materials',
      icon: BookOpen,
      badge: 'Materials'
    },
    {
      title: 'Active Formulation Suite',
      desc: 'Simulate thermodynamic surfactant calculations and herbal cream development assisted by AI.',
      tab: 'herbs',
      icon: Sprout,
      badge: 'Interactive Lab'
    },
    {
      title: 'Google Drive Sync Notes',
      desc: 'Link your student Google account to synchronize persistent flashcards and study logs dynamically.',
      tab: 'notes',
      icon: FileText,
      badge: 'Cloud Sync'
    },
  ];

  return (
    <div className="space-y-12 animate-fade-in" id="student_hub_overview_root">
      
      {/* SEO metadata Preview Box */}
      <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 text-[11px] text-slate-500 font-medium">
        <span className="font-extrabold uppercase tracking-wider text-slate-400 block mb-1">SEO Title & Meta (Student Hub View)</span>
        <strong className="text-slate-700">Title:</strong> Student Resources & Hub | KNUST Herbal Medicine Portal<br />
        <strong className="text-slate-700">Description:</strong> Access academic calendars, scholarship programs, GHEMSA notifications, and clinical guidelines. Directly launch MCQ practice modules and study sync protocols.
      </div>

      {/* Header introduction */}
      <div className="space-y-3">
        <span className="text-[10px] uppercase font-black text-emerald-800 tracking-widest block font-mono">My Student Resources Workspace</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Current Scholars Hub
        </h1>
        <p className="text-xs sm:text-base text-slate-505 max-w-3xl leading-relaxed">
          Welcome to your centralized student workspace. From here, you can acquire academic advising, download regulatory reference guidelines, query scholarship applications, and launch your interactive revision systems.
        </p>
      </div>

      {/* INTERACTIVE WORKSPACE ACCESS TILES */}
      <div className="space-y-6">
        <div>
          <span className="text-[10px] uppercase font-black text-amber-700 tracking-wider">Launch Diagnostic Study Tools</span>
          <h3 className="font-extrabold text-slate-850 text-base">Active Revision Modules</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {internalTools.map((tool) => {
            const ToolIcon = tool.icon;
            return (
              <div 
                key={tool.title} 
                onClick={() => onNavigate(tool.tab)}
                className="group relative rounded-3xl border border-slate-150 bg-white p-6 shadow-sm hover:shadow-xl hover:border-emerald-500/30 hover:ring-4 hover:ring-emerald-500/5 transition-all duration-300 flex flex-col justify-between cursor-pointer"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2 bg-emerald-50 text-emerald-850 rounded-xl group-hover:bg-emerald-800 group-hover:text-white transition-all">
                      <ToolIcon className="h-5.5 w-5.5" />
                    </div>
                    <span className="text-[9px] font-mono font-black text-emerald-800 bg-emerald-50/50 border border-emerald-100/50 px-2 py-0.5 rounded-md">
                      {tool.badge}
                    </span>
                  </div>
                  <h4 className="font-extrabold text-slate-800 text-sm group-hover:text-emerald-850 transition-colors">{tool.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">{tool.desc}</p>
                </div>

                <div className="border-t border-slate-100/60 pt-4 mt-4 flex items-center justify-between text-xs text-emerald-800 font-extrabold">
                  <span>Launch Module Studio</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* GENERAL RESOURCES & SUPPORT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Advising of handbook info */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-150 p-6 space-y-4 shadow-sm">
            <h3 className="font-extrabold text-slate-800 text-sm md:text-base flex items-center gap-2">
              <Users className="h-5 w-5 text-emerald-800" /> Academic Advising & Counseling
            </h3>
            <p className="text-xs text-slate-550 leading-relaxed">
              Every student clinician is assigned a dedicated Academic Advisor selected from our faculty staff directory. Students meet advisors at least twice every term to finalize registration profiles, review Cumulative Weighted Average (CWA) performance indices, and select elective topics.
            </p>
            <div className="p-4 bg-slate-50 rounded-2xl text-xs space-y-1.5 font-semibold text-slate-650 border border-slate-100">
              <p className="text-slate-800 font-bold uppercase text-[10px] tracking-wider">Need Urgent Academic Assistance?</p>
              <p>Email: <a href="mailto:advising.herbal@knust.edu.gh" className="text-emerald-800 hover:underline">advising.herbal@knust.edu.gh</a></p>
              <p>Phone Advisor Desk: +233 (0) 32 206 0294</p>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-150 p-6 space-y-4 shadow-sm">
            <h3 className="font-extrabold text-slate-800 text-sm md:text-base flex items-center gap-2">
              <Award className="h-5 w-5 text-emerald-800" /> Scholarships & Financial Grants
            </h3>
            <p className="text-xs text-slate-550 leading-relaxed">
              KNUST supports high-potential and underprivileged student herbalists via direct partnership and targeted bursary foundations:
            </p>
            <ul className="space-y-3 text-xs text-slate-650 font-semibold pl-4 list-disc">
              <li><strong>The Ghana GETFund Tertiary Bursaries:</strong> Annual financial packages covering tuition fees and text reference costs online.</li>
              <li><strong>KNUST Vice-Chancellor Student Aid:</strong> Urgent direct grants for undergraduate scholars maintaining a CWA above 60.0%.</li>
              <li><strong>Mastercard Foundation Scholars:</strong> Comprehensive coverage for qualified international applicants across sub-Saharan territories.</li>
            </ul>
          </div>
        </div>

        {/* Clinical Conduct, GHEMSA details */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#0c1c12] text-emerald-100 rounded-3xl p-6 border border-emerald-900 space-y-5">
            <h3 className="text-white font-extrabold text-sm md:text-base flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-amber-400" /> Clinical Decorum Code of Conduct
            </h3>
            <p className="text-xs text-emerald-250/85 leading-relaxed font-semibold">
              Scholars executing rotations inside government medical wards or clinical consulting rooms must adhere strictly to GHS regulatory guidelines:
            </p>
            <ul className="space-y-2.5 text-[11px] font-bold text-[#bde0cc]">
              <li className="flex gap-2">
                <span className="text-amber-400 font-black">•</span>
                <span>White laboratory coats are compulsory at all times inside laboratories and wards.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-amber-400 font-black">•</span>
                <span>Maintain absolute patient confidentiality regarding diagnostic charts and pathology files.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-amber-400 font-black">•</span>
                <span>A clear identifier badge stating "BSc Herbal Student Intern" must be clipped to coats publicly.</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl border border-slate-150 p-6 space-y-3 shadow-sm">
            <span className="text-[10px] uppercase font-black text-emerald-800 tracking-wider">Student Life</span>
            <h4 className="font-extrabold text-slate-800 text-sm">GHEMSA Students Association</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              The <strong>Ghana Herbal Medical Students Association (GHEMSA)</strong> coordinates community-wide health checks, organizes botany exploration field trips into forest reserves, publishes traditional journals, and supports peer-to-peer tutorial circles before final MCQ test blocks.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
