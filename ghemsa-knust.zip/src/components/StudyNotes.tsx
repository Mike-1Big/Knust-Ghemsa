import { useState, useEffect } from 'react';
import { StudyNote } from '../types';
import { PencilLine, Trash2, CloudLightning, Loader2, CloudCheck, Plus, CheckCircle, RefreshCcw, Save, FileEdit, AlertTriangle } from 'lucide-react';
import { findOrCreateAppFolder, uploadNoteToDrive, deleteNoteFromDrive } from '../auth';

interface StudyNotesProps {
  accessToken: string | null;
  onLoginRequest: () => void;
  currentLevel: 100 | 200 | 300 | 400;
}

export default function StudyNotes({ accessToken, onLoginRequest, currentLevel }: StudyNotesProps) {
  const [notes, setNotes] = useState<StudyNote[]>([]);
  const [editingNote, setEditingNote] = useState<StudyNote | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [courseCode, setCourseCode] = useState('');

  // Sync state trackers
  const [isSyncing, setIsSyncing] = useState<Record<string, boolean>>({});

  // Load notes initially from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('ghemsa_student_notes');
    if (saved) {
      try {
        setNotes(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const saveToLocal = (updatedNotes: StudyNote[]) => {
    setNotes(updatedNotes);
    localStorage.setItem('ghemsa_student_notes', JSON.stringify(updatedNotes));
  };

  const handleCreateNote = () => {
    const newNote: StudyNote = {
      id: `note_${Date.now()}`,
      title: 'Untilted Observation Notes',
      content: 'Record taxonomic observations of morphological parts or clinical dosing indicators here...',
      courseCode: 'HRM Core',
      timestamp: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSynced: false,
    };

    const updated = [newNote, ...notes];
    saveToLocal(updated);
    setEditingNote(newNote);
    setTitle(newNote.title);
    setContent(newNote.content);
    setCourseCode(newNote.courseCode);
  };

  const handleSelectNote = (note: StudyNote) => {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setCourseCode(note.courseCode);
  };

  const handleSaveLocalEdit = () => {
    if (!editingNote) return;

    const updated = notes.map((n) => {
      if (n.id === editingNote.id) {
        return {
          ...n,
          title,
          content,
          courseCode,
          timestamp: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          // If we modified content locally, mark as dirty (not synced)
          isSynced: n.isSynced ? (n.title === title && n.content === content && n.courseCode === courseCode) : false,
        };
      }
      return n;
    });

    saveToLocal(updated);
    
    // Find and update current active editing reference
    const freshlySaved = updated.find((n) => n.id === editingNote.id);
    if (freshlySaved) {
      setEditingNote(freshlySaved);
    }
  };

  const handleSyncNoteToDrive = async (noteId: string) => {
    if (!accessToken) {
      onLoginRequest();
      return;
    }

    const noteToSync = notes.find((n) => n.id === noteId);
    if (!noteToSync) return;

    setIsSyncing((prev) => ({ ...prev, [noteId]: true }));

    try {
      // Find or create GHEMSA folder ID
      const folderId = await findOrCreateAppFolder(accessToken);

      // Construct markdown document representing notes file
      const formattedMarkdown = `# ${noteToSync.title}\n\n` +
        `**Course Code:** ${noteToSync.courseCode}\n` +
        `**Last Updated:** ${noteToSync.timestamp}\n` +
        `**GHEMSA Portal Digital Study Note**\n\n` +
        `## Core Notes Content\n${noteToSync.content}\n\n` +
        `---\n*Notebook entries synchronized via Kwame Nkrumah University of Science & Technology.*`;

      // Upload file (supports patch if files has prior driveFileId)
      const driveId = await uploadNoteToDrive(
        accessToken,
        folderId,
        noteToSync.title,
        formattedMarkdown,
        noteToSync.driveFileId
      );

      // Save driveFileId in local storage reference
      const updated = notes.map((n) => {
        if (n.id === noteId) {
          return {
            ...n,
            driveFileId: driveId,
            isSynced: true,
          };
        }
        return n;
      });

      saveToLocal(updated);
      if (editingNote?.id === noteId) {
        setEditingNote((prev) => prev ? { ...prev, driveFileId: driveId, isSynced: true } : null);
      }
    } catch (err) {
      console.error('Error syncing note to drive:', err);
      alert('Collaboration sync failed. Ensure Google Drive auth is active.');
    } finally {
      setIsSyncing((prev) => ({ ...prev, [noteId]: false }));
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    const targetNote = notes.find((n) => n.id === noteId);
    if (!targetNote) return;

    // MANDATORY confirmation constraint from system skills
    const message = `Are you sure you want to delete "${targetNote.title}"? This will wipe the card from local storage.\n\n` +
      `Optionally, if backed up in Google Drive, the file there will remain intact inside your GHEMSA directory.`;
    
    if (!window.confirm(message)) {
      return;
    }

    // Perform deletions
    const updated = notes.filter((n) => n.id !== noteId);
    saveToLocal(updated);

    if (editingNote?.id === noteId) {
      setEditingNote(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="study_notebook_view">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <PencilLine className="h-6 w-6 text-emerald-700" /> Digital Study Notebook
          </h1>
          <p className="text-sm text-slate-500">
            Keep logs of field botanical surveys, lab formulations, and sync entries directly with Google Drive.
          </p>
        </div>

        <button
          onClick={handleCreateNote}
          className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-950 px-4 py-2.5 text-xs font-bold text-white transition-all shadow-sm"
          id="btn_new_note"
        >
          <Plus className="h-4.5 w-4.5" /> Start New Entry
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column note directory listing */}
        <div className="space-y-3" id="notebook_directory_grid">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">My Notes Directory</span>
          
          {notes.length === 0 ? (
            <div className="rounded-xl border border-slate-100 bg-white p-6 text-center text-slate-400 space-y-2">
              <PencilLine className="h-10 w-10 mx-auto stroke-1" />
              <p className="text-xs">No entries drafted yet. Hit the "Start New Entry" button to write observations.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {notes.map((note) => {
                const isCurrent = editingNote?.id === note.id;
                const syncing = isSyncing[note.id];

                return (
                  <div
                    key={note.id}
                    onClick={() => handleSelectNote(note)}
                    className={`rounded-xl border bg-white p-4 cursor-pointer hover:border-emerald-200 hover:shadow-sm transition-all flex flex-col justify-between gap-3 ${
                      isCurrent ? 'border-emerald-700 ring-1 ring-emerald-700/30 shadow-sm' : 'border-slate-100'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-block rounded bg-slate-100 px-2 py-0.5 text-[9px] font-bold text-slate-600">
                          {note.courseCode}
                        </span>
                        <span className="text-[10px] text-slate-400">{note.timestamp.split(' ')[0]}</span>
                      </div>
                      <h3 className="text-xs font-bold text-slate-800 leading-snug line-clamp-1">{note.title}</h3>
                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">{note.content}</p>
                    </div>

                    <div className="flex items-center justify-between gap-4 pt-2 border-t border-slate-50">
                      {/* Sync triggers */}
                      {note.isSynced ? (
                        <span className="text-[9px] font-bold text-emerald-800 bg-emerald-50 rounded px-1.5 py-0.5 flex items-center gap-1">
                          <CloudCheck className="h-3.5 w-3.5" /> Drive Synced
                        </span>
                      ) : (
                        <span className="text-[9px] font-bold text-amber-800 bg-amber-50 rounded px-1.5 py-0.5 flex items-center gap-1">
                          <CloudLightning className="h-3.5 w-3.5" /> Local Scratch
                        </span>
                      )}

                      <div className="flex items-center gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSyncNoteToDrive(note.id);
                          }}
                          disabled={syncing}
                          className="rounded bg-slate-50 hover:bg-emerald-50 p-1.5 text-slate-400 hover:text-emerald-700 transition-colors"
                          title="Backup / Sync to Drive"
                        >
                          {syncing ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin text-emerald-700" />
                          ) : (
                            <RefreshCcw className="h-3.5 w-3.5" />
                          )}
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteNote(note.id);
                          }}
                          className="rounded bg-slate-50 hover:bg-rose-50 p-1.5 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Delete Note"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right column Note Editor */}
        <div className="md:col-span-2 space-y-4" id="note_editor_workspace">
          {editingNote ? (
            <div className="rounded-2xl border border-slate-100 bg-white p-6 md:p-8 shadow-sm space-y-6 animate-slide-in">
              <div className="flex items-center justify-between border-b border-slate-50 pb-4">
                <span className="text-xs font-black text-slate-400 flex items-center gap-1 uppercase tracking-wider">
                  <FileEdit className="h-4.5 w-4.5 text-emerald-700" /> Observation Desk
                </span>
                <span className="text-[10px] text-slate-400 font-semibold">{editingNote.timestamp}</span>
              </div>

              {/* Form editing inputs */}
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-bold text-slate-500 block">Observation / Notebook Title</label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      onBlur={handleSaveLocalEdit}
                      className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-bold text-slate-800 placeholder-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 block">Course Code / Label</label>
                    <input
                      type="text"
                      value={courseCode}
                      onChange={(e) => setCourseCode(e.target.value)}
                      onBlur={handleSaveLocalEdit}
                      className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 block">Scientific Content / Lab Readings</label>
                  <textarea
                    rows={12}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    onBlur={handleSaveLocalEdit}
                    placeholder="Enter lab values, microscopic findings, plant extraction specs, etc..."
                    className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-700 placeholder-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none font-mono tracking-normal leading-relaxed overflow-y-auto"
                  ></textarea>
                </div>
              </div>

              {/* Workspace Action Buttons */}
              <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3 items-center justify-between">
                <div className="text-slate-400 text-[10px] font-bold flex items-center gap-1">
                  <Save className="h-4 w-4" /> Edits auto-save to local draft when exiting boxes.
                </div>

                <div className="flex items-center gap-2">
                  {editingNote.isSynced ? (
                    <button
                      onClick={() => handleSyncNoteToDrive(editingNote.id)}
                      disabled={isSyncing[editingNote.id]}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 px-4 py-2 text-xs font-bold text-emerald-800 transition-all cursor-pointer"
                    >
                      {isSyncing[editingNote.id] ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin" /> Syncing...
                        </>
                      ) : (
                        <>
                          <CloudCheck className="h-4 w-4" /> Sync Changes to Drive
                        </>
                      )}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleSyncNoteToDrive(editingNote.id)}
                      disabled={isSyncing[editingNote.id]}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 border border-emerald-950 text-white px-4 py-2 text-xs font-bold transition-all shadow-sm cursor-pointer"
                    >
                      {isSyncing[editingNote.id] ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin" /> Syncing...
                        </>
                      ) : (
                        <>
                          <Plus className="h-4 w-4 animate-pulse" /> Backup to Google Drive
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50/50 p-12 text-center text-slate-400 flex flex-col justify-center items-center gap-4 h-[380px]">
              <PencilLine className="h-12 w-12 text-slate-300 stroke-1" />
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-600">No Observation Selected</h3>
                <p className="text-xs max-w-xs mx-auto leading-relaxed">
                  Choose an existing entry from your notebook column or hit the "Start New Entry" button to draft dynamic study findings.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
