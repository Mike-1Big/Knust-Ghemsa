import { HerbalResource, LearningMaterial, PastQuestion } from '../types';

export interface Course {
  code: string;
  name: string;
  description: string;
  semester: 1 | 2;
  credits: number;
}

export const COURSES_BY_LEVEL: Record<number, Course[]> = {
  100: [
    // FIRST SEMESTER
    { code: 'BHM 151', name: 'INTRODUCTION TO HERBAL MEDICINE', description: 'Introductory concepts of herbal medicine, history, philosophy, and professional practice.', semester: 1, credits: 2 },
    { code: 'BHM 161', name: 'BASIC MICROBIOLOGY I', description: 'Fundamental principles of general microbiology, classification, morphology, and growth of microorganisms.', semester: 1, credits: 3 },
    { code: 'BHM 171', name: 'PLANT MORPHOLOGY', description: 'Study of the external and internal structure, form, and modification of flowering plant organs.', semester: 1, credits: 3 },
    { code: 'BHM 173', name: 'PLANT MORPHOLOGY LABORATORY', description: 'Hands-on microscopic and macroscopic analysis of plant vegetative and reproductive organs.', semester: 1, credits: 1 },
    { code: 'ENGL 157', name: 'COMMUNICATION SKILLS I', description: 'Syllabus foundation of academic reading, essay composition, and presentation strategies.', semester: 1, credits: 2 },
    { code: 'MATH 157', name: 'ALGEBRA', description: 'Set theory, quadratic equations, sequence and series, complex numbers, and matrices.', semester: 1, credits: 2 },
    { code: 'PHARM 151', name: 'BASIC CHEMISTRY THEORY', description: 'Atomic structure, chemical bonding, periodic table, chemical equilibrium, and thermodynamics.', semester: 1, credits: 3 },
    { code: 'PHARM 153', name: 'BASIC CHEMISTRY LABORATORY', description: 'Practical experiments in volumetric analysis, acid-base titrations, and chemical reactions.', semester: 1, credits: 1 },
    { code: 'PHARM 191', name: 'INFORMATICS (COMPUTING)', description: 'Core details of computational literacy, spreadsheet modeling, and biomedical databases.', semester: 1, credits: 3 },
    
    // SECOND SEMESTER
    { code: 'BHM 162', name: 'BASIC MICROBIOLOGY II', description: 'Explores infectious micro-agents, immunology introductory parameters, and pathogenic cycles.', semester: 2, credits: 2 },
    { code: 'BHM 164', name: 'BASIC MICROBIOLOGY LABORATORY', description: 'Sterilization protocols, staining techniques (Gram staining), and agar cultural setups.', semester: 2, credits: 1 },
    { code: 'ENGL 158', name: 'COMMUNICATION SKILLS II', description: 'Advanced rhetoric, technical report writing, referencing styles, and documentation.', semester: 2, credits: 2 },
    { code: 'PHARM 152', name: 'BASIC ORGANIC CHEMISTRY', description: 'Alkanes, alkenes, functional groups, stereochemistry, and reactions of organic compounds.', semester: 2, credits: 3 },
    { code: 'PHARM 154', name: 'BASIC ORGANIC CHEMISTRY LABORATORY', description: 'Purification of organic products, boiling/melting point determinations, and synthesis.', semester: 2, credits: 1 },
    { code: 'PHARM 186', name: 'BIOCHEMISTRY I', description: 'Structure and functions of biomolecules (carbohydrates, lipids, proteins, and nucleic acids).', semester: 2, credits: 3 },
    { code: 'PHARM 188', name: 'BIOCHEMISTRY LABORATORY I', description: 'Qualitative and quantitative analysis of biological compounds and carbohydrates.', semester: 2, credits: 1 },
    { code: 'SMS 184', name: 'HUMAN PHYSIOLOGY I', description: 'Physiology of the cell, nervous system, blood, cardiovascular, and respiratory systems.', semester: 2, credits: 3 },
    { code: 'SMS 186', name: 'HUMAN ANATOMY I', description: 'Gross and microscopic anatomy of structural muscles, bones, cardiovascular, and nervous lines.', semester: 2, credits: 3 }
  ],
  200: [
    // FIRST SEMESTER
    { code: 'BHM 261', name: 'IMMUNOLOGY', description: 'Fundamentals of immune responses, antibody reactions, hypersensitivity, and diagnostic lab tests.', semester: 1, credits: 3 },
    { code: 'BHM 265', name: 'HERBAL DISPENSING & PRE-FORMULATION STUDIES', description: 'Theoretical guidelines of compounding, storage stability, dosage preparation, and natural excipients.', semester: 1, credits: 3 },
    { code: 'BHM 267', name: 'HERBAL DISPENSING & PRE-FORMULATION STUDIES LAB', description: 'Practical compounding of therapeutic mixtures, infusions, decoctions, and dosage suspensions.', semester: 1, credits: 1 },
    { code: 'PHARM 285', name: 'BIOCHEMISTRY II', description: 'Metabolic pathways, including glycolysis, Citric Acid Cycle, oxidative phosphorylation, and lipid metabolism.', semester: 1, credits: 3 },
    { code: 'PHARM 289', name: 'BIOCHEMISTRY LABORATORY II', description: 'Enzymatic assays, protein electrophoresis, and metabolic reaction measurements.', semester: 1, credits: 1 },
    { code: 'SMS 283', name: 'HUMAN PHYSIOLOGY II', description: 'Physiology of digestion, urinary excretion, endocrines, metabolism, and reproductive structures.', semester: 1, credits: 3 },
    { code: 'SMS 285', name: 'HUMAN ANATOMY II', description: 'Systemic gross study of abdominal organs, urinary tracts, reproductive systems, and brain lines.', semester: 1, credits: 3 },
    { code: 'STAT 153', name: 'STATISTICAL METHODS I', description: 'Descriptive statistics, probability, random variables, and binomial/normal distributions.', semester: 1, credits: 2 },
    
    // SECOND SEMESTER
    { code: 'BHM 252', name: 'GOOD HERBAL PRODUCTION PRACTICES', description: 'Standard policies for clean harvesting, processing hygiene, FDA registration, guidelines, and quality assurance.', semester: 2, credits: 3 },
    { code: 'PATH 272', name: 'PATHOLOGY', description: 'General mechanisms of disease, including inflammation, repair, neoplasia, and genetic cellular deviations.', semester: 2, credits: 3 },
    { code: 'PHARM 272', name: 'PHYTOCHEMISTRY', description: 'Secondary plant metabolites (alkaloids, glycosides, flavonoids, tannins) extraction and profiles.', semester: 2, credits: 3 },
    { code: 'PHARM 274', name: 'PHYTOCHEMISTRY LABORATORY', description: 'Qualitative screening, TLC chromatograms, and column isolation of secondary biomarkers.', semester: 2, credits: 1 },
    { code: 'PHARM 284', name: 'INTRODUCTORY PHARMACOLOGY', description: 'Principles of pharmacokinetics (absorption, distribution) and pharmacodynamics (receptor binding).', semester: 2, credits: 3 },
    { code: 'PHARM 286', name: 'PHARMACOLOGY LABORATORY I', description: 'Experimental organ bath setups, animal handling safety guidelines, and dose-response curves.', semester: 2, credits: 1 },
    { code: 'STAT 154', name: 'STATISTICAL METHODS II', description: 'Hypothesis testing, Student\'s t-test, ANOVA analyses, chi-square, and regression modeling.', semester: 2, credits: 2 }
  ],
  300: [
    // FIRST SEMESTER
    { code: 'BHM 351', name: 'HERBAL TOXICOLOGY', description: 'Mechanisms of natural poisons, toxicity grading, organ damages, and acute safety protocols.', semester: 1, credits: 3 },
    { code: 'BHM 353', name: 'PHYTOTHERAPY I', description: 'Clinical management of infectious, metabolic, and systemic disorders using validated botanical prescriptions.', semester: 1, credits: 4 },
    { code: 'PHARM 375', name: 'HERBAL PRODUCT ANALYSIS', description: 'Standardizing procedures, spectrophotometric assays, HPLC fingerprinting, and quality testing of natural finished products.', semester: 1, credits: 3 },
    { code: 'BHM 355', name: 'CLINICAL TRAINING I', description: 'Hospital-based diagnostics, patient clerking, history taking, and herbal clinical evaluations.', semester: 1, credits: 4 },
    { code: 'PHARM 377', name: 'HERBAL PRODUCT ANALYSIS LABORATORY', description: 'Chromatographic standardization, moisture content checks, and heavy metal limit tests.', semester: 1, credits: 1 },
    { code: 'PHARM 385', name: 'SYSTEMS PHARMACOLOGY I', description: 'Action mechanism of drug classes affecting the autonomic nervous system and cardiovascular tracks.', semester: 1, credits: 3 },
    { code: 'PHARM 387', name: 'PHARMACOLOGY LABORATORY II', description: 'In vitro assays, receptor-antagonist matching, and quantitative pharmacological trials.', semester: 1, credits: 1 },
    
    // SECOND SEMESTER
    { code: 'BHM 352', name: 'PHYTOTHERAPY II', description: 'Advanced therapeutic principles of plant extracts for oncology, immunity, and psychiatric systems.', semester: 2, credits: 4 },
    { code: 'BHM 354', name: 'COMPLEMENTARY & INTEGRATIVE MEDICINE', description: 'Philosophies of acupuncture, homeopathy, and integration of traditional medicine into public clinical health.', semester: 2, credits: 2 },
    { code: 'BHM 356', name: 'CLINICAL TRAINING II', description: 'Wards clinical rounds, botanical case presentations, diagnostic integration, and direct patient interaction.', semester: 2, credits: 5 },
    { code: 'BHM 358', name: 'RESEARCH METHODS', description: 'Designing clinical/herbal investigations, sampling strategies, ethical reviews, and dissertation writing proposals.', semester: 2, credits: 2 },
    { code: 'PHARM 386', name: 'CHEMICAL PATHOLOGY I', description: 'Bio-assays of body fluids, urine parameters, liver function markers, and kidney failure indicators.', semester: 2, credits: 3 },
    { code: 'PHARM 388', name: 'SYSTEMS PHARMACOLOGY II', description: 'Pharmacology of drugs affecting the endocrine system, central nervous system, and gastrointestinal tracks.', semester: 2, credits: 3 }
  ],
  400: [
    // FIRST SEMESTER
    { code: 'BHM 451', name: 'HERBAL PRODUCT FORMULATION & TECH', description: 'Industrial design of liquid mixtures, syrups, skin ointments, and solid tableted/capsulated plant extracts with modern quality controls.', semester: 1, credits: 3 },
    { code: 'BHM 453', name: 'CLINICAL TOXICOLOGY OF PHYTOMEDICINES', description: 'Assessing dose-dependent risks, specific target organ toxicity, systemic carcinogenicity, and drug-herb interactions.', semester: 1, credits: 3 },
    { code: 'BHM 455', name: 'CLINICAL PRACTICE & THERAPEUTICS I', description: 'Direct patient clerking, herbal diagnostic integration, botanical formulation prescriptions, and patient monitoring under supervision.', semester: 1, credits: 4 },
    { code: 'BHM 457', name: 'RESEARCH PROJECT I', description: 'Initial literature review, methodology drafting, laboratory setup/field collection, and scientific proposal defense.', semester: 1, credits: 3 },
    { code: 'BHM 459', name: 'PROFESSIONAL ETHICS & DEONTOLOGY', description: 'Legal frameworks of pharmacy, traditional medicine practice acts, patient confidentiality, and medical deontology rules.', semester: 1, credits: 2 },

    // SECOND SEMESTER
    { code: 'BHM 452', name: 'HERBAL COSMETICS & NUTRACEUTICALS', description: 'Formulation and analysis of botanical skin-care products, herbal soaps, and dietary supplements with therapeutic claims.', semester: 2, credits: 3 },
    { code: 'BHM 454', name: 'CLINICAL PRACTICE & THERAPEUTICS II', description: 'Advanced ward rounds, comparative herbal-synthetic evaluation, medical report composition, and holistic patient health management.', semester: 2, credits: 4 },
    { code: 'BHM 456', name: 'POST-HARVEST TECHNOLOGY OF MEDICINAL PLANTS', description: 'Mechanized dry protocols, moisture stabilization, warehouse storage optimization, and prevention of biological micro-contamination.', semester: 2, credits: 2 },
    { code: 'BHM 458', name: 'RESEARCH PROJECT II', description: 'Experimental phase execution, statistical processing, dissertation thesis composition, and final viva-voce presentation.', semester: 2, credits: 4 },
    { code: 'BHM 460', name: 'ENTREPRENEURSHIP & PRACTICE MANAGEMENT', description: 'Consulting clinic management, pharmaceutical distribution rules, business proposals, and small-scale manufacturing economics.', semester: 2, credits: 2 }
  ]
};

export const LEARNING_MATERIALS: LearningMaterial[] = [
  // Level 100
  {
    id: 'mat_101',
    title: 'Plant Nomenclature & Ethnobotany Principles',
    type: 'Lecture Slide',
    description: 'Detailed analysis of binomial conventions, standard botanical taxonomy, and diagnostic plant morphology labels under general rules of the ICN.',
    level: 100,
    courseCode: 'BHM 171',
    courseName: 'PLANT MORPHOLOGY'
  },
  {
    id: 'mat_102',
    title: 'Basic Histology & Organ Systems Lab Guide',
    type: 'Lab Manual',
    description: 'Detailed sketches of structural muscle lines, cellular walls, slide staining protocols, and microscopic analysis guidelines.',
    level: 100,
    courseCode: 'SMS 186',
    courseName: 'HUMAN ANATOMY I'
  },
  {
    id: 'mat_103',
    title: 'Informatics Reference Sheet for Health Sciences',
    type: 'Reference Sheet',
    description: 'Quick reference formulas for patient spreadsheets, medical database search operators, and analytical informatics basics.',
    level: 100,
    courseCode: 'PHARM 191',
    courseName: 'INFORMATICS (COMPUTING)'
  },
  // Level 200
  {
    id: 'mat_201',
    title: 'Compounding Techniques & Infusion Guidelines',
    type: 'Lecture Slide',
    description: 'Theoretical guidelines of formulating high-stability mixtures, tinctures, infusions, and standard clinical decoctions.',
    level: 200,
    courseCode: 'BHM 265',
    courseName: 'HERBAL DISPENSING & PRE-FORMULATION STUDIES'
  },
  {
    id: 'mat_202',
    title: 'Isolation of Secondary Metabolites Protocol',
    type: 'Lab Manual',
    description: 'Step-by-step procedures to isolate alkaloids and cardiac glycosides from dried materials using thin-layer chromatography (TLC).',
    level: 200,
    courseCode: 'PHARM 274',
    courseName: 'PHYTOCHEMISTRY LABORATORY'
  },
  // Level 300
  {
    id: 'mat_301',
    title: 'Cryptolepis Sanguinolenta Clinical Monograph',
    type: 'Monograph',
    description: 'Clinical standardizations, active cryptolepine dosage concentrations, anti-plasmodial mechanisms of action, and toxicological safety limit values.',
    level: 300,
    courseCode: 'BHM 353',
    courseName: 'PHYTOTHERAPY I'
  },
  {
    id: 'mat_302',
    title: 'HPLC Fingerprinting Guidelines for Quality Assurance',
    type: 'Reference Sheet',
    description: 'Standard solvent ratios and peak identification profiles for standardizing liquid-finished phytomedicines.',
    level: 300,
    courseCode: 'PHARM 375',
    courseName: 'HERBAL PRODUCT ANALYSIS'
  },
  // Level 400
  {
    id: 'mat_401',
    title: 'Phytocosmetics Formulation Guide',
    type: 'Lab Manual',
    description: 'Practical guides to formulating skin creams and herbal soaps from raw extracts, defining clean stability indicators.',
    level: 400,
    courseCode: 'BHM 452',
    courseName: 'HERBAL COSMETICS & NUTRACEUTICALS'
  },
  {
    id: 'mat_402',
    title: 'Clinical Practice Case Studies Handbook',
    type: 'Reference Sheet',
    description: 'Patient clerking templates, common traditional medicine indications, and safe dosage monitoring profiles.',
    level: 400,
    courseCode: 'BHM 454',
    courseName: 'CLINICAL PRACTICE & THERAPEUTICS II'
  }
];

export const PAST_QUESTIONS: PastQuestion[] = [
  // Level 100
  {
    id: 'pq_101',
    level: 100,
    courseCode: 'BHM 171',
    courseName: 'PLANT MORPHOLOGY',
    year: '2023/2024',
    questionType: 'MCQ',
    questionText: 'Which structural plant tissue is primary in providing mechanical rigidity and contains thick, lignified secondary walls?',
    options: [
      'Parenchyma',
      'Collenchyma',
      'Sclerenchyma',
      'Epidermis'
    ],
    correctAnswer: 'Sclerenchyma',
    explanation: 'Sclerenchyma fibers are heavily lignified with thick secondary walls designed strictly to provide mechanical support to mature plant structures.'
  },
  {
    id: 'pq_102',
    level: 100, // will fall back to L100
    courseCode: 'PHARM 151',
    courseName: 'BASIC CHEMISTRY THEORY',
    year: '2023/2024',
    questionType: 'MCQ',
    questionText: 'Under standard conditions, which thermodynamic state function represents the total heat content of a chemical system?',
    options: [
      'Entropy (S)',
      'Gibbs Free Energy (G)',
      'Enthalpy (H)',
      'Internal Energy (U)'
    ],
    correctAnswer: 'Enthalpy (H)',
    explanation: 'Enthalpy (H) is the measurement of energy in a thermodynamic system, representing the total heat output or intake.'
  },
  {
    id: 'pq_103',
    level: 100,
    courseCode: 'BHM 151',
    courseName: 'INTRODUCTION TO HERBAL MEDICINE',
    year: '2024/2025',
    questionType: 'MCQ',
    questionText: 'Who is historically recognized as the "Father of Medicine" whose early treatise on herbal therapeutics influenced global botanical traditions?',
    options: [
      'Theophrastus',
      'Hippocrates',
      'Galen',
      'Dioscorides'
    ],
    correctAnswer: 'Hippocrates',
    explanation: 'Hippocrates is widely considered the Father of Medicine, emphasizing natural causes and clinical observations over superstitions.'
  },
  // Level 200
  {
    id: 'pq_201',
    level: 200,
    courseCode: 'PHARM 272',
    courseName: 'PHYTOCHEMISTRY',
    year: '2024/2025',
    questionType: 'MCQ',
    questionText: 'Which chemical reagent is applied specifically to locate and identify secondary alkaloids by generating an orangish-brown precipitate?',
    options: [
      'Mayer\'s Reagent',
      'Dragendorff\'s Reagent',
      'Fehling\'s Solution',
      'Ninhydrin Reagent'
    ],
    correctAnswer: 'Dragendorff\'s Reagent',
    explanation: 'Dragendorff\'s reagent (potassium bismuth iodide) forms a highly diagnostic orange-red precipitate in the presence of secondary alkaloids.'
  },
  {
    id: 'pq_202',
    level: 200,
    courseCode: 'BHM 265',
    courseName: 'HERBAL DISPENSING & PRE-FORMULATION STUDIES',
    year: '2023/2024',
    questionType: 'MCQ',
    questionText: 'What is the principal biological objective of adding natural Arabic Gum (Acacia species exudate) during the dispensing of liquid emulsion formulations?',
    options: [
      'To provide systemic antiviral activity',
      'To act as a protective hydrophilic colloid and physical emulsifier',
      'To suppress fermentation pathways completely',
      'To accelerate crystallization boundaries of glycosides'
    ],
    correctAnswer: 'To act as a protective hydrophilic colloid and physical emulsifier',
    explanation: 'Gum Arabic acts as a key viscosity modifier and thermodynamic stabilizer, preventing phase separation in organic suspensions.'
  },
  // Level 300
  {
    id: 'pq_301',
    level: 300,
    courseCode: 'BHM 353',
    courseName: 'PHYTOTHERAPY I',
    year: '2024/2025',
    questionType: 'MCQ',
    questionText: 'What is the principal, clinical active-marker alkaloid found in yellow roots of Ghanaian Cryptolepis Sanguinolenta standardized for handling malaria?',
    options: [
      'Quinine',
      'Artemisinin',
      'Cryptolepine',
      'Berberine'
    ],
    correctAnswer: 'Cryptolepine',
    explanation: 'Cryptolepine is the key indoloquinoline alkaloid unique to Cryptolepis, clinically demonstrated to possess potent anti-plasmodial capabilities.'
  },
  {
    id: 'pq_302',
    level: 300,
    courseCode: 'BHM 351',
    courseName: 'HERBAL TOXICOLOGY',
    year: '2023/2024',
    questionType: 'MCQ',
    questionText: 'Chronic clinical exposure to Symphytum officinale (Comfrey) is contraindicated primarily due to which organ-specific toxicity pattern?',
    options: [
      'Cardiomyopathy via potassium channel block',
      'Severe irreversible cell-line renal damage',
      'Hepatic Veno-Occlusive Disease (HVOD) via pyrrolizidine alkaloids',
      'Anaphylactic respiratory response triggers'
    ],
    correctAnswer: 'Hepatic Veno-Occlusive Disease (HVOD) via pyrrolizidine alkaloids',
    explanation: 'Pyrrolizidine alkaloids present in Comfrey undergo hepatic bioactivation into toxic pyrroles, damaging endothelial lining cells and causing HVOD.'
  },
  // Level 400
  {
    id: 'pq_401',
    level: 400,
    courseCode: 'BHM 453',
    courseName: 'CLINICAL TOXICOLOGY OF PHYTOMEDICINES',
    year: '2024/2025',
    questionType: 'MCQ',
    questionText: 'Which organ is most commonly affected by pyrrolizidine alkaloid hepatotoxicity due to its high metabolic bioactivation capacity?',
    options: [
      'Kidneys',
      'Liver',
      'Lungs',
      'Heart'
    ],
    correctAnswer: 'Liver',
    explanation: 'The liver possesses high levels of cytochrome P450 enzymes that bioactivate pyrrolizidine alkaloids into highly reactive pyrroles, leading to Hepatic Veno-Occlusive Disease (HVOD).'
  },
  {
    id: 'pq_402',
    level: 400,
    courseCode: 'BHM 451',
    courseName: 'HERBAL PRODUCT FORMULATION & TECH',
    year: '2024/2025',
    questionType: 'MCQ',
    questionText: 'What is the primary thermodynamic stabilizing mechanism of dynamic surfactants in herbal ointment formulations?',
    options: [
      'To completely crystallize water-soluble principles',
      'To reduce interfacial tension between aqueous and non-aqueous phases',
      'To lower pH levels to absolute acidic status',
      'To accelerate evaporation rates of plant volatile oils'
    ],
    correctAnswer: 'To reduce interfacial tension between aqueous and non-aqueous phases',
    explanation: 'Surfactants act as key thermodynamic stabilizers in dual-phase formulations by reducing the interfacial tension between the oil and water phases, preventing coalescence.'
  }
];

export const HERBAL_RESOURCES: HerbalResource[] = [
  {
    id: 'herb_01',
    name: 'Ghanaian Cryptolepis',
    botanicalName: 'Cryptolepis sanguinolenta',
    family: 'Apocynaceae',
    localName: 'Nibima (Akan), Kadze (Ewe)',
    activeConstituents: ['Cryptolepine', 'Isocryptolepine', 'Neocryptolepine'],
    pharmacologicalActions: ['Antimalarial / Anti-plasmodial', 'Antipyretic', 'Clinical Anti-inflammatory'],
    therapeuticUses: ['Uncomplicated Plasmodium falciparum malaria', 'Clinical high fevers', 'Urinary tract infections (UTIs)'],
    preparation: 'Decoction: Boil 10 grams of clean dried root barks in 1 liter of pure water for 25 minutes. Take 100ml three times daily.',
    contraindications: 'Contraindicated in pregnancy and lactation. May prompt gastric irritation.'
  },
  {
    id: 'herb_02',
    name: 'West African Griffonia',
    botanicalName: 'Griffonia simplicifolia',
    family: 'Fabaceae',
    localName: 'Kagya (Akan), Toli (Ga)',
    activeConstituents: ['L-5-Hydroxytryptophan (5-HTP)', 'Griffonine', 'Lectins'],
    pharmacologicalActions: ['Serotonin pathway synthesis elevator', 'Anxiolytic / Sedative'],
    therapeuticUses: ['Sleep disorders / Severe Insomnia', 'Complementary anxiety management', 'Supportive weight optimization'],
    preparation: 'Infusion of standard ground seed powder or capsule equivalent to 50-100mg 5-HTP taken nightly.',
    contraindications: 'Do not combine with synthetic SSRI antidepressants to avoid potential Serotonin Syndrome.'
  },
  {
    id: 'herb_03',
    name: 'Neem Tree',
    botanicalName: 'Azadirachta indica',
    family: 'Meliaceae',
    localName: 'Dua Gyane / Neem (Akan)',
    activeConstituents: ['Azadirachtin', 'Nimbidin', 'Nimbin'],
    pharmacologicalActions: ['Broad-spectrum Antimicrobial', 'Anthelmintic', 'Moderate Hepatoprotective'],
    therapeuticUses: ['Symptom management of systemic fevers', 'Topical skin issues (Scabies, Eczema)', 'Antiparasitic scalp wash'],
    preparation: 'Leaf tea: Steep 4 dried leaves in 250ml freshly boiled water for 10 minutes. Topical: Local oil suspension.',
    contraindications: 'Do not administer internally to young children (clinical link to infant Reye\'s syndrome).'
  }
];
