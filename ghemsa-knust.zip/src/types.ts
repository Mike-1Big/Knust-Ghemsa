export interface HerbalResource {
  id: string;
  name: string;
  botanicalName: string;
  family: string;
  localName: string; // e.g., Akan name like "Nibima" or "Okanto"
  activeConstituents: string[];
  pharmacologicalActions: string[];
  therapeuticUses: string[];
  preparation: string;
  contraindications: string;
}

export interface LearningMaterial {
  id: string;
  title: string;
  type: 'Lecture Slide' | 'Lab Manual' | 'Monograph' | 'Reference Sheet';
  description: string;
  level: 100 | 200 | 300 | 400;
  courseCode: string;
  courseName: string;
  gDriveUrl?: string; // Standard public drive URL for viewing
  hasBackup?: boolean;
}

export interface PastQuestion {
  id: string;
  level: 100 | 200 | 300 | 400;
  courseCode: string;
  courseName: string;
  year: string;
  questionType: 'MCQ' | 'Short Answer';
  questionText: string;
  options?: string[]; // For MCQ
  correctAnswer: string;
  explanation: string;
}

export interface StudyNote {
  id: string;
  title: string;
  content: string;
  courseCode: string;
  timestamp: string;
  driveFileId?: string; // Tracks the file once synced to Google Drive
  isSynced: boolean;
}

export interface FloraItem {
  id: string;
  commonName: string;
  botanicalName: string;
  family: string;
  localName: string;
  distribution: string;
  constituents: string[];
  uses: string;
  imageUrl?: string;
}

