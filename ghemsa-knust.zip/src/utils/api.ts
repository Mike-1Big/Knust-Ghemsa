/**
 * API utility for GHEMSA KNUST Portal
 * Dual-support for Local Web Server and Capacitor Android Hybrid platforms
 */

export function getApiUrl(path: string): string {
  // If we have an environment variable VITE_API_URL specified, we use that for mobile/remote redirection.
  // Otherwise, it falls back to the active page origin or standard relative pathing.
  const baseUrl = (import.meta as any).env?.VITE_API_URL || '';
  
  // Clean slash prefix/suffix alignment
  const cleanedBase = baseUrl.replace(/\/$/, '');
  const cleanedPath = path.startsWith('/') ? path : `/${path}`;

  // Check if we are running in an Android/Capacitor native shell environment (which hosts assets locally on localhost)
  const isCapacitor = typeof window !== 'undefined' && (window as any).Capacitor;
  
  if (isCapacitor && cleanedBase) {
    return `${cleanedBase}${cleanedPath}`;
  }

  // Also, if the page is running locally on a test browser, but we've configured a remote mock/live backend URL
  if (cleanedBase && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')) {
    return `${cleanedBase}${cleanedPath}`;
  }

  return cleanedPath;
}
